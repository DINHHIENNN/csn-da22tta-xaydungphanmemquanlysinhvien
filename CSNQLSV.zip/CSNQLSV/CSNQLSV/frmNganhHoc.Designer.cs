﻿namespace CSNQLSV
{
    partial class frmNganhHoc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btncapnhatbmnh = new System.Windows.Forms.Button();
            this.dgvnh = new System.Windows.Forms.DataGridView();
            this.btntimnh = new System.Windows.Forms.Button();
            this.txttimnh = new System.Windows.Forms.TextBox();
            this.cbmabmnh = new System.Windows.Forms.ComboBox();
            this.btnxoanh = new System.Windows.Forms.Button();
            this.btnhuynh = new System.Windows.Forms.Button();
            this.btnthoatnh = new System.Windows.Forms.Button();
            this.btnsuanh = new System.Windows.Forms.Button();
            this.btnthemnh = new System.Windows.Forms.Button();
            this.txttennh = new System.Windows.Forms.TextBox();
            this.txtmanh = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvnh)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btncapnhatbmnh
            // 
            this.btncapnhatbmnh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btncapnhatbmnh.Font = new System.Drawing.Font("Arial", 10F);
            this.btncapnhatbmnh.ForeColor = System.Drawing.Color.Black;
            this.btncapnhatbmnh.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btncapnhatbmnh.Location = new System.Drawing.Point(604, 106);
            this.btncapnhatbmnh.Name = "btncapnhatbmnh";
            this.btncapnhatbmnh.Size = new System.Drawing.Size(181, 33);
            this.btncapnhatbmnh.TabIndex = 36;
            this.btncapnhatbmnh.Text = "Cập nhật bộ môn";
            this.btncapnhatbmnh.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btncapnhatbmnh.UseVisualStyleBackColor = false;
            this.btncapnhatbmnh.Click += new System.EventHandler(this.btncapnhatbmnh_Click);
            this.btncapnhatbmnh.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.VoHieuHoa_cb);
            this.btncapnhatbmnh.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btncapnhatbmnh.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // dgvnh
            // 
            this.dgvnh.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvnh.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvnh.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvnh.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvnh.Location = new System.Drawing.Point(20, 37);
            this.dgvnh.Name = "dgvnh";
            this.dgvnh.RowHeadersWidth = 51;
            this.dgvnh.RowTemplate.Height = 24;
            this.dgvnh.Size = new System.Drawing.Size(822, 237);
            this.dgvnh.TabIndex = 42;
            this.dgvnh.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvnh_CellClick);
            // 
            // btntimnh
            // 
            this.btntimnh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntimnh.Location = new System.Drawing.Point(830, 75);
            this.btntimnh.Name = "btntimnh";
            this.btntimnh.Size = new System.Drawing.Size(41, 37);
            this.btntimnh.TabIndex = 41;
            this.btntimnh.UseVisualStyleBackColor = true;
            this.btntimnh.Click += new System.EventHandler(this.btntimnh_Click);
            // 
            // txttimnh
            // 
            this.txttimnh.Font = new System.Drawing.Font("Arial", 10F);
            this.txttimnh.Location = new System.Drawing.Point(601, 81);
            this.txttimnh.Name = "txttimnh";
            this.txttimnh.Size = new System.Drawing.Size(223, 27);
            this.txttimnh.TabIndex = 40;
            this.txttimnh.TextChanged += new System.EventHandler(this.Textchange);
            this.txttimnh.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txttimnh_KeyDown);
            // 
            // cbmabmnh
            // 
            this.cbmabmnh.Font = new System.Drawing.Font("Arial", 10F);
            this.cbmabmnh.FormattingEnabled = true;
            this.cbmabmnh.Items.AddRange(new object[] {
            "Chọn mã khoa"});
            this.cbmabmnh.Location = new System.Drawing.Point(193, 110);
            this.cbmabmnh.Name = "cbmabmnh";
            this.cbmabmnh.Size = new System.Drawing.Size(405, 27);
            this.cbmabmnh.TabIndex = 39;
            this.cbmabmnh.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.cbmabmnh_DrawItem);
            this.cbmabmnh.SelectedIndexChanged += new System.EventHandler(this.cbmabmnh_SelectedIndexChanged);
            this.cbmabmnh.TextChanged += new System.EventHandler(this.Textchange);
            this.cbmabmnh.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.VoHieuHoa_cb);
            // 
            // btnxoanh
            // 
            this.btnxoanh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnxoanh.Font = new System.Drawing.Font("Arial", 10F);
            this.btnxoanh.ForeColor = System.Drawing.Color.Black;
            this.btnxoanh.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnxoanh.Location = new System.Drawing.Point(166, 321);
            this.btnxoanh.Name = "btnxoanh";
            this.btnxoanh.Size = new System.Drawing.Size(82, 38);
            this.btnxoanh.TabIndex = 32;
            this.btnxoanh.Text = "Xóa";
            this.btnxoanh.UseVisualStyleBackColor = false;
            this.btnxoanh.Click += new System.EventHandler(this.btnxoanh_Click);
            this.btnxoanh.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnxoanh.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // btnhuynh
            // 
            this.btnhuynh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnhuynh.Font = new System.Drawing.Font("Arial", 10F);
            this.btnhuynh.ForeColor = System.Drawing.Color.Black;
            this.btnhuynh.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnhuynh.Location = new System.Drawing.Point(463, 321);
            this.btnhuynh.Name = "btnhuynh";
            this.btnhuynh.Size = new System.Drawing.Size(73, 38);
            this.btnhuynh.TabIndex = 33;
            this.btnhuynh.Text = "Hủy";
            this.btnhuynh.UseVisualStyleBackColor = false;
            this.btnhuynh.Click += new System.EventHandler(this.btnhuynh_Click);
            this.btnhuynh.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnhuynh.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // btnthoatnh
            // 
            this.btnthoatnh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnthoatnh.Font = new System.Drawing.Font("Arial", 10F);
            this.btnthoatnh.ForeColor = System.Drawing.Color.Black;
            this.btnthoatnh.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnthoatnh.Location = new System.Drawing.Point(757, 321);
            this.btnthoatnh.Name = "btnthoatnh";
            this.btnthoatnh.Size = new System.Drawing.Size(97, 38);
            this.btnthoatnh.TabIndex = 34;
            this.btnthoatnh.Text = "Thoát";
            this.btnthoatnh.UseVisualStyleBackColor = false;
            this.btnthoatnh.Click += new System.EventHandler(this.btnthoatnh_Click);
            this.btnthoatnh.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnthoatnh.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // btnsuanh
            // 
            this.btnsuanh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnsuanh.Font = new System.Drawing.Font("Arial", 10F);
            this.btnsuanh.ForeColor = System.Drawing.Color.Black;
            this.btnsuanh.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnsuanh.Location = new System.Drawing.Point(295, 321);
            this.btnsuanh.Name = "btnsuanh";
            this.btnsuanh.Size = new System.Drawing.Size(130, 38);
            this.btnsuanh.TabIndex = 35;
            this.btnsuanh.Text = "Cập nhật";
            this.btnsuanh.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnsuanh.UseVisualStyleBackColor = false;
            this.btnsuanh.Click += new System.EventHandler(this.btnsuanh_Click);
            this.btnsuanh.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnsuanh.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // btnthemnh
            // 
            this.btnthemnh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnthemnh.Font = new System.Drawing.Font("Arial", 10F);
            this.btnthemnh.ForeColor = System.Drawing.Color.Black;
            this.btnthemnh.Location = new System.Drawing.Point(30, 321);
            this.btnthemnh.Name = "btnthemnh";
            this.btnthemnh.Size = new System.Drawing.Size(91, 38);
            this.btnthemnh.TabIndex = 37;
            this.btnthemnh.Text = "Thêm";
            this.btnthemnh.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnthemnh.UseVisualStyleBackColor = false;
            this.btnthemnh.Click += new System.EventHandler(this.btnthemnh_Click);
            this.btnthemnh.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnthemnh.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // txttennh
            // 
            this.txttennh.Font = new System.Drawing.Font("Arial", 10F);
            this.txttennh.Location = new System.Drawing.Point(193, 70);
            this.txttennh.Name = "txttennh";
            this.txttennh.Size = new System.Drawing.Size(405, 27);
            this.txttennh.TabIndex = 30;
            this.txttennh.TextChanged += new System.EventHandler(this.Textchange);
            this.txttennh.Enter += new System.EventHandler(this.txt_Enter);
            this.txttennh.Leave += new System.EventHandler(this.txt_Leave);
            // 
            // txtmanh
            // 
            this.txtmanh.Font = new System.Drawing.Font("Arial", 10F);
            this.txtmanh.Location = new System.Drawing.Point(193, 32);
            this.txtmanh.Name = "txtmanh";
            this.txtmanh.Size = new System.Drawing.Size(405, 27);
            this.txtmanh.TabIndex = 31;
            this.txtmanh.TextChanged += new System.EventHandler(this.Textchange);
            this.txtmanh.Enter += new System.EventHandler(this.txt_Enter);
            this.txtmanh.Leave += new System.EventHandler(this.txt_Leave);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 10F);
            this.label4.Location = new System.Drawing.Point(31, 77);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 19);
            this.label4.TabIndex = 27;
            this.label4.Text = "Tên Ngành học";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 10F);
            this.label3.Location = new System.Drawing.Point(31, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 19);
            this.label3.TabIndex = 28;
            this.label3.Text = "Bộ Môn";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 10F);
            this.label2.Location = new System.Drawing.Point(31, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 19);
            this.label2.TabIndex = 29;
            this.label2.Text = "Mã Ngành học";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(274, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(343, 35);
            this.label1.TabIndex = 25;
            this.label1.Text = "QUẢN LÝ NGÀNH HỌC";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.txttennh);
            this.groupBox1.Controls.Add(this.btncapnhatbmnh);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtmanh);
            this.groupBox1.Controls.Add(this.cbmabmnh);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(30, 114);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(824, 175);
            this.groupBox1.TabIndex = 43;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "THÔNG TIN";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.dgvnh);
            this.groupBox2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 391);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(859, 293);
            this.groupBox2.TabIndex = 44;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "DANH SÁCH NGÀNH HỌC";
            // 
            // frmNganhHoc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(244)))), ((int)(((byte)(251)))));
            this.ClientSize = new System.Drawing.Size(886, 696);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btntimnh);
            this.Controls.Add(this.txttimnh);
            this.Controls.Add(this.btnxoanh);
            this.Controls.Add(this.btnhuynh);
            this.Controls.Add(this.btnthoatnh);
            this.Controls.Add(this.btnsuanh);
            this.Controls.Add(this.btnthemnh);
            this.Controls.Add(this.label1);
            this.Name = "frmNganhHoc";
            this.Text = "FfrmNganhHoc";
            this.Load += new System.EventHandler(this.FfrmNganhHoc_Load);
            this.Enter += new System.EventHandler(this.txt_Enter);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.VoHieuHoa_cb);
            ((System.ComponentModel.ISupportInitialize)(this.dgvnh)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button btncapnhatbmnh;
        private System.Windows.Forms.DataGridView dgvnh;
        private System.Windows.Forms.Button btntimnh;
        private System.Windows.Forms.TextBox txttimnh;
        private System.Windows.Forms.ComboBox cbmabmnh;
        private System.Windows.Forms.Button btnxoanh;
        private System.Windows.Forms.Button btnhuynh;
        private System.Windows.Forms.Button btnthoatnh;
        private System.Windows.Forms.Button btnsuanh;
        private System.Windows.Forms.Button btnthemnh;
        private System.Windows.Forms.TextBox txttennh;
        private System.Windows.Forms.TextBox txtmanh;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}