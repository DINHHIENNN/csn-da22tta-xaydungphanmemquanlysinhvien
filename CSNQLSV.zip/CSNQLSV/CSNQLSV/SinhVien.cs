﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace CSNQLSV
{
    interface itfSinhVien
    {
        void addSinhVien();
        DataTable getdsSinhVien();
        void deleteSinhVien();
        void updateSinhVien();
    }
    public abstract class AbstracSinhVien
    {

        public abstract void addSinhVien();
        public abstract DataTable getdsSinhVien();
        public abstract void deleteSinhVien();
        public abstract void updateSinhVien();
    }
    public class SinhVien:AbstracSinhVien,itfSinhVien
        {
        private string maSV;
        private string hoSV;
        private string tenSV;
        private string gioiTinh;
        private DateTime ngaySinh;
        private string email;
        private string soDienThoai;
        private string noiSinh;
        private string diaChi;
        private string maLop;
        private string maPXa;
        private string maHT;
        private string maTT;
        private string maKhoa;
        ThaotacCSDL db;
        public string MaSV { get => maSV; set => maSV = value; }
        public string HoSV { get => hoSV; set => hoSV = value; }
        public string TenSV { get => tenSV; set => tenSV = value; }
        public string GioiTinh { get => gioiTinh; set => gioiTinh = value; }
        public DateTime NgaySinh { get => ngaySinh; set => ngaySinh = value; }
        public string Email { get => email; set => email = value; }
        public string SoDienThoai { get => soDienThoai; set => soDienThoai = value; }
        public string NoiSinh { get => noiSinh; set => noiSinh = value; }
        public string DiaChi { get => diaChi; set => diaChi = value; }
        public string MaLop { get => maLop; set => maLop = value; }
        public string MaPXa { get => maPXa; set => maPXa = value; }
        public string MaHT { get => maHT; set => maHT = value; }
        public string MaTT { get => maTT; set => maTT = value; }
        public string MaKhoa { get => maKhoa; set => maKhoa = value; }
        public SinhVien():base()
            {
                db = new ThaotacCSDL();
            }
            public override void addSinhVien()
            {
                string sql = string.Format("INSERT INTO SinhVien values ('{0}',N'{1}',N'{2}',N'{3}','{4}',N'{5}','{6}',N'{7}',N'{8}','{9}','{10}','{11}','{12}','{13}')", this.MaSV, this.HoSV, this.TenSV, this.GioiTinh, this.NgaySinh, this.Email, this.SoDienThoai, this.NoiSinh, this.DiaChi, this.MaLop, this.MaPXa, this.MaHT, this.MaTT,this.MaKhoa);
                Console.WriteLine(sql);
                db.ExecuteNonQuery(sql);
            }
            public override DataTable getdsSinhVien()
            {
                string sql = "select * from SinhVien";
                DataTable dt = db.Execute(sql);
                return dt;
            }
            public override void deleteSinhVien()
            {
                string sql = String.Format("Delete from SinhVien where MaSV='{0}'", MaSV);
                Console.WriteLine(sql);
                db.ExecuteNonQuery(sql);
            }
            public override void updateSinhVien()
            {
                string sql = String.Format("Update SinhVien set MaSV = '{0}', HoSV = N'{1}', TenSV = N'{2}', GioiTinh = N'{3}', NgaySinh= '{4}', Email= N'{5}', SoDienThoai = '{6}', NoiSinh = N'{7}', DiaChi = N'{8}', MaLop = '{9}', MaPXa = '{10}', MaHT = '{11}', MaTT = '{12}' , MaKhoa = '{13}' where MaSV='{14}'", MaSV, HoSV, TenSV, GioiTinh, NgaySinh, Email, SoDienThoai, NoiSinh, DiaChi, MaLop, MaPXa, MaHT, MaTT,MaKhoa, MaSV);
                Console.WriteLine(sql);
                db.ExecuteNonQuery(sql);

            }
        }
}
