﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSNQLSV
{
    public partial class frmLop : Form
    {
        Lop l;
        KhoaHoc kh;
        NganhHoc nh;
        public frmLop()
        {
            InitializeComponent();
            l = new Lop();
            kh = new KhoaHoc();
            nh = new NganhHoc();
        }
        private void frmLop_Load(object sender, EventArgs e)
        {

            dgvlop.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DataTable dtl = l.getdsLop();
            this.dgvlop.DataSource = dtl;
            load(1);
            load_cb();
            Hienthinut(2);
            dgvlop.Columns["MaLop"].HeaderText = "Mã Lớp";
            dgvlop.Columns["TenLop"].HeaderText = "Tên Lớp";
            dgvlop.Columns["MaNH"].HeaderText = "Mã Nhành Học";
            dgvlop.Columns["MaKH"].HeaderText = "Mã Khóa Học";
            dgvlop.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dgvlop.DefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Regular);
            Image timbmicon = Properties.Resources.tim;
            Image resizetimbmicon = new Bitmap(timbmicon, new Size(26, 26));
            btntimlop.Image = resizetimbmicon;
        }
        public void Hienthinut(int x)
        {
            if (x == 1)
            {
                this.btnxoalop.Enabled = true;
                this.btnsualop.Enabled = true;
                this.btnthemlop.Enabled = true;
            }
            else if (x == 2)
            {
                this.btnxoalop.Enabled = false;
                this.btnsualop.Enabled = false;
                this.btnthemlop.Enabled = false;
            }

        }
        public void load_cb()
        {
            load_cbkh();
            load_cbnh();
        }
        public void load_cbkh()
        {

            DataTable dtkh = kh.getdsKhoaHoc();
            DataRow dr1 = dtkh.NewRow();
            dr1[dtkh.Columns[0].ColumnName] = DBNull.Value;
            dr1[dtkh.Columns[1].ColumnName] = "Chọn khóa học";
            dtkh.Rows.InsertAt(dr1, 0);
            this.cbmakhlop.DataSource = dtkh;
            this.cbmakhlop.ValueMember = dtkh.Columns[0].ColumnName.ToString();
            this.cbmakhlop.DisplayMember = dtkh.Columns[1].ColumnName.ToString();
            cbmakhlop.DrawMode = DrawMode.OwnerDrawFixed;
            cbmakhlop.DrawItem += cbkh_DrawItem;

        }
        public void load_cbnh()
        {
            DataTable dtnh = nh.getdsNganhHoc();
            DataRow dr = dtnh.NewRow();
            dr[dtnh.Columns[0].ColumnName] = DBNull.Value;
            dr[dtnh.Columns[1].ColumnName] = "Chọn ngành học";
            dtnh.Rows.InsertAt(dr, 0);
            this.cbmanhlop.DataSource = dtnh;
            this.cbmanhlop.ValueMember = dtnh.Columns[0].ColumnName.ToString();
            this.cbmanhlop.DisplayMember = dtnh.Columns[1].ColumnName.ToString();
            cbmanhlop.DrawMode = DrawMode.OwnerDrawFixed;
            cbmanhlop.DrawItem += cbnh_DrawItem;
        }
        public void load(int x)
        {
            if (x == 1)
            {
                this.txtmalop.Text = "Nhập mã lớp";
                this.txttenlop.Text = "Nhập tên lớp";
                this.txtmalop.ForeColor = Color.Gray;
                this.txttenlop.ForeColor = Color.Gray;
                this.ActiveControl = this.txtmalop;
                this.btnhuylop.Enabled = false;
            }
            else if (x == 2)
            {
                this.txtmalop.ForeColor = Color.Black;
                this.txttenlop.ForeColor = Color.Black;
                this.ActiveControl = this.txtmalop;
                this.btnhuylop.Enabled = false;

            }

        }

        private void cbnh_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            ComboBox comboBox = sender as ComboBox;
            string text = comboBox.GetItemText(comboBox.Items[e.Index]);


            Color textColor = text == "Chọn ngành học" ? Color.Gray : Color.Black;

            e.DrawBackground();
            using (Brush brush = new SolidBrush(textColor))
            {
                e.Graphics.DrawString(text, e.Font, brush, e.Bounds);
            }
            e.DrawFocusRectangle();
        }

        private void cbkh_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            ComboBox comboBox = sender as ComboBox;
            string text = comboBox.GetItemText(comboBox.Items[e.Index]);


            Color textColor = text == "Chọn khóa học" ? Color.Gray : Color.Black;

            e.DrawBackground();
            using (Brush brush = new SolidBrush(textColor))
            {
                e.Graphics.DrawString(text, e.Font, brush, e.Bounds);
            }
            e.DrawFocusRectangle();
        }

        private void cbmanhlop_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void cbmakhlop_KeyPress(object sender, KeyPressEventArgs e)
        {

            e.Handled = true;
        }

        private void dgvlop_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            int id = e.RowIndex;
            if (id == dgvlop.NewRowIndex || id < 0)
            {
                load(1);
                Hienthinut(2);
                load_cb();
                MessageBox.Show("Dữ liệu rỗng!");
                return;
            }
            else
            {
                this.btnhuylop.Enabled = true;
                Hienthinut(1);
                this.txtmalop.ForeColor = Color.Black;
                this.txttenlop.ForeColor = Color.Black;
                this.cbmanhlop.ForeColor = Color.Black;
                this.cbmakhlop.ForeColor = Color.Black;

                this.txtmalop.Text = dgvlop.Rows[id].Cells[2].Value.ToString();
                this.txttenlop.Text = dgvlop.Rows[id].Cells[3].Value.ToString();

                this.cbmakhlop.SelectedValue = dgvlop.Rows[id].Cells[0].Value.ToString().Trim();
                this.cbmakhlop.Text = this.cbmakhlop.GetItemText(this.cbmakhlop.SelectedItem);
                DataTable dtl1 = l.getdsLop();
                dgvlop.DataSource = dtl1;
                this.cbmanhlop.SelectedValue = dgvlop.Rows[id].Cells[1].Value.ToString().Trim();
                this.cbmanhlop.Text = this.cbmanhlop.GetItemText(this.cbmanhlop.SelectedItem);
            }
        }

        private void btnthemlop_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.txtmalop.Text == "Nhập mã lớp" || this.txtmalop.Text == "")
                {
                    MessageBox.Show("Vui lòng nhập Mã lớp!");
                    this.txtmalop.Focus();
                }
                else if (this.txttenlop.Text == "Nhập tên lớp" || this.txttenlop.Text == "")
                {
                    MessageBox.Show("Vui lòng nhập Tên lớp!");
                    this.txttenlop.Focus();
                }
                else if (this.cbmanhlop.Text == "Chọn ngành học")
                {
                    MessageBox.Show("Vui lòng chọn ngành học!");
                }
                else if (this.cbmakhlop.Text == "Chọn khóa học")
                {
                    MessageBox.Show("Vui lòng chọn khóa học!");
                }
                else
                {
                    l.Manh = this.cbmanhlop.SelectedValue.ToString().Trim();
                    l.Makh = this.cbmakhlop.SelectedValue.ToString().Trim();
                    l.Malop = this.txtmalop.Text;
                    l.Tenlop = this.txttenlop.Text;
                    l.addLop();
                    DataTable dtl = l.getdsLop();
                    dgvlop.DataSource = dtl;
                    dgvlop.Columns["MaLop"].HeaderText = "Mã Lớp";
                    dgvlop.Columns["TenLop"].HeaderText = "Tên Lớp";
                    dgvlop.Columns["MaNH"].HeaderText = "Mã Nhành Học";
                    dgvlop.Columns["MaKH"].HeaderText = "Mã Khóa Học";
                    load(1);
                    load_cb();
                    MessageBox.Show("Dữ liệu đã được thêm thành công vào hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lớp có mã {this.txtmalop.Text} đã tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnxoalop_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa dữ liệu này không?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                try
                {
                    if (this.txtmalop.Text == "Nhập mã lớp" || this.txtmalop.Text == "")
                    {
                        MessageBox.Show("Bạn chưa nhập mã lớp. Vui lòng điền thông tin trước khi tiếp tục.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        this.txtmalop.Focus();
                        return;
                    }
                    DataTable dtl1 = l.getdsLop();
                    dgvlop.DataSource = dtl1;
                    bool kt = false;
                    foreach (DataGridViewRow row in dgvlop.Rows)
                    {
                        if (row.Cells["MaLop"].Value != null && row.Cells["MaLop"].Value.ToString().Trim() == txtmalop.Text.Trim())
                        {
                            l.Malop = this.txtmalop.Text;
                            l.deleteLop();
                            DataTable dtl = l.getdsLop();
                            dgvlop.DataSource = dtl;
                            dgvlop.Columns["MaLop"].HeaderText = "Mã Lớp";
                            dgvlop.Columns["TenLop"].HeaderText = "Tên Lớp";
                            dgvlop.Columns["MaNH"].HeaderText = "Mã Nhành Học";
                            dgvlop.Columns["MaKH"].HeaderText = "Mã Khóa Học";
                            load_cb();
                            load(1);
                            MessageBox.Show("Dữ liệu đã được xóa thành công khỏi hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.btnhuylop.Enabled = true;
                            kt = true;
                            break;
                        }
                    }
                    if (!kt)
                    {
                        dgvlop.Columns["MaLop"].HeaderText = "Mã Lớp";
                        dgvlop.Columns["TenLop"].HeaderText = "Tên Lớp";
                        dgvlop.Columns["MaNH"].HeaderText = "Mã Nhành Học";
                        dgvlop.Columns["MaKH"].HeaderText = "Mã Khóa Học";
                        MessageBox.Show($"Lớp có mã {this.txtmalop.Text} không tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi người dùng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi không thể xóa dữ liệu !", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Hủy xóa dữ liệu.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnsualop_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.txtmalop.Text == "Nhập mã lớp" || this.txtmalop.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập mã lớp. Vui lòng điền thông tin trước khi tiếp tục.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    this.txtmalop.Focus();
                    return;
                }
                DataTable dtl1 = l.getdsLop();
                dgvlop.DataSource = dtl1;
                
                bool kt = false;
                int dem = 0;
                foreach (DataGridViewRow row in dgvlop.Rows)
                {
                    if (row.Cells["MaLop"].Value != null && row.Cells["MaLop"].Value.ToString().Trim() == txtmalop.Text.Trim())
                    {
                        if (this.txtmalop.Text == "Nhập mã lớp" || this.txtmalop.Text == "")
                        {
                            this.txtmalop.Text = row.Cells["MaLop"].Value.ToString();
                        }
                        if (this.txttenlop.Text == "Nhập tên lớp" || this.txttenlop.Text == "")
                        {
                            this.txttenlop.Text = row.Cells["TenLop"].Value.ToString();
                            this.txttenlop.ForeColor = Color.Black;
                            dem += 1;
                        }
                        if (this.cbmakhlop.Text == "Chọn khóa học")
                        {
                            if (row.Cells["MaKH"].Value != null)
                            {
                                this.cbmakhlop.SelectedValue = row.Cells["MaKH"].Value.ToString().Trim();
                                this.cbmakhlop.Text = this.cbmakhlop.GetItemText(this.cbmakhlop.SelectedItem);
                                dem += 1;
                            }
                        }
                        if (this.cbmanhlop.Text == "Chọn ngành học")
                        {
                            if (row.Cells["MaNH"].Value != null)
                            {
                                this.cbmanhlop.SelectedValue = row.Cells["MaNH"].Value.ToString().Trim();
                                this.cbmanhlop.Text = this.cbmanhlop.GetItemText(this.cbmanhlop.SelectedItem);
                                dem += 1;
                            }
                        }
                        if (dem == 3)
                        {
                            MessageBox.Show("Chưa nhập thông tin cần cập nhật.\n\nVui lòng kiểm tra và thử lại.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.txtmalop.Focus();
                            return;
                        }

                        l.Manh = this.cbmanhlop.SelectedValue.ToString().Trim();
                        l.Makh = this.cbmakhlop.SelectedValue.ToString().Trim();
                        l.Malop = this.txtmalop.Text;
                        l.Tenlop = this.txttenlop.Text;
                        l.updateLop();
                        DataTable dtl = l.getdsLop();
                        dgvlop.DataSource = dtl;
                        dgvlop.Columns["MaLop"].HeaderText = "Mã Lớp";
                        dgvlop.Columns["TenLop"].HeaderText = "Tên Lớp";
                        dgvlop.Columns["MaNH"].HeaderText = "Mã Nhành Học";
                        dgvlop.Columns["MaKH"].HeaderText = "Mã Khóa Học";
                        load(1);
                        load_cb();
                        if (this.cbmanhlop.SelectedIndex == 0)
                        {
                            this.cbmanhlop.ForeColor = Color.Gray;
                        }
                        else
                        {
                            this.cbmanhlop.ForeColor = Color.Black;
                        }
                        if (this.cbmakhlop.SelectedIndex == 0)
                        {
                            this.cbmakhlop.ForeColor = Color.Gray;
                        }
                        else
                        {
                            this.cbmakhlop.ForeColor = Color.Black;
                        }
                        MessageBox.Show("Dữ liệu đã được cập nhật thành công vào hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        kt = true;
                        break;
                    }
                }
                if (!kt)
                {
                    MessageBox.Show($"Lớp có mã {this.txtmalop.Text} không tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi người dùng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.txtmalop.Focus();
                    dgvlop.Columns["MaLop"].HeaderText = "Mã Lớp";
                    dgvlop.Columns["TenLop"].HeaderText = "Tên Lớp";
                    dgvlop.Columns["MaNH"].HeaderText = "Mã Nhành Học";
                    dgvlop.Columns["MaKH"].HeaderText = "Mã Khóa Học";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi cập nhật dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnhuylop_Click(object sender, EventArgs e)
        {
            load(1);
            load_cb();
            this.txttimlop.Text = "";
            Hienthinut(2);
            this.btnhuylop.Enabled = false;
            DataTable dtl = l.getdsLop();
            dgvlop.DataSource = dtl;
            dgvlop.Columns["MaLop"].HeaderText = "Mã Lớp";
            dgvlop.Columns["TenLop"].HeaderText = "Tên Lớp";
            dgvlop.Columns["MaNH"].HeaderText = "Mã Nhành Học";
            dgvlop.Columns["MaKH"].HeaderText = "Mã Khóa Học";
        }

        private void btnthoatlop_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btncapnhatnhlop_Click(object sender, EventArgs e)
        {
            frmNganhHoc frmnh = new frmNganhHoc();
            if (frmnh.ShowDialog() == DialogResult.OK)
            {
                if (this.txtmalop.Text != "Nhập mã lớp" || this.txttenlop.Text != "Nhập tên lớp" || this.cbmanhlop.SelectedIndex != 0 || this.cbmakhlop.SelectedIndex != 0)
                {
                    this.btnhuylop.Enabled = true;
                    Hienthinut(2);
                    btncapnhatnhlop.BackColor = Color.FromArgb(192, 236, 255);
                    btncapnhatnhlop.ForeColor = Color.Black;
                    if (cbmanhlop.SelectedIndex == 0)
                    {
                        cbmanhlop.ForeColor = Color.Gray;
                    }
                    else
                    {
                        cbmanhlop.ForeColor = Color.Black;
                    }
                }
                else
                {
                    Hienthinut(1);
                    btncapnhatnhlop.BackColor = Color.FromArgb(192, 236, 255);
                    btncapnhatnhlop.ForeColor = Color.Black;
                }
            }
            btncapnhatnhlop.BackColor = Color.FromArgb(192, 236, 255);
            btncapnhatnhlop.ForeColor = Color.Black;
            load_cbnh();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            frmKhoaHoc frmKhoaHoc = new frmKhoaHoc();
            if (frmKhoaHoc.ShowDialog() == DialogResult.OK)
            {
                if (this.txtmalop.Text != "Nhập mã lớp" || this.txttenlop.Text != "Nhập tên lớp" || this.cbmanhlop.SelectedIndex != 0 || this.cbmakhlop.SelectedIndex != 0)
                {
                    this.btnhuylop.Enabled = true;
                    Hienthinut(2);
                    btncapnhatkhlop.BackColor = Color.FromArgb(192, 236, 255);
                    btncapnhatkhlop.ForeColor = Color.Black;
                    if (cbmakhlop.SelectedIndex == 0)
                    {
                        cbmakhlop.ForeColor = Color.Gray;
                    }
                    else
                    {
                        cbmakhlop.ForeColor = Color.Black;
                    }
                }
                else
                {
                    Hienthinut(1);
                    btncapnhatkhlop.BackColor = Color.FromArgb(192, 236, 255);
                    btncapnhatkhlop.ForeColor = Color.Black;
                }
            }
            load_cbkh();
            btncapnhatkhlop.BackColor = Color.FromArgb(192, 236, 255);
            btncapnhatkhlop.ForeColor = Color.Black;
        }

        private void Textchange(object sender, EventArgs e)
        {
            bool isMalopEmpty = string.IsNullOrWhiteSpace(this.txtmalop.Text) || this.txtmalop.Text == "Nhập mã lớp";
            bool isTenlopEmpty = string.IsNullOrWhiteSpace(this.txttenlop.Text) || this.txttenlop.Text == "Nhập tên lớp";
            bool isTimlopEmpty = string.IsNullOrWhiteSpace(this.txttimlop.Text);
            bool isCbnhNotSelected = this.cbmanhlop.SelectedIndex == 0;
            bool isCbkhNotSelected = this.cbmakhlop.SelectedIndex == 0;
            if (cbmanhlop.SelectedIndex == 0)
            {
                cbmanhlop.ForeColor = Color.Gray;
            }
            else
            {
                cbmanhlop.ForeColor = Color.Black;
            }
            if (cbmakhlop.SelectedIndex == 0)
            {
                cbmakhlop.ForeColor = Color.Gray;
            }
            else
            {
                cbmakhlop.ForeColor = Color.Black;
            }

            if (isMalopEmpty && isTenlopEmpty && isCbnhNotSelected && isCbkhNotSelected)
            {
                if (isTimlopEmpty)
                {
                    this.btnhuylop.Enabled = false;
                }
                else
                {
                    this.btnhuylop.Enabled = true;
                }
                Hienthinut(2);
            }
            else if (isMalopEmpty || isTenlopEmpty || isCbnhNotSelected || isCbkhNotSelected)
            {
                if (isTimlopEmpty)
                {
                    this.btnhuylop.Enabled = true;
                }
                else
                {
                    this.btnhuylop.Enabled = true;
                }
                Hienthinut(1);
            }
            else if ((!isMalopEmpty && !isTenlopEmpty && !isCbnhNotSelected && !isCbkhNotSelected))
            {

                if (isTimlopEmpty)
                {
                    this.btnhuylop.Enabled = true;
                }
                else
                {
                    this.btnhuylop.Enabled = true;
                }
                Hienthinut(1);
            }
        }


        private void txt_Enter(object sender, EventArgs e)
        {
            TextBox tx = (TextBox)sender;
            if (tx.Text == this.txtmalop.Text && tx.Text == "Nhập mã lớp")
            {
                this.txtmalop.Text = "";
                this.txtmalop.ForeColor = Color.Black;
            }
            else if (tx.Text == this.txttenlop.Text && tx.Text == "Nhập tên lớp")
            {
                this.txttenlop.Text = "";
                this.txttenlop.ForeColor = Color.Black;
            }
        }

        private void txt_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(this.txtmalop.Text))
            {
                this.txtmalop.Text = "Nhập mã lớp";
                this.txtmalop.ForeColor = Color.Gray;
            }
            else if (string.IsNullOrWhiteSpace(this.txttenlop.Text))
            {
                this.txttenlop.Text = "Nhập tên lớp";
                this.txttenlop.ForeColor = Color.Gray;
            }
        }

        private void btntimlop_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(this.txttimlop.Text.Trim()))
            {
                MessageBox.Show("Vui lòng nhập từ khóa tìm kiếm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            DataTable dtl = l.getdsLop();
            dgvlop.DataSource = dtl;
            DataTable dt_tim = new DataTable();
            DataColumn col1 = new DataColumn();
            col1.ColumnName = "MaNH";
            DataColumn col2 = new DataColumn();
            col2.ColumnName = "MaKH";
            DataColumn col3 = new DataColumn();
            col3.ColumnName = "MaLop";
            DataColumn col4 = new DataColumn();
            col4.ColumnName = "TenLop";
            dt_tim.Columns.Add(col1);
            dt_tim.Columns.Add(col2);
            dt_tim.Columns.Add(col3);
            dt_tim.Columns.Add(col4);
            bool kt = false;
            foreach (DataGridViewRow row in dgvlop.Rows)
            {
                if (row.Cells["MaLop"].Value != null && row.Cells["MaLop"].Value.ToString().Trim() == txttimlop.Text.Trim())
                {
                    DataRow dr = dt_tim.NewRow();
                    dr["MaLop"] = row.Cells["MaLop"].Value.ToString();
                    dr["TenLop"] = row.Cells["TenLop"].Value.ToString();
                    dr["MaNH"] = row.Cells["MaNH"].Value.ToString();
                    dr["MaKH"] = row.Cells["MaKH"].Value.ToString();
                    dt_tim.Rows.Add(dr);
                    kt = true;
                }
            }
            load(1);
            load_cb();
            Hienthinut(2);
            this.dgvlop.DataSource = dt_tim;
            if (!kt)
            {
                MessageBox.Show("Không tìm thấy thông tin lớp", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            this.btnhuylop.Enabled = true;
        }

        private void txttimlop_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) {
                btntimlop_Click(sender, e);
            }

        }

        private void btn_MouseEnter(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.Text == btnthemlop.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnxoalop.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnsualop.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnhuylop.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnthoatlop.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btncapnhatnhlop.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btncapnhatkhlop.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
        }

        private void btn_MouseLeave(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.Text == btnthemlop.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnxoalop.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnsualop.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnhuylop.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnthoatlop.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btncapnhatnhlop.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btncapnhatkhlop.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
        }

        //private void cbmakhlop_SelectedIndexChanged(object sender, EventArgs e)
        //{

        //    if (this.cbmakhlop.SelectedIndex > 0 && this.cbmanhlop.SelectedIndex<0)
        //    {
        //        DataTable dtlop = l.getdsLop();
        //        this.dgvlop.DataSource = dtlop;
        //        DataTable dtkh = kh.getdsKhoaHoc();
        //        this.dgvan.DataSource = dtkh;
        //        DataTable dtnh = nh.getdsNganhHoc();
        //        this.dgvan2.DataSource = dtnh;
        //        string makh = this.cbmakhlop.SelectedValue.ToString().Trim();
        //        DataTable dtpx2 = new DataTable();
        //        DataColumn col = new DataColumn();
        //        col.ColumnName = "MaNH";
        //        DataColumn col2 = new DataColumn();
        //        col2.ColumnName = "TenNH";
        //        DataColumn col3 = new DataColumn();
        //        col3.ColumnName = "MaBM";

        //        dtpx2.Columns.Add(col);
        //        dtpx2.Columns.Add(col2);
        //        dtpx2.Columns.Add(col3);

        //        DataRow d = dtpx2.NewRow();
        //        d[0] = "-1"; d[1] = "Chọn ngành học"; d[2] = "NULL";
        //        dtpx2.Rows.Add(d);

        //        DataTable dtp2 = new DataTable();
        //        DataColumn co = new DataColumn();
        //        co.ColumnName = "MaLop";
        //        DataColumn co2 = new DataColumn();
        //        co2.ColumnName = "TenLop";
        //        DataColumn co3 = new DataColumn();
        //        co3.ColumnName = "MaKH";
        //        DataColumn co4 = new DataColumn();
        //        co4.ColumnName = "MaNH";
        //        dtp2.Columns.Add(co);
        //        dtp2.Columns.Add(co2);
        //        dtp2.Columns.Add(co3);
        //        dtp2.Columns.Add(co4);
        //        bool kt = false;
        //        foreach (DataGridViewRow row in dgvan.Rows)
        //        {
        //            if (row.Cells["MaKH"].Value != null && row.Cells["MaKH"].Value.ToString().Trim() == makh)
        //            {
        //                foreach (DataGridViewRow row1 in dgvlop.Rows)
        //                {
        //                    if(row1.Cells["MaKH"].Value != null && row1.Cells["MaKH"].Value.ToString().Trim() == makh)
        //                    {
        //                        foreach (DataGridViewRow row2 in dgvan2.Rows)
        //                        {
        //                            if (row2.Cells["MaNH"].Value != null && row2.Cells["MaNH"].Value.ToString().Trim() == row1.Cells["MaNH"].Value.ToString().Trim())
        //                            {

        //                                DataRow d1 = dtpx2.NewRow();
        //                                d1[0] = row2.Cells["MaNH"].Value.ToString().Trim();
        //                                d1[1] = row2.Cells["TenNH"].Value.ToString();
        //                                d1[2] = row2.Cells["MaBM"].Value.ToString().Trim();
        //                                dtpx2.Rows.Add(d1);

        //                                DataRow an = dtp2.NewRow();
        //                                an[0] = row1.Cells["MaLop"].Value.ToString().Trim();
        //                                an[1] = row1.Cells["TenLop"].Value.ToString();
        //                                an[2] = row1.Cells["MaKH"].Value.ToString().Trim();
        //                                an[3] = row1.Cells["MaNH"].Value.ToString().Trim();
        //                                dtp2.Rows.Add(an);
        //                            }
        //                        }

        //                    }
        //                }    

        //            }
        //        }
        //        this.dgvlop.DataSource = dtp2;
        //        this.cbmanhlop.DataSource = dtpx2;
        //        this.cbmanhlop.ValueMember = dtpx2.Columns[0].ColumnName.ToString();
        //        this.cbmanhlop.DisplayMember = dtpx2.Columns[1].ColumnName.ToString();
        //        cbmanhlop.DrawMode = DrawMode.OwnerDrawFixed;
        //        cbmanhlop.DrawItem += cbnh_DrawItem;

        //    }
        //}

        private void cbmanhlop_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (txttimlop.Text != "")
                return;
            DataTable dtlop = l.getdsLop();
            this.dgvlop.DataSource = dtlop;
            if (this.cbmanhlop.SelectedIndex > 0 && this.cbmakhlop.SelectedIndex == 0)
            {
                string manh = this.cbmanhlop.SelectedValue.ToString().Trim();

                DataTable dtp2 = new DataTable();
                DataColumn co = new DataColumn();
                co.ColumnName = "MaLop";
                DataColumn co2 = new DataColumn();
                co2.ColumnName = "TenLop";
                DataColumn co3 = new DataColumn();
                co3.ColumnName = "MaKH";
                DataColumn co4 = new DataColumn();
                co4.ColumnName = "MaNH";
                dtp2.Columns.Add(co);
                dtp2.Columns.Add(co2);
                dtp2.Columns.Add(co3);
                dtp2.Columns.Add(co4);
                bool kt = false;
                foreach (DataGridViewRow row1 in dgvlop.Rows)
                {
                    if (row1.Cells["MaNH"].Value != null && row1.Cells["MaNH"].Value.ToString().Trim() == manh)
                    {
                        DataRow an = dtp2.NewRow();
                        an[0] = row1.Cells["MaLop"].Value.ToString().Trim();
                        an[1] = row1.Cells["TenLop"].Value.ToString();
                        an[2] = row1.Cells["MaKH"].Value.ToString().Trim();
                        an[3] = row1.Cells["MaNH"].Value.ToString().Trim();
                        dtp2.Rows.Add(an);
                    }
                }
                this.dgvlop.DataSource = dtp2;
            }
            else if (this.cbmakhlop.SelectedIndex > 0 && this.cbmanhlop.SelectedIndex == 0)
            {
            string makh = this.cbmakhlop.SelectedValue.ToString().Trim();
            DataTable dtp2 = new DataTable();
            DataColumn co = new DataColumn();
            co.ColumnName = "MaLop";
            DataColumn co2 = new DataColumn();
            co2.ColumnName = "TenLop";
            DataColumn co3 = new DataColumn();
            co3.ColumnName = "MaKH";
            DataColumn co4 = new DataColumn();
            co4.ColumnName = "MaNH";
            dtp2.Columns.Add(co);
            dtp2.Columns.Add(co2);
            dtp2.Columns.Add(co3);
            dtp2.Columns.Add(co4);
            bool kt = false;
            foreach (DataGridViewRow row1 in dgvlop.Rows)
            {
                if (row1.Cells["MaKH"].Value != null && row1.Cells["MaKH"].Value.ToString().Trim() == makh)
                 {
                    DataRow an = dtp2.NewRow();
                    an[0] = row1.Cells["MaLop"].Value.ToString().Trim();
                    an[1] = row1.Cells["TenLop"].Value.ToString();
                    an[2] = row1.Cells["MaKH"].Value.ToString().Trim();
                    an[3] = row1.Cells["MaNH"].Value.ToString().Trim();
                    dtp2.Rows.Add(an);                     
                }
            }
            this.dgvlop.DataSource = dtp2;
            }
            else if (this.cbmakhlop.SelectedIndex > 0 && this.cbmanhlop.SelectedIndex > 0)
            {
                string makh = this.cbmakhlop.SelectedValue.ToString().Trim();
                string manh = this.cbmanhlop.SelectedValue.ToString().Trim();
                DataTable dtp2 = new DataTable();
                DataColumn co = new DataColumn();
                co.ColumnName = "MaLop";
                DataColumn co2 = new DataColumn();
                co2.ColumnName = "TenLop";
                DataColumn co3 = new DataColumn();
                co3.ColumnName = "MaKH";
                DataColumn co4 = new DataColumn();
                co4.ColumnName = "MaNH";
                dtp2.Columns.Add(co);
                dtp2.Columns.Add(co2);
                dtp2.Columns.Add(co3);
                dtp2.Columns.Add(co4);
                bool kt = false;
                foreach (DataGridViewRow row1 in dgvlop.Rows)
                {
                    if ((row1.Cells["MaKH"].Value != null && row1.Cells["MaKH"].Value.ToString().Trim() == makh) && (row1.Cells["MaNH"].Value != null && row1.Cells["MaNH"].Value.ToString().Trim() == manh))
                    {
                        DataRow an = dtp2.NewRow();
                        an[0] = row1.Cells["MaLop"].Value.ToString().Trim();
                        an[1] = row1.Cells["TenLop"].Value.ToString();
                        an[2] = row1.Cells["MaKH"].Value.ToString().Trim();
                        an[3] = row1.Cells["MaNH"].Value.ToString().Trim();
                        dtp2.Rows.Add(an);
                    }    
                }
                this.dgvlop.DataSource = dtp2;
            }
        }
    }
    
}
