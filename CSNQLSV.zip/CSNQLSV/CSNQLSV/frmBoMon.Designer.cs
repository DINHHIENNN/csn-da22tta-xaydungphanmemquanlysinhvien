﻿namespace CSNQLSV
{
    partial class frmBoMon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.rtxtmotabm = new System.Windows.Forms.RichTextBox();
            this.btnxoabm = new System.Windows.Forms.Button();
            this.btnhuybm = new System.Windows.Forms.Button();
            this.btnthoatbm = new System.Windows.Forms.Button();
            this.btnsuabm = new System.Windows.Forms.Button();
            this.btnthembm = new System.Windows.Forms.Button();
            this.txttenbm = new System.Windows.Forms.TextBox();
            this.txtmabm = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cbmakhoabm = new System.Windows.Forms.ComboBox();
            this.btntimbm = new System.Windows.Forms.Button();
            this.txttimbm = new System.Windows.Forms.TextBox();
            this.btncapnhatmkbm = new System.Windows.Forms.Button();
            this.dgvbm = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvbm)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // rtxtmotabm
            // 
            this.rtxtmotabm.Font = new System.Drawing.Font("Arial", 10F);
            this.rtxtmotabm.Location = new System.Drawing.Point(173, 157);
            this.rtxtmotabm.Name = "rtxtmotabm";
            this.rtxtmotabm.Size = new System.Drawing.Size(405, 82);
            this.rtxtmotabm.TabIndex = 20;
            this.rtxtmotabm.Text = "";
            this.rtxtmotabm.TextChanged += new System.EventHandler(this.Textchange);
            this.rtxtmotabm.Enter += new System.EventHandler(this.rtxt_Enter);
            this.rtxtmotabm.Leave += new System.EventHandler(this.rtxt_Leave);
            // 
            // btnxoabm
            // 
            this.btnxoabm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnxoabm.Font = new System.Drawing.Font("Arial", 10F);
            this.btnxoabm.ForeColor = System.Drawing.Color.Black;
            this.btnxoabm.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnxoabm.Location = new System.Drawing.Point(199, 374);
            this.btnxoabm.Name = "btnxoabm";
            this.btnxoabm.Size = new System.Drawing.Size(97, 38);
            this.btnxoabm.TabIndex = 14;
            this.btnxoabm.Text = "Xóa";
            this.btnxoabm.UseVisualStyleBackColor = false;
            this.btnxoabm.Click += new System.EventHandler(this.btnxoabm_Click);
            this.btnxoabm.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnxoabm.MouseLeave += new System.EventHandler(this.btnsuabm_MouseLeave);
            // 
            // btnhuybm
            // 
            this.btnhuybm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnhuybm.Font = new System.Drawing.Font("Arial", 10F);
            this.btnhuybm.ForeColor = System.Drawing.Color.Black;
            this.btnhuybm.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnhuybm.Location = new System.Drawing.Point(466, 374);
            this.btnhuybm.Name = "btnhuybm";
            this.btnhuybm.Size = new System.Drawing.Size(97, 38);
            this.btnhuybm.TabIndex = 15;
            this.btnhuybm.Text = "Hủy";
            this.btnhuybm.UseVisualStyleBackColor = false;
            this.btnhuybm.Click += new System.EventHandler(this.btnhuybm_Click);
            this.btnhuybm.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnhuybm.MouseLeave += new System.EventHandler(this.btnsuabm_MouseLeave);
            // 
            // btnthoatbm
            // 
            this.btnthoatbm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnthoatbm.Font = new System.Drawing.Font("Arial", 10F);
            this.btnthoatbm.ForeColor = System.Drawing.Color.Black;
            this.btnthoatbm.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnthoatbm.Location = new System.Drawing.Point(732, 374);
            this.btnthoatbm.Name = "btnthoatbm";
            this.btnthoatbm.Size = new System.Drawing.Size(97, 38);
            this.btnthoatbm.TabIndex = 16;
            this.btnthoatbm.Text = "Thoát";
            this.btnthoatbm.UseVisualStyleBackColor = false;
            this.btnthoatbm.Click += new System.EventHandler(this.btnthoatbm_Click);
            this.btnthoatbm.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnthoatbm.MouseLeave += new System.EventHandler(this.btnsuabm_MouseLeave);
            // 
            // btnsuabm
            // 
            this.btnsuabm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnsuabm.Font = new System.Drawing.Font("Arial", 10F);
            this.btnsuabm.ForeColor = System.Drawing.Color.Black;
            this.btnsuabm.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnsuabm.Location = new System.Drawing.Point(331, 374);
            this.btnsuabm.Name = "btnsuabm";
            this.btnsuabm.Size = new System.Drawing.Size(105, 38);
            this.btnsuabm.TabIndex = 17;
            this.btnsuabm.Text = "Cập nhật";
            this.btnsuabm.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnsuabm.UseVisualStyleBackColor = false;
            this.btnsuabm.Click += new System.EventHandler(this.btnsuabm_Click);
            this.btnsuabm.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnsuabm.MouseLeave += new System.EventHandler(this.btnsuabm_MouseLeave);
            // 
            // btnthembm
            // 
            this.btnthembm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnthembm.Font = new System.Drawing.Font("Arial", 10F);
            this.btnthembm.ForeColor = System.Drawing.Color.Black;
            this.btnthembm.Location = new System.Drawing.Point(71, 374);
            this.btnthembm.Name = "btnthembm";
            this.btnthembm.Size = new System.Drawing.Size(97, 38);
            this.btnthembm.TabIndex = 18;
            this.btnthembm.Text = "Thêm";
            this.btnthembm.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnthembm.UseVisualStyleBackColor = false;
            this.btnthembm.Click += new System.EventHandler(this.btnthembm_Click);
            this.btnthembm.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnthembm.MouseLeave += new System.EventHandler(this.btnsuabm_MouseLeave);
            // 
            // txttenbm
            // 
            this.txttenbm.Font = new System.Drawing.Font("Arial", 10F);
            this.txttenbm.Location = new System.Drawing.Point(173, 71);
            this.txttenbm.Name = "txttenbm";
            this.txttenbm.Size = new System.Drawing.Size(405, 27);
            this.txttenbm.TabIndex = 12;
            this.txttenbm.TextChanged += new System.EventHandler(this.Textchange);
            this.txttenbm.Enter += new System.EventHandler(this.txt_Enter);
            this.txttenbm.Leave += new System.EventHandler(this.txt_Leave);
            // 
            // txtmabm
            // 
            this.txtmabm.Font = new System.Drawing.Font("Arial", 10F);
            this.txtmabm.Location = new System.Drawing.Point(173, 33);
            this.txtmabm.Name = "txtmabm";
            this.txtmabm.Size = new System.Drawing.Size(405, 27);
            this.txtmabm.TabIndex = 13;
            this.txtmabm.TextChanged += new System.EventHandler(this.Textchange);
            this.txtmabm.Enter += new System.EventHandler(this.txt_Enter);
            this.txtmabm.Leave += new System.EventHandler(this.txt_Leave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 10F);
            this.label5.Location = new System.Drawing.Point(31, 157);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 19);
            this.label5.TabIndex = 7;
            this.label5.Text = "Mô tả";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 10F);
            this.label4.Location = new System.Drawing.Point(31, 74);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 19);
            this.label4.TabIndex = 8;
            this.label4.Text = "Tên Bộ môn";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 10F);
            this.label3.Location = new System.Drawing.Point(31, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 19);
            this.label3.TabIndex = 9;
            this.label3.Text = "Khoa";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 10F);
            this.label2.Location = new System.Drawing.Point(31, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 19);
            this.label2.TabIndex = 10;
            this.label2.Text = "Mã Bộ môn";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(325, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(279, 35);
            this.label1.TabIndex = 6;
            this.label1.Text = "QUẢN LÝ BỘ MÔN";
            // 
            // cbmakhoabm
            // 
            this.cbmakhoabm.Font = new System.Drawing.Font("Arial", 10F);
            this.cbmakhoabm.FormattingEnabled = true;
            this.cbmakhoabm.Items.AddRange(new object[] {
            "Chọn mã khoa"});
            this.cbmakhoabm.Location = new System.Drawing.Point(173, 111);
            this.cbmakhoabm.Name = "cbmakhoabm";
            this.cbmakhoabm.Size = new System.Drawing.Size(405, 27);
            this.cbmakhoabm.TabIndex = 21;
            this.cbmakhoabm.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.cbmakhoabm_DrawItem);
            this.cbmakhoabm.SelectedIndexChanged += new System.EventHandler(this.cbmakhoabm_SelectedIndexChanged);
            this.cbmakhoabm.TextChanged += new System.EventHandler(this.Textchange);
            this.cbmakhoabm.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.VoHieuHoa_cb);
            // 
            // btntimbm
            // 
            this.btntimbm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntimbm.Location = new System.Drawing.Point(826, 52);
            this.btntimbm.Name = "btntimbm";
            this.btntimbm.Size = new System.Drawing.Size(41, 37);
            this.btntimbm.TabIndex = 23;
            this.btntimbm.UseVisualStyleBackColor = true;
            this.btntimbm.Click += new System.EventHandler(this.btntimbm_Click);
            // 
            // txttimbm
            // 
            this.txttimbm.Font = new System.Drawing.Font("Arial", 10F);
            this.txttimbm.Location = new System.Drawing.Point(590, 58);
            this.txttimbm.Name = "txttimbm";
            this.txttimbm.Size = new System.Drawing.Size(230, 27);
            this.txttimbm.TabIndex = 22;
            this.txttimbm.TextChanged += new System.EventHandler(this.Textchange);
            this.txttimbm.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txttimbm_KeyDown);
            // 
            // btncapnhatmkbm
            // 
            this.btncapnhatmkbm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btncapnhatmkbm.Font = new System.Drawing.Font("Arial", 10F);
            this.btncapnhatmkbm.ForeColor = System.Drawing.Color.Black;
            this.btncapnhatmkbm.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btncapnhatmkbm.Location = new System.Drawing.Point(587, 107);
            this.btncapnhatmkbm.Name = "btncapnhatmkbm";
            this.btncapnhatmkbm.Size = new System.Drawing.Size(162, 33);
            this.btncapnhatmkbm.TabIndex = 17;
            this.btncapnhatmkbm.Text = "Cập nhật khoa";
            this.btncapnhatmkbm.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btncapnhatmkbm.UseVisualStyleBackColor = false;
            this.btncapnhatmkbm.Click += new System.EventHandler(this.btncapnhatmkbm_Click);
            this.btncapnhatmkbm.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btncapnhatmkbm.MouseLeave += new System.EventHandler(this.btnsuabm_MouseLeave);
            // 
            // dgvbm
            // 
            this.dgvbm.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvbm.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvbm.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvbm.ColumnHeadersHeight = 29;
            this.dgvbm.Location = new System.Drawing.Point(10, 35);
            this.dgvbm.Name = "dgvbm";
            this.dgvbm.RowHeadersWidth = 51;
            this.dgvbm.RowTemplate.Height = 24;
            this.dgvbm.Size = new System.Drawing.Size(848, 211);
            this.dgvbm.TabIndex = 24;
            this.dgvbm.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Load_khi_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.cbmakhoabm);
            this.groupBox1.Controls.Add(this.btncapnhatmkbm);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtmabm);
            this.groupBox1.Controls.Add(this.rtxtmotabm);
            this.groupBox1.Controls.Add(this.txttenbm);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(71, 91);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(780, 259);
            this.groupBox1.TabIndex = 25;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "THÔNG TIN";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.dgvbm);
            this.groupBox2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 435);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(881, 264);
            this.groupBox2.TabIndex = 26;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "DANH SÁCH BỘ MÔN";
            // 
            // frmBoMon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(244)))), ((int)(((byte)(251)))));
            this.ClientSize = new System.Drawing.Size(905, 711);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btntimbm);
            this.Controls.Add(this.txttimbm);
            this.Controls.Add(this.btnxoabm);
            this.Controls.Add(this.btnhuybm);
            this.Controls.Add(this.btnthoatbm);
            this.Controls.Add(this.btnsuabm);
            this.Controls.Add(this.btnthembm);
            this.Controls.Add(this.label1);
            this.Name = "frmBoMon";
            this.Text = "frmBoMon";
            this.Load += new System.EventHandler(this.frmBoMon_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvbm)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtxtmotabm;
        private System.Windows.Forms.Button btnxoabm;
        private System.Windows.Forms.Button btnhuybm;
        private System.Windows.Forms.Button btnthoatbm;
        private System.Windows.Forms.Button btnsuabm;
        private System.Windows.Forms.Button btnthembm;
        private System.Windows.Forms.TextBox txttenbm;
        private System.Windows.Forms.TextBox txtmabm;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbmakhoabm;
        private System.Windows.Forms.Button btntimbm;
        private System.Windows.Forms.TextBox txttimbm;
        private System.Windows.Forms.DataGridView dgvbm;
        public System.Windows.Forms.Button btncapnhatmkbm;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}