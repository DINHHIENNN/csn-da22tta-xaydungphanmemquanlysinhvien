﻿namespace CSNQLSV
{
    partial class Mainfrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnsv = new System.Windows.Forms.Button();
            this.btnt = new System.Windows.Forms.Button();
            this.btnht = new System.Windows.Forms.Button();
            this.btnl = new System.Windows.Forms.Button();
            this.btnbm = new System.Windows.Forms.Button();
            this.btnpx = new System.Windows.Forms.Button();
            this.btnnh = new System.Windows.Forms.Button();
            this.btnkh = new System.Windows.Forms.Button();
            this.btnhd = new System.Windows.Forms.Button();
            this.btnk = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblfooter = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnsv
            // 
            this.btnsv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnsv.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsv.Location = new System.Drawing.Point(484, 74);
            this.btnsv.Name = "btnsv";
            this.btnsv.Size = new System.Drawing.Size(202, 50);
            this.btnsv.TabIndex = 0;
            this.btnsv.Text = "Quản lý sinh viên";
            this.btnsv.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnsv.UseVisualStyleBackColor = false;
            this.btnsv.Click += new System.EventHandler(this.btnsv_Click);
            this.btnsv.MouseEnter += new System.EventHandler(this.btn_mouseentre);
            this.btnsv.MouseLeave += new System.EventHandler(this.btn_modeleave);
            // 
            // btnt
            // 
            this.btnt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnt.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnt.Location = new System.Drawing.Point(484, 364);
            this.btnt.Name = "btnt";
            this.btnt.Size = new System.Drawing.Size(202, 50);
            this.btnt.TabIndex = 0;
            this.btnt.Text = "Quản lý tỉnh thành";
            this.btnt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnt.UseVisualStyleBackColor = false;
            this.btnt.Click += new System.EventHandler(this.btnt_Click);
            this.btnt.MouseEnter += new System.EventHandler(this.btn_mouseentre);
            this.btnt.MouseLeave += new System.EventHandler(this.btn_modeleave);
            // 
            // btnht
            // 
            this.btnht.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnht.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnht.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnht.Location = new System.Drawing.Point(484, 413);
            this.btnht.Name = "btnht";
            this.btnht.Size = new System.Drawing.Size(202, 50);
            this.btnht.TabIndex = 0;
            this.btnht.Text = "Quản lý huyện thị";
            this.btnht.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnht.UseVisualStyleBackColor = false;
            this.btnht.Click += new System.EventHandler(this.btnht_Click);
            this.btnht.MouseEnter += new System.EventHandler(this.btn_mouseentre);
            this.btnht.MouseLeave += new System.EventHandler(this.btn_modeleave);
            // 
            // btnl
            // 
            this.btnl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnl.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnl.Location = new System.Drawing.Point(484, 315);
            this.btnl.Name = "btnl";
            this.btnl.Size = new System.Drawing.Size(202, 50);
            this.btnl.TabIndex = 0;
            this.btnl.Text = "Quản lý lớp";
            this.btnl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnl.UseVisualStyleBackColor = false;
            this.btnl.Click += new System.EventHandler(this.btnl_Click);
            this.btnl.MouseEnter += new System.EventHandler(this.btn_mouseentre);
            this.btnl.MouseLeave += new System.EventHandler(this.btn_modeleave);
            // 
            // btnbm
            // 
            this.btnbm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnbm.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbm.Location = new System.Drawing.Point(484, 123);
            this.btnbm.Name = "btnbm";
            this.btnbm.Size = new System.Drawing.Size(202, 48);
            this.btnbm.TabIndex = 0;
            this.btnbm.Text = "Quản lý bộ môn";
            this.btnbm.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnbm.UseVisualStyleBackColor = false;
            this.btnbm.Click += new System.EventHandler(this.btnbm_Click);
            this.btnbm.MouseEnter += new System.EventHandler(this.btn_mouseentre);
            this.btnbm.MouseLeave += new System.EventHandler(this.btn_modeleave);
            // 
            // btnpx
            // 
            this.btnpx.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnpx.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpx.Location = new System.Drawing.Point(484, 462);
            this.btnpx.Name = "btnpx";
            this.btnpx.Size = new System.Drawing.Size(202, 48);
            this.btnpx.TabIndex = 0;
            this.btnpx.Text = "Quản lý phường xã";
            this.btnpx.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnpx.UseVisualStyleBackColor = false;
            this.btnpx.Click += new System.EventHandler(this.btnpx_Click);
            this.btnpx.MouseEnter += new System.EventHandler(this.btn_mouseentre);
            this.btnpx.MouseLeave += new System.EventHandler(this.btn_modeleave);
            // 
            // btnnh
            // 
            this.btnnh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnnh.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnh.Location = new System.Drawing.Point(484, 219);
            this.btnnh.Name = "btnnh";
            this.btnnh.Size = new System.Drawing.Size(202, 50);
            this.btnnh.TabIndex = 0;
            this.btnnh.Text = "Quản lý ngành học";
            this.btnnh.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnnh.UseVisualStyleBackColor = false;
            this.btnnh.Click += new System.EventHandler(this.btnnh_Click);
            this.btnnh.MouseEnter += new System.EventHandler(this.btn_mouseentre);
            this.btnnh.MouseLeave += new System.EventHandler(this.btn_modeleave);
            // 
            // btnkh
            // 
            this.btnkh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnkh.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnkh.Location = new System.Drawing.Point(484, 268);
            this.btnkh.Name = "btnkh";
            this.btnkh.Size = new System.Drawing.Size(202, 48);
            this.btnkh.TabIndex = 0;
            this.btnkh.Text = "Quản lý khóa học";
            this.btnkh.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnkh.UseVisualStyleBackColor = false;
            this.btnkh.Click += new System.EventHandler(this.btnkh_Click);
            this.btnkh.MouseEnter += new System.EventHandler(this.btn_mouseentre);
            this.btnkh.MouseLeave += new System.EventHandler(this.btn_modeleave);
            // 
            // btnhd
            // 
            this.btnhd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnhd.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnhd.Location = new System.Drawing.Point(484, 509);
            this.btnhd.Name = "btnhd";
            this.btnhd.Size = new System.Drawing.Size(202, 48);
            this.btnhd.TabIndex = 0;
            this.btnhd.Text = "Hướng dẫn sử dụng";
            this.btnhd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnhd.UseVisualStyleBackColor = false;
            this.btnhd.Click += new System.EventHandler(this.btnhd_Click);
            this.btnhd.MouseEnter += new System.EventHandler(this.btn_mouseentre);
            this.btnhd.MouseLeave += new System.EventHandler(this.btn_modeleave);
            // 
            // btnk
            // 
            this.btnk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnk.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnk.Location = new System.Drawing.Point(484, 170);
            this.btnk.Name = "btnk";
            this.btnk.Size = new System.Drawing.Size(202, 50);
            this.btnk.TabIndex = 0;
            this.btnk.Text = "Quản lý khoa";
            this.btnk.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnk.UseVisualStyleBackColor = false;
            this.btnk.Click += new System.EventHandler(this.btnk_Click);
            this.btnk.MouseEnter += new System.EventHandler(this.btn_mouseentre);
            this.btnk.MouseLeave += new System.EventHandler(this.btn_modeleave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(89, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(515, 38);
            this.label1.TabIndex = 1;
            this.label1.Text = "HỆ THỐNG QUẢN LÝ SINH VIÊN";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkGray;
            this.panel1.Controls.Add(this.lblfooter);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.ForeColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(0, 568);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(698, 80);
            this.panel1.TabIndex = 2;
            // 
            // lblfooter
            // 
            this.lblfooter.AutoSize = true;
            this.lblfooter.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfooter.ForeColor = System.Drawing.Color.White;
            this.lblfooter.Location = new System.Drawing.Point(74, 33);
            this.lblfooter.Name = "lblfooter";
            this.lblfooter.Size = new System.Drawing.Size(553, 19);
            this.lblfooter.TabIndex = 0;
            this.lblfooter.Text = "© 2025 Hệ Thống Quản Lý Sinh Viên - Được phát triển bởi Trần Dinh Hiển";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // Mainfrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackgroundImage = global::CSNQLSV.Properties.Resources.tvu;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(698, 648);
            this.Controls.Add(this.btnhd);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnkh);
            this.Controls.Add(this.btnnh);
            this.Controls.Add(this.btnpx);
            this.Controls.Add(this.btnbm);
            this.Controls.Add(this.btnk);
            this.Controls.Add(this.btnl);
            this.Controls.Add(this.btnht);
            this.Controls.Add(this.btnt);
            this.Controls.Add(this.btnsv);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Mainfrm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mainfrm";
            this.Load += new System.EventHandler(this.Mainfrm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnsv;
        private System.Windows.Forms.Button btnt;
        private System.Windows.Forms.Button btnht;
        private System.Windows.Forms.Button btnl;
        private System.Windows.Forms.Button btnbm;
        private System.Windows.Forms.Button btnpx;
        private System.Windows.Forms.Button btnnh;
        private System.Windows.Forms.Button btnkh;
        private System.Windows.Forms.Button btnhd;
        private System.Windows.Forms.Button btnk;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblfooter;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
    }
}