﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace CSNQLSV
{
    interface itfBoMon
    {
        void addBoMon();
        DataTable getdsBoMon();
        void deleteBoMon();
        void updateBoMon();
    }
    public abstract class AbstracBoMon
    {
        public abstract void addBoMon();
        public abstract DataTable getdsBoMon();
        public abstract void deleteBoMon();
        public abstract void updateBoMon();
    }
    public class BoMon:AbstracBoMon,itfBoMon
    {
        private string maBoMon;
        private string tenBoMon;
        private string makhoa;
        private string mota;

        ThaotacCSDL db;

        public string MaBoMon { get => maBoMon; set => maBoMon = value; }
        public string TenBoMon { get => tenBoMon; set => tenBoMon = value; }
        public string Makhoa { get => makhoa; set => makhoa = value; }
        public string Mota { get => mota; set => mota = value; }

        public BoMon():base()
        {
            db = new ThaotacCSDL();
        }
        public override void addBoMon()
        {
            string sql = string.Format("insert into  BoMon values('{0}',N'{1}','{2}',N'{3}' )", MaBoMon, TenBoMon, Makhoa,Mota);
            Console.WriteLine(sql);
            db.ExecuteNonQuery(sql);
        }
        public override DataTable getdsBoMon()
        {
            string sql = "select * from BoMon";
            DataTable dt = db.Execute(sql);
            return dt;
        }
        public override void deleteBoMon()
        {
            string sql = String.Format("Delete from BoMon where MaBM='{0}'", MaBoMon);
            Console.WriteLine(sql);
            db.ExecuteNonQuery(sql);
        }
        public override void updateBoMon()
        {
            string sql = String.Format("Update BoMon set MaBM='{0}', TenBoMon = N'{1}',MaKhoa ='{2}',MoTaBM = N'{3}' Where MaBM='{4}'", MaBoMon, TenBoMon, Makhoa,Mota, MaBoMon);
            Console.WriteLine(sql);
            db.ExecuteNonQuery(sql);
        }
    }
}
