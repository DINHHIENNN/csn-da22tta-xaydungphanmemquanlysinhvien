﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSNQLSV
{
    public partial class frmTinhThanh : Form
    {
        TinhThanh t;
        public frmTinhThanh()
        {
            InitializeComponent();
            t=new TinhThanh();
        }

        private void frmTinhThanh_Load(object sender, EventArgs e)
        {
            dgvtinh.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DataTable dtt = t.getdsTinhThanh();
            this.dgvtinh.DataSource = dtt;
            load(1);
            Hienthinut(2);   
            btnhuytinh.Enabled = false;
            this.dgvtinh.Columns["MaTT"].HeaderText = "Mã Tỉnh/Thành";
            this.dgvtinh.Columns["TenTT"].HeaderText = "Tên Tỉnh/Thành";
            dgvtinh.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dgvtinh.DefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Regular);
            Image timbmicon = Properties.Resources.tim;
            Image resizetimbmicon = new Bitmap(timbmicon, new Size(26, 26));
            btntimtinh.Image = resizetimbmicon;
        }
        public void Hienthinut(int x)
        {
            if (x == 1)
            {
                this.btnxoatinh.Enabled = true;
                this.btnsuatinh.Enabled = true;
                this.btnthemtinh.Enabled = true;
            }
            else if (x == 2)
            {
                this.btnxoatinh.Enabled = false;
                this.btnsuatinh.Enabled = false;
                this.btnthemtinh.Enabled = false;
            }

        }
        public void load(int x)
        {
            if (x == 1)
            {
                this.txtmatinh.Text = "Nhập mã tỉnh/thành";
                this.txttentinh.Text = "Nhập tên tỉnh/thành";               
                this.txtmatinh.ForeColor = Color.Gray;
                this.txttentinh.ForeColor = Color.Gray;
                this.ActiveControl = this.txtmatinh;
                this.btnhuytinh.Enabled = false;
            }
            else if (x == 2)
            {

                this.txtmatinh.ForeColor = Color.Black;
                this.txttentinh.ForeColor = Color.Black;
                this.ActiveControl = this.txtmatinh;
                this.btnhuytinh.Enabled = false;
            }

        }
        private void dgvtinh_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            if (index == dgvtinh.NewRowIndex || index < 0)
            {
                load(1);
                Hienthinut(2);
                MessageBox.Show("Dữ liệu rỗng!");
            }
            else
            {
                this.btnhuytinh.Enabled = true;
                Hienthinut(1);
                this.txtmatinh.ForeColor = Color.Black;
                this.txttentinh.ForeColor = Color.Black;
                this.txtmatinh.Text = dgvtinh.Rows[index].Cells[0].Value.ToString();
                this.txttentinh.Text = dgvtinh.Rows[index].Cells[1].Value.ToString();
            }
        }

        private void btnthemtinh_Click(object sender, EventArgs e)
        {
            try
            {
                int namtl;

                if (this.txtmatinh.Text == "Nhập mã tỉnh/thành" || this.txtmatinh.Text=="")
                {
                    MessageBox.Show("Vui lòng nhập Mã tỉnh!");
                    this.txtmatinh.Focus();
                }
                else if (this.txttentinh.Text == "Nhập tên tỉnh/thành" || this.txttentinh.Text=="")
                {
                    MessageBox.Show("Vui lòng nhập Tên tỉnh!");
                    this.txttentinh.Focus();
                }
                else
                {
                    t.Matt = this.txtmatinh.Text;
                    t.Tentt = this.txttentinh.Text;
                    t.addTinhThanh();
                    DataTable dtt = t.getdsTinhThanh();
                    dgvtinh.DataSource = dtt;
                    load(1);
                    MessageBox.Show("Dữ liệu đã được thêm thành công vào hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Tỉnh/Thành có mã {this.txtmatinh.Text} đã tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnxoatinh_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa dữ liệu này không?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                try
                {
                    if (this.txtmatinh.Text == "" || this.txtmatinh.Text == "Nhập mã tỉnh/thành")
                    {
                        MessageBox.Show("Bạn chưa nhập mã tỉnh/thành. Vui lòng điền thông tin trước khi tiếp tục.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        this.txtmatinh.Focus();
                        return;
                    }
                    DataTable dtt1 = t.getdsTinhThanh();
                    dgvtinh.DataSource = dtt1;
                    bool kt = false;
                    foreach (DataGridViewRow row in dgvtinh.Rows)
                    {
                        if (row.Cells["MaTT"].Value != null && row.Cells["MaTT"].Value.ToString().Trim() == txtmatinh.Text.Trim())
                        {
                            t.Matt = this.txtmatinh.Text;
                            t.deleteTinhThanh();
                            DataTable dtt = t.getdsTinhThanh();
                            dgvtinh.DataSource = dtt;
                            load(1);
                            MessageBox.Show("Dữ liệu đã được xóa thành công khỏi hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.btnhuytinh.Enabled = true;
                            kt = true;
                            break;
                        }
                    }
                    if (!kt)
                    {
                        MessageBox.Show($"Tỉnh/Thành có mã {this.txtmatinh.Text} không tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi người dùng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi không thể xóa dữ liệu !", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Hủy xóa dữ liệu.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnsuatinh_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.txtmatinh.Text == "" || this.txtmatinh.Text == "Nhập mã tỉnh/thành")
                {
                    MessageBox.Show("Bạn chưa nhập mã tỉnh/thành. Vui lòng điền thông tin trước khi tiếp tục.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    this.txtmatinh.Focus();
                    return;
                }

                DataTable dtt1 = t.getdsTinhThanh();
                dgvtinh.DataSource = dtt1;
                bool kt = false;
                int dem = 0;
                foreach (DataGridViewRow row in dgvtinh.Rows)
                {
                    if (row.Cells["MaTT"].Value != null && row.Cells["MaTT"].Value.ToString().Trim() == txtmatinh.Text.Trim())
                    {
                        if (this.txtmatinh.Text == "Nhập mã tỉnh/thành" || this.txtmatinh.Text == "")
                        {
                            this.txtmatinh.Text = row.Cells["MaTT"].Value.ToString();
                        }
                        if (this.txttentinh.Text == "Nhập tên tỉnh/thành" || this.txttentinh.Text == "")
                        {
                            this.txttentinh.Text = row.Cells["TenTT"].Value.ToString();
                            this.txttentinh.ForeColor = Color.Black;
                            dem += 1;
                        }
                        if (dem == 1)
                        {
                            MessageBox.Show("Chưa nhập thông tin cần cập nhật.\n\nVui lòng kiểm tra và thử lại.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.txtmatinh.Focus();
                            return;
                        }
                        t.Matt = this.txtmatinh.Text;
                        t.Tentt = this.txttentinh.Text;
                        t.updateTinhThanh();
                        DataTable dtt = t.getdsTinhThanh();
                        dgvtinh.DataSource = dtt;
                        load(1);
                        MessageBox.Show("Dữ liệu đã được cập nhật thành công vào hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        kt = true;
                        break;
                    }
                }
                if (!kt)
                {
                    MessageBox.Show($"Tỉnh/Thành có mã {this.txtmatinh.Text} không tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi người dùng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.txtmatinh.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Mã {this.txtmatinh.Text} không có trong CSDL!");
            }
        }

        private void btnhuytinh_Click(object sender, EventArgs e)
        {
            load(1);
            this.txttimtinh.Text = "";
            Hienthinut(2);
            this.btnhuytinh.Enabled = false;
        }

        private void btnthoattinh_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            this.Close();
        }


        private void Textchange(object sender, EventArgs e)
        {
            bool isMatinhEmpty = string.IsNullOrWhiteSpace(this.txtmatinh.Text) || this.txtmatinh.Text == "Nhập mã tỉnh/thành";
            bool isTentinhEmpty = string.IsNullOrWhiteSpace(this.txttentinh.Text) || this.txttentinh.Text == "Nhập tên tỉnh/thành";
            bool isTimtinhEmpty = string.IsNullOrEmpty(this.txttimtinh.Text);
            if (isMatinhEmpty && isTentinhEmpty)
            {
                if (isTimtinhEmpty)
                {
                    this.btnhuytinh.Enabled = false;
                }
                else
                {
                    this.btnhuytinh.Enabled = true;
                }
                Hienthinut(2);
            }
            else if (isMatinhEmpty || isTentinhEmpty )
            {
                if (isTimtinhEmpty)
                {
                    this.btnhuytinh.Enabled = true;
                }
                else
                {
                    this.btnhuytinh.Enabled = true;
                }
                Hienthinut(1);
            }
            else if (!isMatinhEmpty && !isTentinhEmpty )
            {

                if (isTimtinhEmpty)
                {
                    this.btnhuytinh.Enabled = true;
                }
                else
                {
                    this.btnhuytinh.Enabled = true;
                }
                Hienthinut(1);
            }
        }

        private void btntimtinh_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(this.txttimtinh.Text.Trim()))
            {
                MessageBox.Show("Vui lòng nhập từ khóa tìm kiếm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            DataTable dtt = t.getdsTinhThanh();
            dgvtinh.DataSource = dtt;
            bool kt = false;
            foreach (DataGridViewRow row in dgvtinh.Rows)
            {
                if (row.Cells["MaTT"].Value != null && row.Cells["MaTT"].Value.ToString().Trim() == txttimtinh.Text.Trim())
                {
                    this.txtmatinh.Text = row.Cells["MaTT"].Value.ToString();
                    this.txttentinh.Text = row.Cells["TenTT"].Value.ToString();
                    load(2);
                    kt = true;
                    break;
                }
            }
            if (!kt)
            {
                MessageBox.Show("Không tìm thấy thông tin tỉnh", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            this.btnhuytinh.Enabled = true;
        }

        private void txttimtinh_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btntimtinh_Click(sender, e);
            }

        }
        private void txt_Enter(object sender, EventArgs e)
        {
            TextBox tx = (TextBox)sender;
            if (tx.Text == this.txtmatinh.Text && tx.Text == "Nhập mã tỉnh/thành")
            {
                this.txtmatinh.Text = "";
                this.txtmatinh.ForeColor = Color.Black;
            }
            else if (tx.Text == this.txttentinh.Text && tx.Text == "Nhập tên tỉnh/thành")
            {
                this.txttentinh.Text = "";
                this.txttentinh.ForeColor = Color.Black;
            }
        }

        private void txt_Leave(object sender, EventArgs e)
        {
            TextBox tx = (TextBox)sender;
            if (string.IsNullOrWhiteSpace(this.txtmatinh.Text))
            {
                this.txtmatinh.Text = "Nhập mã tỉnh/thành";
                this.txtmatinh.ForeColor = Color.Gray;
            }
            else if (string.IsNullOrWhiteSpace(this.txttentinh.Text))
            {
                this.txttentinh.Text = "Nhập tên tỉnh/thành";
                this.txttentinh.ForeColor = Color.Gray;
            }
        }

        private void btn_MouseEnter(object sender, EventArgs e)
        {

            Button btn = (Button)sender;
            if (btn.Text == btnthemtinh.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnxoatinh.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnsuatinh.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnhuytinh.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnthoattinh.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
        }

        private void btn_MouseLeave(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.Text == btnthemtinh.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnxoatinh.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnsuatinh.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnhuytinh.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnthoattinh.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
        }

        private void dgvtinh_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
