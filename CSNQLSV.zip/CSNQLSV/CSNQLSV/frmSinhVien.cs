﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSNQLSV
{
    public partial class frmSinhVien : Form
    {
        SinhVien sv;
        Lop l;
        TinhThanh t;
        HuyenThi ht;
        PhuongXa px;
        Khoa k;
        public frmSinhVien()
        {
            InitializeComponent();
            sv = new SinhVien();
            l = new Lop();
            t = new TinhThanh();
            px = new PhuongXa();
            ht = new HuyenThi();
            k = new Khoa();
        }

        private void frmSinhVien_Load(object sender, EventArgs e)
        {
            dgvsv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DataTable dtsv = sv.getdsSinhVien();
            load(1);
            load_cb();
            this.dgvsv.DataSource = dtsv;
            dgvsv.Columns[4].DefaultCellStyle.Format = "dd/MM/yyyy";
            this.btnsuasv.Enabled = false;
            this.btnxoasv.Enabled = false;
           // btnluu.Visible = false;
            Hienthinut(2);

            dgvsv.Columns["MaSV"].HeaderText = "Mã Sinh Viên";
            dgvsv.Columns["TenSV"].HeaderText = "Tên Sinh Viên";
            dgvsv.Columns["HoSV"].HeaderText = "Họ Sinh Viên";
            dgvsv.Columns["GioiTinh"].HeaderText = "Giới Tính";
            dgvsv.Columns["NgaySinh"].HeaderText = "Ngày Sinh";
            dgvsv.Columns["Email"].HeaderText = "Email";
            dgvsv.Columns["SoDienThoai"].HeaderText = "Số điện thoại";
            dgvsv.Columns["NoiSinh"].HeaderText = "Nơi Sinh";
            dgvsv.Columns["DiaChi"].HeaderText = "Địa Chỉ";
            dgvsv.Columns["MaLop"].HeaderText = "Mã Lớp";
            dgvsv.Columns["MaPXa"].HeaderText = "Mã Phường/Xã";
            dgvsv.Columns["MaHT"].HeaderText = "Mã Huyện/Thị";
            dgvsv.Columns["MaTT"].HeaderText = "Mã Tỉnh/Thành";
            dgvsv.Columns["MaKhoa"].HeaderText = "Mã Khoa";
            dgvsv.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dgvsv.DefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Regular);
            Image timbmicon = Properties.Resources.tim;
            Image resizetimbmicon = new Bitmap(timbmicon, new Size(26, 26));
            btntimsv.Image = resizetimbmicon;

            //Image luuicon = Properties.Resources.luu;
            //Image resizeluuicon = new Bitmap(luuicon, new Size(16, 16));
            //btnluu.Image = resizeluuicon;
        }
        public void Hienthinut(int x)
        {
            if (x == 1)
            {
                this.btnxoasv.Enabled = true;
                this.btnsuasv.Enabled = true;
                this.btnthemsv.Enabled = true;
            }
            else if (x == 2)
            {
                this.btnxoasv.Enabled = false;
                this.btnsuasv.Enabled = false;
                this.btnthemsv.Enabled = false;
            }

        }
        public void load_cb()
        {
            load_cblop();
            load_cbtinh();
            load_cbht();
            load_cbpx();
            load_cbgt();
            load_cbkhoa();
        }
        public void load_cbkhoa()
        {
            DataTable dtk = k.getdsKhoa();
            DataRow dr = dtk.NewRow();
            dr[dtk.Columns[0].ColumnName] = DBNull.Value;
            dr[dtk.Columns[1].ColumnName] = "Chọn khoa";
            dtk.Rows.InsertAt(dr, 0);
            this.cbmakhoasv.DataSource = dtk;
            this.cbmakhoasv.ValueMember = dtk.Columns[0].ColumnName.ToString();
            this.cbmakhoasv.DisplayMember = dtk.Columns[1].ColumnName.ToString();
            cbmakhoasv.DrawMode = DrawMode.OwnerDrawFixed;
            cbmakhoasv.DrawItem += cbmakhoasv_DrawItem;
        }
        public void load_cblop()
        {
            DataTable dtl = l.getdsLop();
            DataRow dr = dtl.NewRow();
            dr[dtl.Columns[2].ColumnName] = DBNull.Value;
            dr[dtl.Columns[3].ColumnName] = "Chọn lớp học";
            dtl.Rows.InsertAt(dr, 0);
            this.cbmalopsv.DataSource = dtl;
            this.cbmalopsv.ValueMember = dtl.Columns[2].ColumnName.ToString();
            this.cbmalopsv.DisplayMember = dtl.Columns[3].ColumnName.ToString();
            cbmalopsv.DrawMode = DrawMode.OwnerDrawFixed;
            cbmalopsv.DrawItem += cbmalopsv_DrawItem;
        }
        public void load_cbtinh()
        {
            DataTable dtt = t.getdsTinhThanh();
            DataRow dr = dtt.NewRow();
            dr[dtt.Columns[0].ColumnName] = DBNull.Value;
            dr[dtt.Columns[1].ColumnName] = "Chọn tỉnh/thành";
            dtt.Rows.InsertAt(dr, 0);

            this.cbmatsv.DataSource = dtt;
            this.cbmatsv.ValueMember = dtt.Columns[0].ColumnName.ToString();
            this.cbmatsv.DisplayMember = dtt.Columns[1].ColumnName.ToString();
            cbmatsv.DrawMode = DrawMode.OwnerDrawFixed;
            cbmatsv.DrawItem += cbmatsv_DrawItem;
        }
        public void load_cbht()
        {
            DataTable dtht = ht.getdsHuyenThi();
            DataRow dr = dtht.NewRow();
            dr[dtht.Columns[0].ColumnName] = DBNull.Value;
            dr[dtht.Columns[2].ColumnName] = "Chọn huyện/thị";
            dtht.Rows.InsertAt(dr, 0);

            this.cbmahtsv.DataSource = dtht;
            this.cbmahtsv.ValueMember = dtht.Columns[0].ColumnName.ToString();
            this.cbmahtsv.DisplayMember = dtht.Columns[2].ColumnName.ToString();
            cbmahtsv.DrawMode = DrawMode.OwnerDrawFixed;
            cbmahtsv.DrawItem += cbmahtsv_DrawItem;
        }
        public void load_cbpx()
        {
            DataTable dtpx = px.getdsPhuongXa();
            DataRow dr = dtpx.NewRow();
            dr[dtpx.Columns[0].ColumnName] = DBNull.Value;
            dr[dtpx.Columns[1].ColumnName] = "Chọn phường/xã";
            dtpx.Rows.InsertAt(dr, 0);

            this.cbmapxsv.DataSource = dtpx;
            this.cbmapxsv.ValueMember = dtpx.Columns[0].ColumnName.ToString();
            this.cbmapxsv.DisplayMember = dtpx.Columns[1].ColumnName.ToString();
            cbmapxsv.DrawMode = DrawMode.OwnerDrawFixed;
            cbmapxsv.DrawItem += cbmapxsv_DrawItem;
        }
        public void load_cbgt()
        {
            DataTable dtgt = new DataTable();
            DataColumn col = new DataColumn();
            col.ColumnName = "ID";
            DataColumn col2 = new DataColumn();
            col2.ColumnName = "Gtinh";
            dtgt.Columns.Add(col);
            dtgt.Columns.Add(col2);

            DataRow dr = dtgt.NewRow();
            dr[0] = "-1"; dr[1] = "Chọn giới tính";
            DataRow dr1 = dtgt.NewRow();
            dr1[0] = "1"; dr1[1] = "Nam";
            DataRow dr2 = dtgt.NewRow();
            dr2[0] = "0"; dr2[1] = "Nữ";
            dtgt.Rows.Add(dr);
            dtgt.Rows.Add(dr1);
            dtgt.Rows.Add(dr2);

            this.cbgioisv.DataSource = dtgt;
            this.cbgioisv.ValueMember = dtgt.Columns[0].ColumnName.ToString();
            this.cbgioisv.DisplayMember = dtgt.Columns[1].ColumnName.ToString();
            cbgioisv.DrawMode = DrawMode.OwnerDrawFixed;
            cbgioisv.DrawItem += cbgioisv_DrawItem;
        }
        public void load(int x)
        {
            if (x == 1)
            {

                this.txtmasv.Text = "Nhập mã số sinh viên";
                this.txthosv.Text = "Nhập họ sinh viên";
                this.txttensv.Text = "Nhập tên sinh viên";
                this.txtngsinh.Text = "dd/MM/yyyy";
                this.txtemail.Text = "Nhập email";
                this.txtdienthoai.Text = "Nhập số điện thoại";
                this.txtnoisinh.Text = "Nhập nơi sinh";
                this.txtdiachi.Text = "Nhập địa chỉ";

                this.txtmasv.ForeColor = Color.Gray;
                this.txthosv.ForeColor = Color.Gray;
                this.txttensv.ForeColor = Color.Gray;
                this.txtngsinh.ForeColor = Color.Gray;
                this.txtemail.ForeColor = Color.Gray;
                this.txtdienthoai.ForeColor = Color.Gray;
                this.txtnoisinh.ForeColor = Color.Gray;
                this.txtdiachi.ForeColor = Color.Gray;
                this.ActiveControl = this.txtmasv;
                this.btnhuysv.Enabled = false;
            }
            else if (x == 2)
            {
                this.txtmasv.ForeColor = Color.Black;
                this.txthosv.ForeColor = Color.Black;
                this.txttensv.ForeColor = Color.Black;
                this.txtngsinh.ForeColor = Color.Black;
                this.txtemail.ForeColor = Color.Black;
                this.txtdienthoai.ForeColor = Color.Black;
                this.txtnoisinh.ForeColor = Color.Black;
                this.txtdiachi.ForeColor = Color.Black;

                this.ActiveControl = this.txtmasv;
                this.btnhuysv.Enabled = false;

            }

        }

        private void cbmalopsv_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            ComboBox comboBox = sender as ComboBox;
            string text = comboBox.GetItemText(comboBox.Items[e.Index]);


            Color textColor = text == "Chọn lớp học" ? Color.Gray : Color.Black;

            e.DrawBackground();
            using (Brush brush = new SolidBrush(textColor))
            {
                e.Graphics.DrawString(text, e.Font, brush, e.Bounds);
            }
            e.DrawFocusRectangle();
        }
        private void cbmatsv_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            ComboBox comboBox = sender as ComboBox;
            string text = comboBox.GetItemText(comboBox.Items[e.Index]);


            Color textColor = text == "Chọn tỉnh/thành" ? Color.Gray : Color.Black;

            e.DrawBackground();
            using (Brush brush = new SolidBrush(textColor))
            {
                e.Graphics.DrawString(text, e.Font, brush, e.Bounds);
            }
            e.DrawFocusRectangle();
        }

        private void cbmahtsv_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            ComboBox comboBox = sender as ComboBox;
            string text = comboBox.GetItemText(comboBox.Items[e.Index]);


            Color textColor = text == "Chọn huyện/thị" ? Color.Gray : Color.Black;

            e.DrawBackground();
            using (Brush brush = new SolidBrush(textColor))
            {
                e.Graphics.DrawString(text, e.Font, brush, e.Bounds);
            }
            e.DrawFocusRectangle();
        }

        private void cbmapxsv_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            ComboBox comboBox = sender as ComboBox;
            string text = comboBox.GetItemText(comboBox.Items[e.Index]);


            Color textColor = text == "Chọn phường/xã" ? Color.Gray : Color.Black;

            e.DrawBackground();
            using (Brush brush = new SolidBrush(textColor))
            {
                e.Graphics.DrawString(text, e.Font, brush, e.Bounds);
            }
            e.DrawFocusRectangle();
        }

        private void cbgioisv_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            ComboBox comboBox = sender as ComboBox;
            string text = comboBox.GetItemText(comboBox.Items[e.Index]);


            Color textColor = text == "Chọn giới tính" ? Color.Gray : Color.Black;

            e.DrawBackground();
            using (Brush brush = new SolidBrush(textColor))
            {
                e.Graphics.DrawString(text, e.Font, brush, e.Bounds);
            }
            e.DrawFocusRectangle();
        }

        private void dgvsv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int id = e.RowIndex;
            if (id == dgvsv.NewRowIndex || id < 0)
            {
                load(1);
                load_cb();
                Hienthinut(2);
                MessageBox.Show("Dữ liệu rỗng!");
            }
            else
            {
                this.btnhuysv.Enabled = true;
                Hienthinut(1);
                this.txtmasv.ForeColor = Color.Black;
                this.txthosv.ForeColor = Color.Black;
                this.txttensv.ForeColor = Color.Black;
                this.txtngsinh.ForeColor = Color.Black;
                this.txtemail.ForeColor = Color.Black;
                this.txtdienthoai.ForeColor = Color.Black;
                this.txtnoisinh.ForeColor = Color.Black;
                this.txtdiachi.ForeColor = Color.Black;

                this.txtmasv.Text = dgvsv.Rows[id].Cells[0].Value.ToString();
                this.txthosv.Text = dgvsv.Rows[id].Cells[1].Value.ToString();
                this.txttensv.Text = dgvsv.Rows[id].Cells[2].Value.ToString();


                DateTime dt = (DateTime)dgvsv.Rows[id].Cells[4].Value;
                this.txtngsinh.Text = dt.ToString("dd/MM/yyyy");
                this.txtemail.Text = dgvsv.Rows[id].Cells[5].Value.ToString();
                this.txtdienthoai.Text = dgvsv.Rows[id].Cells[6].Value.ToString();
                this.txtnoisinh.Text = dgvsv.Rows[id].Cells[7].Value.ToString();
                this.txtdiachi.Text = dgvsv.Rows[id].Cells[8].Value.ToString();

                this.cbgioisv.Text = dgvsv.Rows[id].Cells[3].Value.ToString().Trim();

                this.cbmakhoasv.SelectedValue = dgvsv.Rows[id].Cells[13].Value.ToString().Trim();
                this.cbmakhoasv.Text = this.cbmakhoasv.GetItemText(this.cbmakhoasv.SelectedItem);

                this.cbmalopsv.SelectedValue = dgvsv.Rows[id].Cells[9].Value.ToString().Trim();
                this.cbmalopsv.Text = this.cbmalopsv.GetItemText(this.cbmalopsv.SelectedItem);

                this.cbmapxsv.SelectedValue = dgvsv.Rows[id].Cells[10].Value.ToString().Trim();
                this.cbmapxsv.Text = this.cbmapxsv.GetItemText(this.cbmapxsv.SelectedItem);

                this.cbmahtsv.SelectedValue = dgvsv.Rows[id].Cells[11].Value.ToString().Trim();
                this.cbmahtsv.Text = this.cbmahtsv.GetItemText(this.cbmahtsv.SelectedItem);

                this.cbmatsv.SelectedValue = dgvsv.Rows[id].Cells[12].Value.ToString().Trim();
                this.cbmatsv.Text = this.cbmatsv.GetItemText(this.cbmatsv.SelectedItem);
                if (this.cbmatsv.SelectedIndex > 0)
                {
                    DataTable dtht = ht.getdsHuyenThi();
                    string mat = this.cbmatsv.SelectedValue.ToString().Trim();
                    this.dgvhtan.DataSource = dtht;
                    DataTable dtht2 = new DataTable();
                    DataColumn col = new DataColumn();
                    col.ColumnName = "MaHT";
                    DataColumn col2 = new DataColumn();
                    col2.ColumnName = "MaTT";
                    DataColumn col3 = new DataColumn();
                    col.ColumnName = "TenHT";
                    dtht2.Columns.Add(col);
                    dtht2.Columns.Add(col2);
                    dtht2.Columns.Add(col3);
                    DataRow d = dtht2.NewRow();
                    d[0] = "-1"; d[2] = "Chọn huyện/thị"; d[1] = "NULL";
                    dtht2.Rows.Add(d);
                    bool kt = false;
                    foreach (DataGridViewRow row in dgvhtan.Rows)
                    {
                        if (row.Cells["MaTT"].Value != null && row.Cells["MaTT"].Value.ToString().Trim() == mat)
                        {
                            DataRow d1 = dtht2.NewRow();
                            d1[0] = row.Cells["MaHT"].Value.ToString().Trim();
                            d1[1] = row.Cells["MaTT"].Value.ToString().Trim();
                            d1[2] = row.Cells["TenHT"].Value.ToString().Trim();
                            dtht2.Rows.Add(d1);
                        }
                    }
                    this.cbmahtsv.DataSource = dtht2;
                    this.cbmahtsv.ValueMember = dtht2.Columns[0].ColumnName.ToString();
                    this.cbmahtsv.DisplayMember = dtht2.Columns[2].ColumnName.ToString();
                    cbmahtsv.DrawMode = DrawMode.OwnerDrawFixed;
                    cbmahtsv.DrawItem += cbmahtsv_DrawItem;
                    this.cbmahtsv.SelectedValue = dgvsv.Rows[id].Cells[11].Value.ToString().Trim();
                    this.cbmahtsv.Text = this.cbmahtsv.GetItemText(this.cbmahtsv.SelectedItem);
                }
                if (this.cbmahtsv.SelectedIndex > 0)
                {
                    DataTable dtpx = px.getdsPhuongXa();
                    string maht = this.cbmahtsv.SelectedValue.ToString().Trim();
                    this.dgvhtan.DataSource = dtpx;
                    DataTable dtht2 = new DataTable();
                    DataColumn col = new DataColumn();
                    col.ColumnName = "MaPXa";
                    DataColumn col2 = new DataColumn();
                    col2.ColumnName = "TenPXa";
                    DataColumn col3 = new DataColumn();
                    col.ColumnName = "MaHT";
                    dtht2.Columns.Add(col);
                    dtht2.Columns.Add(col2);
                    dtht2.Columns.Add(col3);
                    DataRow d = dtht2.NewRow();
                    d[0] = "-1"; d[1] = "Chọn phường/xã"; d[2] = "NULL";
                    dtht2.Rows.Add(d);
                    bool kt = false;
                    foreach (DataGridViewRow row in dgvhtan.Rows)
                    {
                        if (row.Cells["MaHT"].Value != null && row.Cells["MaHT"].Value.ToString().Trim() == maht)
                        {
                            DataRow d1 = dtht2.NewRow();
                            d1[0] = row.Cells["MaPXa"].Value.ToString().Trim();
                            d1[1] = row.Cells["TenPXa"].Value.ToString().Trim();
                            d1[2] = row.Cells["MaHT"].Value.ToString().Trim();
                            dtht2.Rows.Add(d1);
                        }
                    }
                    this.cbmapxsv.DataSource = dtht2;
                    this.cbmapxsv.ValueMember = dtht2.Columns[0].ColumnName.ToString();
                    this.cbmapxsv.DisplayMember = dtht2.Columns[1].ColumnName.ToString();
                    cbmapxsv.DrawMode = DrawMode.OwnerDrawFixed;
                    cbmapxsv.DrawItem += cbmapxsv_DrawItem;
                    this.cbmapxsv.SelectedValue = dgvsv.Rows[id].Cells[10].Value.ToString().Trim();
                    this.cbmapxsv.Text = this.cbmapxsv.GetItemText(this.cbmapxsv.SelectedItem);
                }
            }

        }

        private void btnthemsv_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.txtmasv.Text == "Nhập mã số sinh viên" || this.txtmasv.Text == "")
                {
                    MessageBox.Show("Vui lòng nhập Mã sinh số sinh viên!");
                    this.txtmasv.Focus();
                }
                else if (this.txthosv.Text == "Nhập họ sinh viên" || this.txthosv.Text == "")
                {
                    MessageBox.Show("Vui lòng nhập Họ sinh viên!");
                    this.txthosv.Focus();
                }
                else if (this.txttensv.Text == "Nhập tên sinh viên" || this.txttensv.Text == "")
                {
                    MessageBox.Show("Vui lòng nhập Tên sinh viên!");
                    this.txttensv.Focus();
                }
                else if (this.txtngsinh.Text == "dd/MM/yyyy" || this.txtngsinh.Text == "")
                {
                    MessageBox.Show("Vui lòng nhập Ngày sinh sinh viên!");
                    this.txtngsinh.Focus();
                }
                else if (this.txtemail.Text == "Nhập email" || this.txtemail.Text == "")
                {
                    MessageBox.Show("Vui lòng nhập Email sinh viên!");
                    this.txtemail.Focus();
                }
                else if (this.txtdienthoai.Text == "Nhập số điện thoại" || this.txtdienthoai.Text == "")
                {
                    MessageBox.Show("Vui lòng nhập Số điện thoại sinh viên!");
                    this.txtdienthoai.Focus();
                }
                else if (this.txtnoisinh.Text == "Nhập nơi sinh" || this.txtnoisinh.Text == "")
                {
                    MessageBox.Show("Vui lòng nhập Nơi sinh sinh viên!");
                    this.txtnoisinh.Focus();
                }
                else if (this.txtdiachi.Text == "Nhập địa chỉ" || this.txtdiachi.Text == "")
                {
                    MessageBox.Show("Vui lòng nhập Địa chỉ sinh viên!");
                    this.txtdiachi.Focus();
                }
                else if (this.cbmalopsv.Text == "Chọn lớp học" || this.cbmalopsv.Text == "")
                {
                    MessageBox.Show("Vui lòng chọn Lớp cho sinh viên!");
                }
                else if (this.cbmapxsv.Text == "Chọn phường/xã" || this.cbmapxsv.Text == "")
                {
                    MessageBox.Show("Vui lòng chọn Phường/Xã cho sinh viên!");
                }
                else if (this.cbmahtsv.Text == "Chọn huyện/thị" || this.cbmahtsv.Text == "")
                {
                    MessageBox.Show("Vui lòng chọn Huyện/Thị cho sinh viên!");
                }
                else if (this.cbmatsv.Text == "Chọn tỉnh/thành" || this.cbmatsv.Text == "")
                {
                    MessageBox.Show("Vui lòng chọn Tỉnh/Thị cho sinh viên!");
                }
                else if (this.cbgioisv.Text == "Chọn giới tính" || this.cbgioisv.Text == "")
                {
                    MessageBox.Show("Vui lòng chọn Giới tính cho sinh viên!");
                }
                else if (this.cbmakhoasv.Text == "Chọn khoa" || this.cbmakhoasv.Text == "")
                {
                    MessageBox.Show("Vui lòng chọn Khoa cho sinh viên!");
                }
                else
                {
                    sv.MaLop = this.cbmalopsv.SelectedValue.ToString().Trim();
                    sv.MaTT = this.cbmatsv.SelectedValue.ToString().Trim();
                    sv.MaHT = this.cbmahtsv.SelectedValue.ToString().Trim();
                    sv.MaPXa = this.cbmapxsv.SelectedValue.ToString().Trim();
                    sv.MaKhoa = this.cbmakhoasv.SelectedValue.ToString().Trim();
                    DateTime dt;
                    bool kt = DateTime.TryParseExact(this.txtngsinh.Text, "dd/MM/yyyy",
                        System.Globalization.CultureInfo.InvariantCulture,
                        System.Globalization.DateTimeStyles.None, out dt);
                    if (!kt)
                    {
                        MessageBox.Show("Ngày sinh không hợp lệ! Vui lòng nhập đúng định dạng dd/MM/yyyy.");
                        return;
                    }
                    sv.MaSV = this.txtmasv.Text;
                    sv.HoSV=this.txthosv.Text;
                    sv.TenSV=this.txttensv.Text;
                    sv.GioiTinh=this.cbgioisv.Text;
                    sv.NgaySinh=dt;
                    sv.Email=this.txtemail.Text;
                    sv.SoDienThoai=this.txtdienthoai.Text;
                    sv.NoiSinh=this.txtnoisinh.Text;
                    sv.DiaChi=this.txtdiachi.Text;
                    sv.addSinhVien();
                    DataTable dtsv = sv.getdsSinhVien();
                    dgvsv.DataSource = dtsv;
                    dgvsv.Columns["MaSV"].HeaderText = "Mã Sinh Viên";
                    dgvsv.Columns["TenSV"].HeaderText = "Tên Sinh Viên";
                    dgvsv.Columns["HoSV"].HeaderText = "Họ Sinh Viên";
                    dgvsv.Columns["GioiTinh"].HeaderText = "Giới Tính";
                    dgvsv.Columns["NgaySinh"].HeaderText = "Ngày Sinh";
                    dgvsv.Columns["Email"].HeaderText = "Email";
                    dgvsv.Columns["SoDienThoai"].HeaderText = "Số điện thoại";
                    dgvsv.Columns["NoiSinh"].HeaderText = "Nơi Sinh";
                    dgvsv.Columns["DiaChi"].HeaderText = "Địa Chỉ";
                    dgvsv.Columns["MaLop"].HeaderText = "Mã Lớp";
                    dgvsv.Columns["MaPXa"].HeaderText = "Mã Phường/Xã";
                    dgvsv.Columns["MaHT"].HeaderText = "Mã Huyện/Thị";
                    dgvsv.Columns["MaTT"].HeaderText = "Mã Tỉnh/Thành";
                    dgvsv.Columns["MaKhoa"].HeaderText = "Mã Khoa";
                    load(1);
                    load_cb();
                    MessageBox.Show("Dữ liệu đã được thêm thành công vào hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Mã số sinh viên {this.txtmasv.Text} đã tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnxoasv_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa dữ liệu này không?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                try
                {
                    if (this.txtmasv.Text == "Nhập mã số sinh viên" || this.txtmasv.Text == "")
                    {
                        MessageBox.Show("Bạn chưa nhập mã số sinh viên. Vui lòng điền thông tin trước khi tiếp tục.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        this.txtmasv.Focus();
                        return;
                    }
                    DataTable dtsv = sv.getdsSinhVien();
                    dgvsv.DataSource = dtsv;
                    bool kt=false;
                    foreach (DataGridViewRow row in dgvsv.Rows) 
                    {
                        if (row.Cells["MaSV"].Value != null && row.Cells["MaSV"].Value.ToString().Trim() == txtmasv.Text.Trim())
                        {
                            sv.MaSV = this.txtmasv.Text;
                            sv.deleteSinhVien();
                            DataTable dtsv1 = sv.getdsSinhVien();
                            dgvsv.DataSource = dtsv1;
                            dgvsv.Columns["MaSV"].HeaderText = "Mã Sinh Viên";
                            dgvsv.Columns["TenSV"].HeaderText = "Tên Sinh Viên";
                            dgvsv.Columns["HoSV"].HeaderText = "Họ Sinh Viên";
                            dgvsv.Columns["GioiTinh"].HeaderText = "Giới Tính";
                            dgvsv.Columns["NgaySinh"].HeaderText = "Ngày Sinh";
                            dgvsv.Columns["Email"].HeaderText = "Email";
                            dgvsv.Columns["SoDienThoai"].HeaderText = "Số điện thoại";
                            dgvsv.Columns["NoiSinh"].HeaderText = "Nơi Sinh";
                            dgvsv.Columns["DiaChi"].HeaderText = "Địa Chỉ";
                            dgvsv.Columns["MaLop"].HeaderText = "Mã Lớp";
                            dgvsv.Columns["MaPXa"].HeaderText = "Mã Phường/Xã";
                            dgvsv.Columns["MaHT"].HeaderText = "Mã Huyện/Thị";
                            dgvsv.Columns["MaTT"].HeaderText = "Mã Tỉnh/Thành";
                            dgvsv.Columns["MaKhoa"].HeaderText = "Mã Khoa";
                            load_cb();
                            MessageBox.Show("Dữ liệu đã được xóa thành công khỏi hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            load(1);
                            this.btnhuysv.Enabled = true;
                            kt = true;
                            break;
                        }
                    }
                    if (!kt)
                    {
                        dgvsv.Columns["MaSV"].HeaderText = "Mã Sinh Viên";
                        dgvsv.Columns["TenSV"].HeaderText = "Tên Sinh Viên";
                        dgvsv.Columns["HoSV"].HeaderText = "Họ Sinh Viên";
                        dgvsv.Columns["GioiTinh"].HeaderText = "Giới Tính";
                        dgvsv.Columns["NgaySinh"].HeaderText = "Ngày Sinh";
                        dgvsv.Columns["Email"].HeaderText = "Email";
                        dgvsv.Columns["SoDienThoai"].HeaderText = "Số điện thoại";
                        dgvsv.Columns["NoiSinh"].HeaderText = "Nơi Sinh";
                        dgvsv.Columns["DiaChi"].HeaderText = "Địa Chỉ";
                        dgvsv.Columns["MaLop"].HeaderText = "Mã Lớp";
                        dgvsv.Columns["MaPXa"].HeaderText = "Mã Phường/Xã";
                        dgvsv.Columns["MaHT"].HeaderText = "Mã Huyện/Thị";
                        dgvsv.Columns["MaTT"].HeaderText = "Mã Tỉnh/Thành";
                        dgvsv.Columns["MaKhoa"].HeaderText = "Mã Khoa";
                        MessageBox.Show($"Mã số sinh viên {this.txtmasv.Text} không tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi người dùng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi không thể xóa dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Hủy xóa dữ liệu.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void btnsuasv_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.txtmasv.Text == "Nhập mã số sinh viên" || this.txtmasv.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập mã số sinh viên. Vui lòng điền thông tin trước khi tiếp tục.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    this.txtmasv.Focus();
                    return;
                }
                DataTable dtsv = sv.getdsSinhVien();
                dgvsv.DataSource = dtsv;
                bool kt = false;
                int dem = 0;
                foreach (DataGridViewRow row in dgvsv.Rows)
                {
                    if (row.Cells["MaSV"].Value != null && row.Cells["MaSV"].Value.ToString().Trim() == this.txtmasv.Text.Trim())
                    {
                        if (this.txthosv.Text == "Nhập họ sinh viên" ||this.txthosv.Text=="")
                        {
                            this.txthosv.Text = row.Cells["HoSV"].Value.ToString();
                            this.txthosv.ForeColor = Color.Black;
                            dem += 1;
                        }

                        if (this.txttensv.Text == "Nhập tên sinh viên"|| this.txttensv.Text=="")
                        {
                            this.txttensv.Text = row.Cells["TenSV"].Value.ToString();
                            this.txttensv.ForeColor = Color.Black;
                            dem += 1;
                        }
                        if (this.txtngsinh.Text == "dd/MM/yyyy" || this.txtngsinh.Text == "")
                        {
                            DateTime dtns = (DateTime)row.Cells["NgaySinh"].Value;
                            this.txtngsinh.Text = dtns.ToString("dd/MM/yyyy");
                            this.txtngsinh.ForeColor = Color.Black;
                            dem += 1;
                        }
                        if (this.txtemail.Text == "Nhập email" || this.txtemail.Text == "")
                        {
                            this.txtemail.Text = row.Cells["Email"].Value.ToString();
                            this.txtemail.ForeColor = Color.Black;
                            dem += 1;
                        }
                        if (this.txtdienthoai.Text == "Nhập số điện thoại" || this.txtdienthoai.Text == "")
                        {
                            this.txtdienthoai.Text = row.Cells["SoDienThoai"].Value.ToString();
                            this.txtdienthoai.ForeColor = Color.Black;
                            dem += 1;
                        }
                        if (this.txtnoisinh.Text == "Nhập nơi sinh" || this.txtnoisinh.Text == "")
                        {
                            this.txtnoisinh.Text = row.Cells["NoiSinh"].Value.ToString();
                            this.txtnoisinh.ForeColor = Color.Black;
                            dem += 1;
                        }
                        if (this.txtdiachi.Text == "Nhập địa chỉ" || this.txtdiachi.Text == "")
                        {
                            this.txtdiachi.Text = row.Cells["DiaChi"].Value.ToString();
                            this.txtdiachi.ForeColor = Color.Black;
                            dem += 1;
                        }
                        if (this.cbmakhoasv.Text == "Chọn khoa" || this.cbmakhoasv.Text == "")
                        {
                            this.cbmakhoasv.SelectedValue = row.Cells["MaKhoa"].Value.ToString().Trim();
                            this.cbmakhoasv.Text = this.cbmakhoasv.GetItemText(this.cbmakhoasv.SelectedItem);
                            dem += 1;
                        }
                        if (this.cbgioisv.Text == "Chọn giới tính" || this.cbgioisv.Text == "")
                        {
                            cbgioisv.Text = row.Cells["GioiTinh"].Value.ToString();
                            dem += 1;
                        }
                        if (this.cbmalopsv.Text == "Chọn lớp học" || this.cbmalopsv.Text == "")
                        {
                            this.cbmalopsv.SelectedValue = row.Cells["MaLop"].Value.ToString().Trim();
                            this.cbmalopsv.Text = this.cbmalopsv.GetItemText(this.cbmalopsv.SelectedItem);
                            dem += 1;
                        }
                        if (this.cbmatsv.Text == "Chọn tỉnh/thành" || this.cbmatsv.Text == "")
                        {
                            this.cbmatsv.SelectedValue = row.Cells["MaTT"].Value.ToString().Trim();
                            this.cbmatsv.Text = this.cbmatsv.GetItemText(this.cbmatsv.SelectedItem);
                            dem += 1;
                        }
                        if (this.cbmahtsv.Text == "Chọn huyện/thị" || this.cbmahtsv.Text == "")
                        {
                            this.cbmahtsv.SelectedValue = row.Cells["MaHT"].Value.ToString().Trim();
                            this.cbmahtsv.Text = this.cbmahtsv.GetItemText(this.cbmahtsv.SelectedItem);
                            if (this.cbmatsv.SelectedIndex > 0)
                            {
                                DataTable dtht = ht.getdsHuyenThi();
                                string mat = this.cbmatsv.SelectedValue.ToString().Trim();
                                this.dgvhtan.DataSource = dtht;
                                DataTable dtht2 = new DataTable();
                                DataColumn col = new DataColumn();
                                col.ColumnName = "MaHT";
                                DataColumn col2 = new DataColumn();
                                col2.ColumnName = "MaTT";
                                DataColumn col3 = new DataColumn();
                                col.ColumnName = "TenHT";
                                dtht2.Columns.Add(col);
                                dtht2.Columns.Add(col2);
                                dtht2.Columns.Add(col3);
                                DataRow d = dtht2.NewRow();
                                d[0] = "-1"; d[2] = "Chọn huyện/thị"; d[1] = "NULL";
                                dtht2.Rows.Add(d);
                                //bool kt = false;
                                foreach (DataGridViewRow rowv in dgvhtan.Rows)
                                {
                                    if (rowv.Cells["MaTT"].Value != null && rowv.Cells["MaTT"].Value.ToString().Trim() == mat)
                                    {
                                        DataRow d1 = dtht2.NewRow();
                                        d1[0] = rowv.Cells["MaHT"].Value.ToString().Trim();
                                        d1[1] = rowv.Cells["MaTT"].Value.ToString().Trim();
                                        d1[2] = rowv.Cells["TenHT"].Value.ToString().Trim();
                                        dtht2.Rows.Add(d1);
                                    }
                                }
                                this.cbmahtsv.DataSource = dtht2;
                                this.cbmahtsv.ValueMember = dtht2.Columns[0].ColumnName.ToString();
                                this.cbmahtsv.DisplayMember = dtht2.Columns[2].ColumnName.ToString();
                                cbmahtsv.DrawMode = DrawMode.OwnerDrawFixed;
                                cbmahtsv.DrawItem += cbmahtsv_DrawItem;
                                this.cbmahtsv.SelectedValue = row.Cells["MaHT"].Value.ToString().Trim();
                                this.cbmahtsv.Text = this.cbmahtsv.GetItemText(this.cbmahtsv.SelectedItem);
                            }
                            dem += 1;
                        }
                        if (this.cbmapxsv.Text == "Chọn phường/xã")
                        {
                            this.cbmapxsv.SelectedValue = row.Cells["MaPXa"].Value.ToString().Trim();
                            this.cbmapxsv.Text = this.cbmapxsv.GetItemText(this.cbmapxsv.SelectedItem);
                            if (this.cbmahtsv.SelectedIndex > 0)
                            {
                                DataTable dtpx = px.getdsPhuongXa();
                                string maht = this.cbmahtsv.SelectedValue.ToString().Trim();
                                this.dgvhtan.DataSource = dtpx;
                                DataTable dtht2 = new DataTable();
                                DataColumn col = new DataColumn();
                                col.ColumnName = "MaPXa";
                                DataColumn col2 = new DataColumn();
                                col2.ColumnName = "TenPXa";
                                DataColumn col3 = new DataColumn();
                                col.ColumnName = "MaHT";
                                dtht2.Columns.Add(col);
                                dtht2.Columns.Add(col2);
                                dtht2.Columns.Add(col3);
                                DataRow d = dtht2.NewRow();
                                d[0] = "-1"; d[1] = "Chọn phường/xã"; d[2] = "NULL";
                                dtht2.Rows.Add(d);
                                foreach (DataGridViewRow row1 in dgvhtan.Rows)
                                {
                                    if (row1.Cells["MaHT"].Value != null && row1.Cells["MaHT"].Value.ToString().Trim() == maht)
                                    {
                                        DataRow d1 = dtht2.NewRow();
                                        d1[0] = row1.Cells["MaPXa"].Value.ToString().Trim();
                                        d1[1] = row1.Cells["TenPXa"].Value.ToString().Trim();
                                        d1[2] = row1.Cells["MaHT"].Value.ToString().Trim();
                                        dtht2.Rows.Add(d1);
                                    }
                                }
                                this.cbmapxsv.DataSource = dtht2;
                                this.cbmapxsv.ValueMember = dtht2.Columns[0].ColumnName.ToString();
                                this.cbmapxsv.DisplayMember = dtht2.Columns[1].ColumnName.ToString();
                                cbmapxsv.DrawMode = DrawMode.OwnerDrawFixed;
                                cbmapxsv.DrawItem += cbmapxsv_DrawItem;
                                this.cbmapxsv.SelectedValue = row.Cells["MaPXa"].Value.ToString().Trim();
                                this.cbmapxsv.Text = this.cbmapxsv.GetItemText(this.cbmapxsv.SelectedItem);
                            }
                            dem += 1;
                        }
                        DateTime dt;
                        bool kt1 = DateTime.TryParseExact(this.txtngsinh.Text, "dd/MM/yyyy",
                            System.Globalization.CultureInfo.InvariantCulture,
                            System.Globalization.DateTimeStyles.None, out dt);
                        if (!kt1 && txtngsinh.Text != "dd/MM/yyyy")
                        {
                            MessageBox.Show("Định dạng ngày sinh không chính xác. Vui lòng nhập theo định dạng dd/MM/yyyy.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            this.txtngsinh.Focus();
                            return;
                        }
                        if (dem==13)
                        {
                            MessageBox.Show("Chưa nhập thông tin cần cập nhật.\n\nVui lòng kiểm tra và thử lại.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }
                        sv.MaSV = this.txtmasv.Text;
                        sv.HoSV = this.txthosv.Text;
                        sv.TenSV = this.txttensv.Text;
                        sv.GioiTinh = this.cbgioisv.Text;
                        sv.NgaySinh = dt;
                        sv.Email = this.txtemail.Text;
                        sv.SoDienThoai = this.txtdienthoai.Text;
                        sv.NoiSinh = this.txtnoisinh.Text;
                        sv.DiaChi = this.txtdiachi.Text;
                        sv.MaLop = this.cbmalopsv.SelectedValue.ToString().Trim();
                        sv.MaTT = this.cbmatsv.SelectedValue.ToString().Trim();
                        sv.MaHT = this.cbmahtsv.SelectedValue.ToString().Trim();
                        sv.MaPXa = this.cbmapxsv.SelectedValue.ToString().Trim();
                        sv.MaKhoa = this.cbmakhoasv.SelectedValue.ToString().Trim();
                        sv.updateSinhVien();
                        DataTable dtsv1 = sv.getdsSinhVien();
                        dgvsv.DataSource = dtsv1;
                        dgvsv.Columns["MaSV"].HeaderText = "Mã Sinh Viên";
                        dgvsv.Columns["TenSV"].HeaderText = "Tên Sinh Viên";
                        dgvsv.Columns["HoSV"].HeaderText = "Họ Sinh Viên";
                        dgvsv.Columns["GioiTinh"].HeaderText = "Giới Tính";
                        dgvsv.Columns["NgaySinh"].HeaderText = "Ngày Sinh";
                        dgvsv.Columns["Email"].HeaderText = "Email";
                        dgvsv.Columns["SoDienThoai"].HeaderText = "Số điện thoại";
                        dgvsv.Columns["NoiSinh"].HeaderText = "Nơi Sinh";
                        dgvsv.Columns["DiaChi"].HeaderText = "Địa Chỉ";
                        dgvsv.Columns["MaLop"].HeaderText = "Mã Lớp";
                        dgvsv.Columns["MaPXa"].HeaderText = "Mã Phường/Xã";
                        dgvsv.Columns["MaHT"].HeaderText = "Mã Huyện/Thị";
                        dgvsv.Columns["MaTT"].HeaderText = "Mã Tỉnh/Thành";
                        dgvsv.Columns["MaKhoa"].HeaderText = "Mã Khoa";
                        load(1);
                        load_cb();
                        MessageBox.Show("Dữ liệu đã được cập nhật thành công vào hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        kt = true;
                        break;
                    }
                }
                if (!kt)
                {
                    dgvsv.Columns["MaSV"].HeaderText = "Mã Sinh Viên";
                    dgvsv.Columns["TenSV"].HeaderText = "Tên Sinh Viên";
                    dgvsv.Columns["HoSV"].HeaderText = "Họ Sinh Viên";
                    dgvsv.Columns["GioiTinh"].HeaderText = "Giới Tính";
                    dgvsv.Columns["NgaySinh"].HeaderText = "Ngày Sinh";
                    dgvsv.Columns["Email"].HeaderText = "Email";
                    dgvsv.Columns["SoDienThoai"].HeaderText = "Số điện thoại";
                    dgvsv.Columns["NoiSinh"].HeaderText = "Nơi Sinh";
                    dgvsv.Columns["DiaChi"].HeaderText = "Địa Chỉ";
                    dgvsv.Columns["MaLop"].HeaderText = "Mã Lớp";
                    dgvsv.Columns["MaPXa"].HeaderText = "Mã Phường/Xã";
                    dgvsv.Columns["MaHT"].HeaderText = "Mã Huyện/Thị";
                    dgvsv.Columns["MaTT"].HeaderText = "Mã Tỉnh/Thành";
                    dgvsv.Columns["MaKhoa"].HeaderText = "Mã Khoa";
                    MessageBox.Show($"Mã số sinh viên {this.txtmasv.Text} không tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi người dùng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi không cập nhật dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnhuysv_Click(object sender, EventArgs e)
        {
            load(1);
            load_cb();
            Hienthinut(2);
            this.txttimsv.Text = "";
            this.btnhuysv.Enabled = false;
            this.btnsuasv.Enabled = false;
            //this.btnluu.Visible = false;
            DataTable dtsv = sv.getdsSinhVien();
            this.dgvsv.DataSource = dtsv;
            dgvsv.Columns["MaSV"].HeaderText = "Mã Sinh Viên";
            dgvsv.Columns["TenSV"].HeaderText = "Tên Sinh Viên";
            dgvsv.Columns["HoSV"].HeaderText = "Họ Sinh Viên";
            dgvsv.Columns["GioiTinh"].HeaderText = "Giới Tính";
            dgvsv.Columns["NgaySinh"].HeaderText = "Ngày Sinh";
            dgvsv.Columns["Email"].HeaderText = "Email";
            dgvsv.Columns["SoDienThoai"].HeaderText = "Số điện thoại";
            dgvsv.Columns["NoiSinh"].HeaderText = "Nơi Sinh";
            dgvsv.Columns["DiaChi"].HeaderText = "Địa Chỉ";
            dgvsv.Columns["MaLop"].HeaderText = "Mã Lớp";
            dgvsv.Columns["MaPXa"].HeaderText = "Mã Phường/Xã";
            dgvsv.Columns["MaHT"].HeaderText = "Mã Huyện/Thị";
            dgvsv.Columns["MaTT"].HeaderText = "Mã Tỉnh/Thành";
            dgvsv.Columns["MaKhoa"].HeaderText = "Mã Khoa";
            dgvsv.Columns[4].DefaultCellStyle.Format = "dd/MM/yyyy";
        }

        private void btnthoatsv_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void btncapnhatlopsv_Click(object sender, EventArgs e)
        {
            frmLop frmlop = new frmLop();
            if (frmlop.ShowDialog() == DialogResult.OK)
            {
                if (this.txtmasv.Text != "Nhập mã số sinh viên" || this.txttensv.Text != "Nhập tên sinh viện" || this.txthosv.Text != "Nhập họ sinh viện" || this.cbgioisv.SelectedIndex != 0 || this.txtngsinh.Text !="dd/MM/yyyy"|| this.txtemail.Text!="Nhập email" || this.txtdienthoai.Text !="Nhập số điện thoại" || this.txtnoisinh.Text!="Nhập nơi sinh" || this.txtdiachi.Text!="Nhập địa chỉ" || this.cbmalopsv.SelectedIndex !=0 || this.cbmapxsv.SelectedIndex != 0 || this.cbmahtsv.SelectedIndex != 0 || this.cbmatsv.SelectedIndex != 0 || this.cbmakhoasv.SelectedIndex != 0)
                {
                    this.btnhuysv.Enabled = true;
                    Hienthinut(2);
                    btncapnhatlopsv.BackColor = Color.FromArgb(192, 236, 255);
                    btncapnhatlopsv.ForeColor = Color.Black;
                    if (cbmalopsv.SelectedIndex == 0)
                    {
                        cbmalopsv.ForeColor = Color.Gray;
                    }
                    else
                    {
                        cbmalopsv.ForeColor = Color.Black;
                    }
                }
                else
                {
                    Hienthinut(1);
                    this.btnthemsv.Enabled = true;
                    btncapnhatlopsv.BackColor = Color.FromArgb(192, 236, 255);
                    btncapnhatlopsv.ForeColor = Color.Black;
                }
            }
            load_cblop();
            btncapnhatlopsv.BackColor = Color.FromArgb(192, 236, 255);
            btncapnhatlopsv.ForeColor = Color.Black;
        }

        private void btncapnhatttsv_Click(object sender, EventArgs e)
        {
            frmTinhThanh frmtt = new frmTinhThanh();
            if (frmtt.ShowDialog() == DialogResult.OK)
            {
                if (this.txtmasv.Text != "Nhập mã số sinh viên" || this.txttensv.Text != "Nhập tên sinh viện" || this.txthosv.Text != "Nhập họ sinh viện" || this.cbgioisv.SelectedIndex != 0 || this.txtngsinh.Text != "dd/MM/yyyy" || this.txtemail.Text != "Nhập email" || this.txtdienthoai.Text != "Nhập số điện thoại" || this.txtnoisinh.Text != "Nhập nơi sinh" || this.txtdiachi.Text != "Nhập địa chỉ" || this.cbmalopsv.SelectedIndex != 0 || this.cbmapxsv.SelectedIndex != 0 || this.cbmahtsv.SelectedIndex != 0 || this.cbmatsv.SelectedIndex != 0 || this.cbmakhoasv.SelectedIndex != 0)
                {
                    this.btnhuysv.Enabled = true;
                    Hienthinut(2);
                    btncapnhatttsv.BackColor = Color.FromArgb(192, 236, 255);
                    btncapnhatttsv.ForeColor = Color.Black;
                    if (cbmatsv.SelectedIndex == 0)
                    {
                        cbmatsv.ForeColor = Color.Gray;
                    }
                    else
                    {
                        cbmatsv.ForeColor = Color.Black;
                    }
                }
                else
                {
                    Hienthinut(1);
                    this.btnthemsv.Enabled = true;
                    btncapnhatttsv.BackColor = Color.FromArgb(192, 236, 255);
                    btncapnhatttsv.ForeColor = Color.Black;
                }
            }
            load_cbtinh();
            btncapnhatttsv.BackColor = Color.FromArgb(192, 236, 255);
            btncapnhatttsv.ForeColor = Color.Black;
        }

        private void btncapnhathtsv_Click(object sender, EventArgs e)
        {
            frmHuyenThi frmht=new frmHuyenThi();
            if (frmht.ShowDialog() == DialogResult.OK)
            {
                if (this.txtmasv.Text != "Nhập mã số sinh viên" || this.txttensv.Text != "Nhập tên sinh viện" || this.txthosv.Text != "Nhập họ sinh viện" || this.cbgioisv.SelectedIndex != 0 || this.txtngsinh.Text != "dd/MM/yyyy" || this.txtemail.Text != "Nhập email" || this.txtdienthoai.Text != "Nhập số điện thoại" || this.txtnoisinh.Text != "Nhập nơi sinh" || this.txtdiachi.Text != "Nhập địa chỉ" || this.cbmalopsv.SelectedIndex != 0 || this.cbmapxsv.SelectedIndex != 0 || this.cbmahtsv.SelectedIndex != 0 || this.cbmatsv.SelectedIndex != 0 || this.cbmakhoasv.SelectedIndex != 0)
                {
                    this.btnhuysv.Enabled = true;
                    Hienthinut(2);
                    btncapnhathtsv.BackColor = Color.FromArgb(192, 236, 255);
                    btncapnhathtsv.ForeColor = Color.Black;
                    if (cbmahtsv.SelectedIndex == 0)
                    {
                        cbmahtsv.ForeColor = Color.Gray;
                    }
                    else
                    {
                        cbmahtsv.ForeColor = Color.Black;
                    }
                }
                else
                {
                    Hienthinut(1);
                    this.btnthemsv.Enabled = true;
                    btncapnhathtsv.BackColor = Color.FromArgb(192, 236, 255);
                    btncapnhathtsv.ForeColor = Color.Black;
                }
            }
            load_cbht();
            btncapnhathtsv.BackColor = Color.FromArgb(192, 236, 255);
            btncapnhathtsv.ForeColor = Color.Black;
        }

        private void btncapnhatpxsv_Click(object sender, EventArgs e)
        {
            frmPhuongXa frmpx=new frmPhuongXa();
            if (frmpx.ShowDialog() == DialogResult.OK)
            {
                if (this.txtmasv.Text != "Nhập mã số sinh viên" || this.txttensv.Text != "Nhập tên sinh viện" || this.txthosv.Text != "Nhập họ sinh viện" || this.cbgioisv.SelectedIndex != 0 || this.txtngsinh.Text != "dd/MM/yyyy" || this.txtemail.Text != "Nhập email" || this.txtdienthoai.Text != "Nhập số điện thoại" || this.txtnoisinh.Text != "Nhập nơi sinh" || this.txtdiachi.Text != "Nhập địa chỉ" || this.cbmalopsv.SelectedIndex != 0 || this.cbmapxsv.SelectedIndex != 0 || this.cbmahtsv.SelectedIndex != 0 || this.cbmatsv.SelectedIndex != 0|| this.cbmakhoasv.SelectedIndex != 0)
                {
                    this.btnhuysv.Enabled = true;
                    Hienthinut(2);
                    btncapnhatpxsv.BackColor = Color.FromArgb(192, 236, 255);
                    btncapnhatpxsv.ForeColor = Color.Black;
                    if (cbmapxsv.SelectedIndex == 0)
                    {
                        cbmapxsv.ForeColor = Color.Gray;
                    }
                    else
                    {
                        cbmapxsv.ForeColor = Color.Black;
                    }
                }
                else
                {
                    Hienthinut(1);
                    this.btnthemsv.Enabled = true;
                    btncapnhatpxsv.BackColor = Color.FromArgb(192, 236, 255);
                    btncapnhatpxsv.ForeColor = Color.Black;
                }
            }
            load_cbpx();
            btncapnhatpxsv.BackColor = Color.FromArgb(192, 236, 255);
            btncapnhatpxsv.ForeColor = Color.Black;
        }

        private void btntimsv_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(this.txttimsv.Text.Trim()))
            {
                MessageBox.Show("Vui lòng nhập từ khóa tìm kiếm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            DataTable dtsv = sv.getdsSinhVien();
            dgvsv.DataSource = dtsv;
            bool kt = false;
            bool load_tim = false;
            DataTable dt_tim=new DataTable();
            DataColumn col1= new DataColumn();
            col1.ColumnName = "MaSV";
            DataColumn col2 = new DataColumn();
            col2.ColumnName = "HoSV";
            DataColumn col3 = new DataColumn();
            col3.ColumnName = "TenSV";
            DataColumn col4 = new DataColumn();
            col4.ColumnName = "GioiTinh";
            DataColumn col5 = new DataColumn();
            col5.ColumnName = "NgaySinh";
            DataColumn col6 = new DataColumn();
            col6.ColumnName = "Email";
            DataColumn col7 = new DataColumn();
            col7.ColumnName = "SoDienThoai";
            DataColumn col8 = new DataColumn();
            col8.ColumnName = "NoiSinh";
            DataColumn col9 = new DataColumn();
            col9.ColumnName = "DiaChi";
            DataColumn col10 = new DataColumn();
            col10.ColumnName = "MaLop";
            DataColumn col11 = new DataColumn();
            col11.ColumnName = "MaPXa";
            DataColumn col12 = new DataColumn();
            col12.ColumnName = "MaHT";
            DataColumn col13 = new DataColumn();
            col13.ColumnName = "MaTT";
            DataColumn col14 = new DataColumn();
            col14.ColumnName = "MaKhoa";
            dt_tim.Columns.Add(col1);
            dt_tim.Columns.Add(col2);
            dt_tim.Columns.Add(col3);
            dt_tim.Columns.Add(col4);
            dt_tim.Columns.Add(col5);
            dt_tim.Columns.Add(col6);
            dt_tim.Columns.Add(col7);
            dt_tim.Columns.Add(col8);
            dt_tim.Columns.Add(col9);
            dt_tim.Columns.Add(col10);
            dt_tim.Columns.Add(col11);
            dt_tim.Columns.Add(col12);
            dt_tim.Columns.Add(col13);
            dt_tim.Columns.Add(col14);

            foreach (DataGridViewRow row in dgvsv.Rows)
            {

                if (row.Cells["MaSV"].Value != null && row.Cells["MaSV"].Value.ToString().Trim() == txttimsv.Text.Trim())
                {
                    DataRow dr = dt_tim.NewRow();
                    dr["MaSV"] = row.Cells["MaSV"].Value.ToString();
                    dr["TenSV"] = row.Cells["TenSV"].Value.ToString();
                    dr["HoSV"] = row.Cells["HoSV"].Value.ToString();
                    DateTime dt = (DateTime)row.Cells["NgaySinh"].Value;
                    dr["NgaySinh"] = dt.ToString("dd/MM/yyyy");
                    dr["Email"] = row.Cells["Email"].Value.ToString();
                    dr["SoDienThoai"] = row.Cells["SoDienThoai"].Value.ToString();
                    dr["NoiSinh"] = row.Cells["NoiSinh"].Value.ToString();
                    dr["DiaChi"] = row.Cells["DiaChi"].Value.ToString();
                    dr["GioiTinh"] = row.Cells["GioiTinh"].Value.ToString();
                    dr["MaLop"] = row.Cells["MaLop"].Value.ToString();
                    dr["MaTT"] = row.Cells["MaTT"].Value.ToString();
                    dr["MaHT"] = row.Cells["MaHT"].Value.ToString();
                    dr["MaPXa"] = row.Cells["MaPXa"].Value.ToString();
                    dr["MaKhoa"] = row.Cells["MaKhoa"].Value.ToString();
                    dt_tim.Rows.Add(dr);
                    kt = true;
                    load_tim = true;
                } else if ((row.Cells["MaLop"].Value != null && row.Cells["MaLop"].Value.ToString().Trim() == txttimsv.Text.Trim()) || (row.Cells["HoSV"].Value != null && row.Cells["HoSv"].Value.ToString().Trim() == txttimsv.Text.Trim()) || (row.Cells["TenSV"].Value != null && row.Cells["TenSV"].Value.ToString().Trim() == txttimsv.Text.Trim()) || (row.Cells["HoSV"].Value != null && row.Cells["TenSV"].Value != null  && ((row.Cells["HoSV"].Value.ToString().Trim() +" "+ row.Cells["TenSV"].Value.ToString().Trim())== txttimsv.Text.Trim())))
                {
                    DataRow dr = dt_tim.NewRow();
                    dr["MaSV"] = row.Cells["MaSV"].Value.ToString();
                    dr["TenSV"] = row.Cells["TenSV"].Value.ToString();
                    dr["HoSV"] = row.Cells["HoSV"].Value.ToString();
                    DateTime dt = (DateTime)row.Cells["NgaySinh"].Value;
                    dr["NgaySinh"] = dt.ToString("dd/MM/yyyy");
                    dr["Email"] = row.Cells["Email"].Value.ToString();
                    dr["SoDienThoai"] = row.Cells["SoDienThoai"].Value.ToString();
                    dr["NoiSinh"] = row.Cells["NoiSinh"].Value.ToString();
                    dr["DiaChi"] = row.Cells["DiaChi"].Value.ToString();
                    dr["GioiTinh"] = row.Cells["GioiTinh"].Value.ToString();
                    dr["MaLop"] = row.Cells["MaLop"].Value.ToString();
                    dr["MaTT"] = row.Cells["MaTT"].Value.ToString();
                    dr["MaHT"] = row.Cells["MaHT"].Value.ToString();
                    dr["MaPXa"] = row.Cells["MaPXa"].Value.ToString();
                    dr["MaKhoa"] = row.Cells["MaKhoa"].Value.ToString();
                    dt_tim.Rows.Add(dr);
                    kt = true;
                    load_tim = true;
                    //btnluu.Visible = true;
                }
            }
            this.dgvsv.DataSource = dt_tim;
            if (!kt)
            {
                MessageBox.Show("Không tìm thấy thông tin sinh viên", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            this.btnhuysv.Enabled = true;
        }

        private void txttimsv_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) { 
                btntimsv_Click(sender, e);
            }
        }

        private void Textchange(object sender, EventArgs e)
        {
            bool isMasvEmpty = string.IsNullOrWhiteSpace(this.txtmasv.Text) || this.txtmasv.Text == "Nhập mã số sinh viên";
            bool isTensvEmpty = string.IsNullOrWhiteSpace(this.txttensv.Text) || this.txttensv.Text == "Nhập tên sinh viên";
            bool isHosvEmpty = string.IsNullOrWhiteSpace(this.txthosv.Text) || this.txthosv.Text == "Nhập họ sinh viên";
            bool isNgsinhEmpty = string.IsNullOrWhiteSpace(this.txtngsinh.Text) || this.txtngsinh.Text == "dd/MM/yyyy";
            bool isEmailEmpty = string.IsNullOrWhiteSpace(this.txtemail.Text) || this.txtemail.Text == "Nhập email";
            bool isSdtsvEmpty = string.IsNullOrWhiteSpace(this.txtdienthoai.Text) || this.txtdienthoai.Text == "Nhập số điện thoại";
            bool isNoiSinhsvEmpty = string.IsNullOrWhiteSpace(this.txtnoisinh.Text) || this.txtnoisinh.Text == "Nhập nơi sinh";
            bool isDcsvEmpty = string.IsNullOrWhiteSpace(this.txtdiachi.Text) || this.txtdiachi.Text == "Nhập địa chỉ";

            bool isTimsvEmpty = string.IsNullOrWhiteSpace(this.txttimsv.Text);

            bool isCbgtNotSelected = this.cbgioisv.SelectedIndex == 0;
            bool isCblopNotSelected = this.cbmalopsv.SelectedIndex == 0;
            bool isCbtinhNotSelected = this.cbmatsv.SelectedIndex == 0;
            bool isCbhtNotSelected = this.cbmahtsv.SelectedIndex == 0;
            bool isCbpxNotSelected = this.cbmapxsv.SelectedIndex == 0;
            bool isCbkhoaNotSelected = this.cbmakhoasv.SelectedIndex == 0;
            if (cbmakhoasv.SelectedIndex == 0)
                cbmakhoasv.ForeColor = Color.Gray;
            else
                cbmakhoasv.ForeColor = Color.Black;
            if (cbmalopsv.SelectedIndex == 0)
                cbmalopsv.ForeColor = Color.Gray;
            else
                cbmalopsv.ForeColor = Color.Black;
            if (cbmapxsv.SelectedIndex == 0)
                cbmapxsv.ForeColor = Color.Gray;
            else
                cbmapxsv.ForeColor = Color.Black;
            if (cbmahtsv.SelectedIndex == 0)
                cbmahtsv.ForeColor = Color.Gray;
            else
                cbmahtsv.ForeColor = Color.Black;
            if (cbmatsv.SelectedIndex == 0)
                cbmatsv.ForeColor = Color.Gray;
            else
                cbmatsv.ForeColor = Color.Black;
            if (cbgioisv.SelectedIndex == 0)
                cbgioisv.ForeColor = Color.Gray;
            else
                cbgioisv.ForeColor = Color.Black;
            if (isCbkhoaNotSelected && isMasvEmpty && isTensvEmpty && isHosvEmpty && isNgsinhEmpty && isEmailEmpty && isSdtsvEmpty && isNoiSinhsvEmpty && isDcsvEmpty && isCbgtNotSelected && isCblopNotSelected && isCbtinhNotSelected && isCbhtNotSelected && isCbpxNotSelected)
            {
                if (isTimsvEmpty)
                {
                    this.btnhuysv.Enabled = false;
                    DataTable dtsv = sv.getdsSinhVien();
                    dgvsv.DataSource = dtsv;
                    dgvsv.Columns[4].DefaultCellStyle.Format = "dd/MM/yyyy";

                }
                else
                {
                    this.btnhuysv.Enabled = true;
                }
                Hienthinut(2);
            }
            else if (isCbkhoaNotSelected || isMasvEmpty || isTensvEmpty || isHosvEmpty || isNgsinhEmpty || isEmailEmpty || isSdtsvEmpty || isNoiSinhsvEmpty || isDcsvEmpty || isCbgtNotSelected || isCblopNotSelected || isCbtinhNotSelected || isCbhtNotSelected || isCbpxNotSelected)
            {
                if (isTimsvEmpty)
                {
                    this.btnhuysv.Enabled = true;
                }
                else
                {
                    this.btnhuysv.Enabled = true;
                }
                Hienthinut(1);
            }
            else if (!isCbkhoaNotSelected && !isMasvEmpty && !isTensvEmpty && !isHosvEmpty && !isNgsinhEmpty && !isEmailEmpty && !isSdtsvEmpty && !isNoiSinhsvEmpty && !isDcsvEmpty && !isCbgtNotSelected && !isCblopNotSelected && !isCbtinhNotSelected && !isCbhtNotSelected && !isCbpxNotSelected)
            {

                if (isTimsvEmpty)
                {
                    this.btnhuysv.Enabled = true;
                }
                else
                {
                    this.btnhuysv.Enabled = true;
                }
                Hienthinut(1);
            }
        }

        private void cbgioisv_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void cbmatsv_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled= true;
        }

        private void cbmalopsv_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void cbmahtsv_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void cbmapxsv_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void txt_Enter(object sender, EventArgs e)
        {
            TextBox tx = (TextBox)sender;
            if (tx.Text == this.txtmasv.Text && tx.Text == "Nhập mã số sinh viên")
            {
                this.txtmasv.Text = "";
                this.txtmasv.ForeColor = Color.Black;
            }
            else if (tx.Text == this.txttensv.Text && tx.Text == "Nhập tên sinh viên")
            {
                this.txttensv.Text = "";
                this.txttensv.ForeColor = Color.Black;
            }
            if (tx.Text == this.txthosv.Text && tx.Text == "Nhập họ sinh viên")
            {
                this.txthosv.Text = "";
                this.txthosv.ForeColor = Color.Black;
            }
            else if (tx.Text == this.txtemail.Text && tx.Text == "Nhập email")
            {
                this.txtemail.Text = "";
                this.txtemail.ForeColor = Color.Black;
            }
            if (tx.Text == this.txtdienthoai.Text && tx.Text == "Nhập số điện thoại")
            {
                this.txtdienthoai.Text = "";
                this.txtdienthoai.ForeColor = Color.Black;
            }
            else if (tx.Text == this.txtngsinh.Text && tx.Text == "Nhập ngày sinh")
            {
                this.txtngsinh.Text = "";
                this.txtngsinh.ForeColor = Color.Black;
            }
            if (tx.Text == this.txtnoisinh.Text && tx.Text == "Nhập nơi sinh")
            {
                this.txtnoisinh.Text = "";
                this.txtnoisinh.ForeColor = Color.Black;
            }
            else if (tx.Text == this.txtdiachi.Text && tx.Text == "Nhập địa chỉ")
            {
                this.txtdiachi.Text = "";
                this.txtdiachi.ForeColor = Color.Black;
            }
        }

        private void txt_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(this.txtmasv.Text))
            {
                this.txtmasv.Text = "Nhập mã số sinh viên";
                this.txtmasv.ForeColor = Color.Gray;
            }
            else if (string.IsNullOrWhiteSpace(this.txttensv.Text))
            {
                this.txttensv.Text = "Nhập tên sinh viên";
                this.txttensv.ForeColor = Color.Gray;
            }
            if (string.IsNullOrWhiteSpace(this.txthosv.Text))
            {
                this.txthosv.Text = "Nhập họ sinh viên";
                this.txthosv.ForeColor = Color.Gray;
            }
            else if (string.IsNullOrWhiteSpace(this.txtngsinh.Text))
            {
                this.txtngsinh.Text = "dd/MM/yyyy";
                this.txtngsinh.ForeColor = Color.Gray;
            }
            if (string.IsNullOrWhiteSpace(this.txtemail.Text))
            {
                this.txtemail.Text = "Nhập email";
                this.txtemail.ForeColor = Color.Gray;
            }
            else if (string.IsNullOrWhiteSpace(this.txtdienthoai.Text))
            {
                this.txtdienthoai.Text = "Nhập số điện thoại";
                this.txtdienthoai.ForeColor = Color.Gray;
            }
            if (string.IsNullOrWhiteSpace(this.txtnoisinh.Text))
            {
                this.txtnoisinh.Text = "Nhập nơi sinh";
                this.txtnoisinh.ForeColor = Color.Gray;
            }
            else if (string.IsNullOrWhiteSpace(this.txtdiachi.Text))
            {
                this.txtdiachi.Text = "Nhập địa chỉ";
                this.txtdiachi.ForeColor = Color.Gray;
            }
        }

        private void cbmahtsv_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.cbmahtsv.SelectedIndex > 0)
            {
                this.cbmapxsv.Enabled = true;
                DataTable dtpx = px.getdsPhuongXa();
                string maht = this.cbmahtsv.SelectedValue.ToString().Trim();
                this.dgvhtan.DataSource = dtpx;
                DataTable dtht2 = new DataTable();
                DataColumn col = new DataColumn();
                col.ColumnName = "MaPXa";
                DataColumn col2 = new DataColumn();
                col2.ColumnName = "TenPXa";
                DataColumn col3 = new DataColumn();
                col3.ColumnName = "MaHT";
                dtht2.Columns.Add(col);
                dtht2.Columns.Add(col2);
                dtht2.Columns.Add(col3);
                DataRow d = dtht2.NewRow();
                d[0] = "-1"; d[1] = "Chọn phường/xã"; d[2] = "NULL";
                dtht2.Rows.Add(d);
                bool kt = false;
                foreach (DataGridViewRow row in dgvhtan.Rows)
                {
                    if (row.Cells["MaHT"].Value != null && row.Cells["MaHT"].Value.ToString().Trim() == maht)
                    {
                        DataRow d1 = dtht2.NewRow();
                        d1[0] = row.Cells["MaPXa"].Value.ToString().Trim();
                        d1[1] = row.Cells["TenPXa"].Value.ToString().Trim();
                        d1[2] = row.Cells["MaHT"].Value.ToString().Trim();
                        dtht2.Rows.Add(d1);
                    }
                }
                this.cbmapxsv.DataSource = dtht2;
                this.cbmapxsv.ValueMember = dtht2.Columns[0].ColumnName.ToString();
                this.cbmapxsv.DisplayMember = dtht2.Columns[1].ColumnName.ToString();
                cbmapxsv.DrawMode = DrawMode.OwnerDrawFixed;
                cbmapxsv.DrawItem += cbmapxsv_DrawItem;
            }
            else
            {
                this.cbmapxsv.Enabled = false;
            }
        }

        private void cbmatsv_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.cbmatsv.SelectedIndex > 0)
            {
                this.cbmahtsv.Enabled = true;
                DataTable dtht = ht.getdsHuyenThi();
                string mat = this.cbmatsv.SelectedValue.ToString().Trim();
                this.dgvhtan.DataSource = dtht;
                DataTable dtht2 = new DataTable();
                DataColumn col = new DataColumn();
                col.ColumnName = "MaHT";
                DataColumn col2 = new DataColumn();
                col2.ColumnName = "MaTT";
                DataColumn col3 = new DataColumn();
                col3.ColumnName = "TenHT";
                dtht2.Columns.Add(col);
                dtht2.Columns.Add(col2);
                dtht2.Columns.Add(col3);
                DataRow d = dtht2.NewRow();
                d[0] = "-1"; d[2] = "Chọn huyện/thị"; d[1] = "NULL";
                dtht2.Rows.Add(d);
                bool kt = false;
                foreach (DataGridViewRow row in dgvhtan.Rows)
                {
                    if (row.Cells["MaTT"].Value != null && row.Cells["MaTT"].Value.ToString().Trim() == mat)
                    {
                        DataRow d1 = dtht2.NewRow();
                        d1[0] = row.Cells["MaHT"].Value.ToString().Trim();
                        d1[1] = row.Cells["MaTT"].Value.ToString().Trim();
                        d1[2] = row.Cells["TenHT"].Value.ToString().Trim();
                        dtht2.Rows.Add(d1);
                    }
                }
                this.cbmahtsv.DataSource = dtht2;
                this.cbmahtsv.ValueMember = dtht2.Columns[0].ColumnName.ToString();
                this.cbmahtsv.DisplayMember = dtht2.Columns[2].ColumnName.ToString();
                cbmahtsv.DrawMode = DrawMode.OwnerDrawFixed;
                cbmahtsv.DrawItem += cbmahtsv_DrawItem;
            }
            else
            {
                this.cbmahtsv.Enabled = false;
            }
        }

        private void btnthoatsv_Click_1(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnluu_Click(object sender, EventArgs e)
        {
            if (dgvsv.Rows.Count == 0)
            {
                MessageBox.Show("Dữ liệu rỗng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*";
            sfd.FileName = "DanhSachSinhVien.csv";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    using (StreamWriter sw = new StreamWriter(sfd.FileName, false, Encoding.UTF8))
                    {
                        for (int i = 0; i < dgvsv.Columns.Count; i++)
                        {
                            sw.Write(dgvsv.Columns[i].HeaderText);
                            if (i < dgvsv.Columns.Count - 1)
                                sw.Write(","); 
                        }
                        sw.WriteLine();
                        foreach (DataGridViewRow row in dgvsv.Rows)
                        {
                            if (!row.IsNewRow) 
                            {
                                for (int i = 0; i < dgvsv.Columns.Count; i++)
                                {

                                    if (dgvsv.Columns[i].Name == "NgaySinh" && row.Cells[i].Value != DBNull.Value)
                                    {
                                        DateTime ngaySinh = Convert.ToDateTime(row.Cells[i].Value);
                                        sw.Write(ngaySinh.ToString("dd/MM/yyyy"));
                                    }
                                    else
                                    {
                                        sw.Write(row.Cells[i].Value.ToString());
                                    }

                                    if (i < dgvsv.Columns.Count - 1)
                                        sw.Write(",");
                                }
                                sw.WriteLine();
                            }
                        }
                    }
                    MessageBox.Show("Xuất danh sách thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnluu.BackColor = Color.FromArgb(192, 236, 255);
                    btnluu.ForeColor = Color.Black;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi khi xuất danh sách: {ex.Message}", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void frmSinhVien_MouseEnter(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.Text == btnthemsv.Text)
            {
                btn.BackColor = Color.FromArgb(0,191,255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnxoasv.Text)
            {
                btn.BackColor = Color.FromArgb(103, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnsuasv.Text)
            {
                btn.BackColor = Color.FromArgb(103, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnhuysv.Text)
            {
                btn.BackColor = Color.FromArgb(103, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnthoatsv.Text)
            {
                btn.BackColor = Color.FromArgb(103, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btncapnhatlopsv.Text)
            {
                btn.BackColor = Color.FromArgb(103, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btncapnhatttsv.Text)
            {
                btn.BackColor = Color.FromArgb(103, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btncapnhathtsv.Text)
            {
                btn.BackColor = Color.FromArgb(103, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btncapnhatpxsv.Text)
            {
                btn.BackColor = Color.FromArgb(103, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnluu.Text)
            {
                btn.BackColor = Color.FromArgb(103, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btncapnhatkhoasv.Text)
            {
                btn.BackColor = Color.FromArgb(103, 191, 255);
                btn.ForeColor = Color.Black;
            }
        }

        private void frmSinhVien_MouseLeave(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.Text == btnthemsv.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnxoasv.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnsuasv.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnhuysv.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnthoatsv.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btncapnhatlopsv.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btncapnhatttsv.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btncapnhathtsv.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btncapnhatpxsv.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnluu.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btncapnhatkhoasv.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
        }

        private void cbmakhoasv_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            ComboBox comboBox = sender as ComboBox;
            string text = comboBox.GetItemText(comboBox.Items[e.Index]);


            Color textColor = text == "Chọn khoa" ? Color.Gray : Color.Black;

            e.DrawBackground();
            using (Brush brush = new SolidBrush(textColor))
            {
                e.Graphics.DrawString(text, e.Font, brush, e.Bounds);
            }
            e.DrawFocusRectangle();
        }

        private void cbmakhoasv_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void btncapnhatkhoasv_Click(object sender, EventArgs e)
        {
            frmKhoa frmkhoa = new frmKhoa();
            if (frmkhoa.ShowDialog() == DialogResult.OK)
            {
                if (this.txtmasv.Text != "Nhập mã số sinh viên" || this.txttensv.Text != "Nhập tên sinh viện" || this.txthosv.Text != "Nhập họ sinh viện" || this.cbgioisv.SelectedIndex != 0 || this.txtngsinh.Text != "dd/MM/yyyy" || this.txtemail.Text != "Nhập email" || this.txtdienthoai.Text != "Nhập số điện thoại" || this.txtnoisinh.Text != "Nhập nơi sinh" || this.txtdiachi.Text != "Nhập địa chỉ" || this.cbmalopsv.SelectedIndex != 0 || this.cbmapxsv.SelectedIndex != 0 || this.cbmahtsv.SelectedIndex != 0 || this.cbmatsv.SelectedIndex != 0 ||this.cbmakhoasv.SelectedIndex!=0)
                {
                    this.btnhuysv.Enabled = true;
                    Hienthinut(2);
                    btncapnhatkhoasv.BackColor = Color.FromArgb(192, 236, 255);
                    btncapnhatkhoasv.ForeColor = Color.Black;
                    if (cbmakhoasv.SelectedIndex == 0)
                    {
                        cbmakhoasv.ForeColor = Color.Gray;
                    }
                    else
                    {
                        cbmakhoasv.ForeColor = Color.Black;
                    }
                }
                else
                {
                    Hienthinut(1);
                    this.btnthemsv.Enabled = true;
                    btncapnhatkhoasv.BackColor = Color.FromArgb(192, 236, 255);
                    btncapnhatkhoasv.ForeColor = Color.Black;
                }
            }
            load_cblop();
            btncapnhatkhoasv.BackColor = Color.FromArgb(192, 236, 255);
            btncapnhatkhoasv.ForeColor = Color.Black;
        }
    }
}
