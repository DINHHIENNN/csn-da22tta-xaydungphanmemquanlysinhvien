﻿namespace CSNQLSV
{
    partial class frmLop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btncapnhatnhlop = new System.Windows.Forms.Button();
            this.dgvlop = new System.Windows.Forms.DataGridView();
            this.btntimlop = new System.Windows.Forms.Button();
            this.txttimlop = new System.Windows.Forms.TextBox();
            this.cbmanhlop = new System.Windows.Forms.ComboBox();
            this.btnxoalop = new System.Windows.Forms.Button();
            this.btnhuylop = new System.Windows.Forms.Button();
            this.btnthoatlop = new System.Windows.Forms.Button();
            this.btnsualop = new System.Windows.Forms.Button();
            this.btnthemlop = new System.Windows.Forms.Button();
            this.txttenlop = new System.Windows.Forms.TextBox();
            this.txtmalop = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cbmakhlop = new System.Windows.Forms.ComboBox();
            this.btncapnhatkhlop = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvlop)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btncapnhatnhlop
            // 
            this.btncapnhatnhlop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btncapnhatnhlop.Font = new System.Drawing.Font("Arial", 10F);
            this.btncapnhatnhlop.ForeColor = System.Drawing.Color.Black;
            this.btncapnhatnhlop.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btncapnhatnhlop.Location = new System.Drawing.Point(584, 156);
            this.btncapnhatnhlop.Name = "btncapnhatnhlop";
            this.btncapnhatnhlop.Size = new System.Drawing.Size(193, 33);
            this.btncapnhatnhlop.TabIndex = 53;
            this.btncapnhatnhlop.Text = "Cập nhật ngành học";
            this.btncapnhatnhlop.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btncapnhatnhlop.UseVisualStyleBackColor = false;
            this.btncapnhatnhlop.Click += new System.EventHandler(this.btncapnhatnhlop_Click);
            this.btncapnhatnhlop.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btncapnhatnhlop.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // dgvlop
            // 
            this.dgvlop.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvlop.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvlop.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvlop.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvlop.Location = new System.Drawing.Point(28, 38);
            this.dgvlop.Name = "dgvlop";
            this.dgvlop.RowHeadersWidth = 51;
            this.dgvlop.RowTemplate.Height = 24;
            this.dgvlop.Size = new System.Drawing.Size(867, 230);
            this.dgvlop.TabIndex = 58;
            this.dgvlop.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvlop_CellClick);
            // 
            // btntimlop
            // 
            this.btntimlop.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntimlop.Location = new System.Drawing.Point(856, 59);
            this.btntimlop.Name = "btntimlop";
            this.btntimlop.Size = new System.Drawing.Size(41, 37);
            this.btntimlop.TabIndex = 57;
            this.btntimlop.UseVisualStyleBackColor = true;
            this.btntimlop.Click += new System.EventHandler(this.btntimlop_Click);
            // 
            // txttimlop
            // 
            this.txttimlop.Font = new System.Drawing.Font("Arial", 10F);
            this.txttimlop.Location = new System.Drawing.Point(647, 65);
            this.txttimlop.Name = "txttimlop";
            this.txttimlop.Size = new System.Drawing.Size(203, 27);
            this.txttimlop.TabIndex = 56;
            this.txttimlop.TextChanged += new System.EventHandler(this.Textchange);
            this.txttimlop.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txttimlop_KeyDown);
            // 
            // cbmanhlop
            // 
            this.cbmanhlop.Font = new System.Drawing.Font("Arial", 10F);
            this.cbmanhlop.FormattingEnabled = true;
            this.cbmanhlop.Items.AddRange(new object[] {
            "Chọn mã khoa"});
            this.cbmanhlop.Location = new System.Drawing.Point(170, 160);
            this.cbmanhlop.Name = "cbmanhlop";
            this.cbmanhlop.Size = new System.Drawing.Size(405, 27);
            this.cbmanhlop.TabIndex = 55;
            this.cbmanhlop.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.cbnh_DrawItem);
            this.cbmanhlop.SelectedIndexChanged += new System.EventHandler(this.cbmanhlop_SelectedIndexChanged);
            this.cbmanhlop.TextChanged += new System.EventHandler(this.Textchange);
            this.cbmanhlop.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbmanhlop_KeyPress);
            // 
            // btnxoalop
            // 
            this.btnxoalop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnxoalop.Font = new System.Drawing.Font("Arial", 10F);
            this.btnxoalop.ForeColor = System.Drawing.Color.Black;
            this.btnxoalop.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnxoalop.Location = new System.Drawing.Point(204, 334);
            this.btnxoalop.Name = "btnxoalop";
            this.btnxoalop.Size = new System.Drawing.Size(90, 38);
            this.btnxoalop.TabIndex = 49;
            this.btnxoalop.Text = "Xóa";
            this.btnxoalop.UseVisualStyleBackColor = false;
            this.btnxoalop.Click += new System.EventHandler(this.btnxoalop_Click);
            this.btnxoalop.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnxoalop.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // btnhuylop
            // 
            this.btnhuylop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnhuylop.Font = new System.Drawing.Font("Arial", 10F);
            this.btnhuylop.ForeColor = System.Drawing.Color.Black;
            this.btnhuylop.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnhuylop.Location = new System.Drawing.Point(486, 334);
            this.btnhuylop.Name = "btnhuylop";
            this.btnhuylop.Size = new System.Drawing.Size(90, 38);
            this.btnhuylop.TabIndex = 50;
            this.btnhuylop.Text = "Hủy";
            this.btnhuylop.UseVisualStyleBackColor = false;
            this.btnhuylop.Click += new System.EventHandler(this.btnhuylop_Click);
            this.btnhuylop.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnhuylop.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // btnthoatlop
            // 
            this.btnthoatlop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnthoatlop.Font = new System.Drawing.Font("Arial", 10F);
            this.btnthoatlop.ForeColor = System.Drawing.Color.Black;
            this.btnthoatlop.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnthoatlop.Location = new System.Drawing.Point(776, 334);
            this.btnthoatlop.Name = "btnthoatlop";
            this.btnthoatlop.Size = new System.Drawing.Size(97, 38);
            this.btnthoatlop.TabIndex = 51;
            this.btnthoatlop.Text = "Thoát";
            this.btnthoatlop.UseVisualStyleBackColor = false;
            this.btnthoatlop.Click += new System.EventHandler(this.btnthoatlop_Click);
            this.btnthoatlop.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnthoatlop.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // btnsualop
            // 
            this.btnsualop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnsualop.Font = new System.Drawing.Font("Arial", 10F);
            this.btnsualop.ForeColor = System.Drawing.Color.Black;
            this.btnsualop.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnsualop.Location = new System.Drawing.Point(333, 334);
            this.btnsualop.Name = "btnsualop";
            this.btnsualop.Size = new System.Drawing.Size(112, 38);
            this.btnsualop.TabIndex = 52;
            this.btnsualop.Text = "Cập nhật";
            this.btnsualop.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnsualop.UseVisualStyleBackColor = false;
            this.btnsualop.Click += new System.EventHandler(this.btnsualop_Click);
            this.btnsualop.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnsualop.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // btnthemlop
            // 
            this.btnthemlop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnthemlop.Font = new System.Drawing.Font("Arial", 10F);
            this.btnthemlop.ForeColor = System.Drawing.Color.Black;
            this.btnthemlop.Location = new System.Drawing.Point(73, 334);
            this.btnthemlop.Name = "btnthemlop";
            this.btnthemlop.Size = new System.Drawing.Size(95, 38);
            this.btnthemlop.TabIndex = 54;
            this.btnthemlop.Text = "Thêm";
            this.btnthemlop.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnthemlop.UseVisualStyleBackColor = false;
            this.btnthemlop.Click += new System.EventHandler(this.btnthemlop_Click);
            this.btnthemlop.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnthemlop.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // txttenlop
            // 
            this.txttenlop.Font = new System.Drawing.Font("Arial", 10F);
            this.txttenlop.Location = new System.Drawing.Point(170, 75);
            this.txttenlop.Name = "txttenlop";
            this.txttenlop.Size = new System.Drawing.Size(405, 27);
            this.txttenlop.TabIndex = 47;
            this.txttenlop.TextChanged += new System.EventHandler(this.Textchange);
            this.txttenlop.Enter += new System.EventHandler(this.txt_Enter);
            this.txttenlop.Leave += new System.EventHandler(this.txt_Leave);
            // 
            // txtmalop
            // 
            this.txtmalop.Font = new System.Drawing.Font("Arial", 10F);
            this.txtmalop.Location = new System.Drawing.Point(170, 37);
            this.txtmalop.Name = "txtmalop";
            this.txtmalop.Size = new System.Drawing.Size(405, 27);
            this.txtmalop.TabIndex = 48;
            this.txtmalop.TextChanged += new System.EventHandler(this.Textchange);
            this.txtmalop.Enter += new System.EventHandler(this.txt_Enter);
            this.txtmalop.Leave += new System.EventHandler(this.txt_Leave);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 10F);
            this.label4.Location = new System.Drawing.Point(28, 78);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 19);
            this.label4.TabIndex = 44;
            this.label4.Text = "Tên Lớp";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 10F);
            this.label3.Location = new System.Drawing.Point(28, 164);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 19);
            this.label3.TabIndex = 45;
            this.label3.Text = "Ngành học";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 10F);
            this.label2.Location = new System.Drawing.Point(28, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 19);
            this.label2.TabIndex = 46;
            this.label2.Text = "Mã Lớp";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(344, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(221, 35);
            this.label1.TabIndex = 43;
            this.label1.Text = "QUẢN LÝ LỚP";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 10F);
            this.label5.Location = new System.Drawing.Point(28, 121);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 19);
            this.label5.TabIndex = 45;
            this.label5.Text = "Khóa học";
            // 
            // cbmakhlop
            // 
            this.cbmakhlop.Font = new System.Drawing.Font("Arial", 10F);
            this.cbmakhlop.FormattingEnabled = true;
            this.cbmakhlop.Items.AddRange(new object[] {
            "Chọn mã khoa"});
            this.cbmakhlop.Location = new System.Drawing.Point(170, 117);
            this.cbmakhlop.Name = "cbmakhlop";
            this.cbmakhlop.Size = new System.Drawing.Size(405, 27);
            this.cbmakhlop.TabIndex = 55;
            this.cbmakhlop.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.cbkh_DrawItem);
            this.cbmakhlop.SelectedIndexChanged += new System.EventHandler(this.cbmanhlop_SelectedIndexChanged);
            this.cbmakhlop.TextChanged += new System.EventHandler(this.Textchange);
            this.cbmakhlop.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbmakhlop_KeyPress);
            // 
            // btncapnhatkhlop
            // 
            this.btncapnhatkhlop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btncapnhatkhlop.Font = new System.Drawing.Font("Arial", 10F);
            this.btncapnhatkhlop.ForeColor = System.Drawing.Color.Black;
            this.btncapnhatkhlop.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btncapnhatkhlop.Location = new System.Drawing.Point(584, 114);
            this.btncapnhatkhlop.Name = "btncapnhatkhlop";
            this.btncapnhatkhlop.Size = new System.Drawing.Size(193, 33);
            this.btncapnhatkhlop.TabIndex = 53;
            this.btncapnhatkhlop.Text = "Cập nhật khóa học";
            this.btncapnhatkhlop.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btncapnhatkhlop.UseVisualStyleBackColor = false;
            this.btncapnhatkhlop.Click += new System.EventHandler(this.button1_Click);
            this.btncapnhatkhlop.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btncapnhatkhlop.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.cbmanhlop);
            this.groupBox1.Controls.Add(this.btncapnhatkhlop);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.btncapnhatnhlop);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtmalop);
            this.groupBox1.Controls.Add(this.txttenlop);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.cbmakhlop);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(73, 98);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(800, 215);
            this.groupBox1.TabIndex = 59;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "THÔNG TIN";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.dgvlop);
            this.groupBox2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 395);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(918, 287);
            this.groupBox2.TabIndex = 60;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "DANH SÁCH LỚP ";
            // 
            // frmLop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(244)))), ((int)(((byte)(251)))));
            this.ClientSize = new System.Drawing.Size(942, 694);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btntimlop);
            this.Controls.Add(this.txttimlop);
            this.Controls.Add(this.btnxoalop);
            this.Controls.Add(this.btnhuylop);
            this.Controls.Add(this.btnthoatlop);
            this.Controls.Add(this.btnsualop);
            this.Controls.Add(this.btnthemlop);
            this.Controls.Add(this.label1);
            this.Name = "frmLop";
            this.Text = "frmLop";
            this.Load += new System.EventHandler(this.frmLop_Load);
            this.TextChanged += new System.EventHandler(this.Textchange);
            this.Enter += new System.EventHandler(this.txt_Enter);
            this.Leave += new System.EventHandler(this.txt_Leave);
            ((System.ComponentModel.ISupportInitialize)(this.dgvlop)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button btncapnhatnhlop;
        private System.Windows.Forms.DataGridView dgvlop;
        private System.Windows.Forms.Button btntimlop;
        private System.Windows.Forms.TextBox txttimlop;
        private System.Windows.Forms.ComboBox cbmanhlop;
        private System.Windows.Forms.Button btnxoalop;
        private System.Windows.Forms.Button btnhuylop;
        private System.Windows.Forms.Button btnthoatlop;
        private System.Windows.Forms.Button btnsualop;
        private System.Windows.Forms.Button btnthemlop;
        private System.Windows.Forms.TextBox txttenlop;
        private System.Windows.Forms.TextBox txtmalop;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbmakhlop;
        public System.Windows.Forms.Button btncapnhatkhlop;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}