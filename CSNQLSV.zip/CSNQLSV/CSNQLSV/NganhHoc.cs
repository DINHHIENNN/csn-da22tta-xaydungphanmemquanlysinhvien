﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSNQLSV
{
    interface itfNganhHoc
    {
        void addNganhHoc();
        DataTable getdsNganhHoc();
        void deleteNganhHoc();
        void updateNganhHoc();
    }
    public abstract class AbstracNganhHoc
    {
        public abstract void addNganhHoc();
        public abstract DataTable getdsNganhHoc();
        public abstract void deleteNganhHoc();
        public abstract void updateNganhHoc();
    }
    public class NganhHoc:AbstracNganhHoc,itfNganhHoc
    {
        private string manh;
        private string tennh;
        private string mabm;
        ThaotacCSDL db;

        public string Manh { get => manh; set => manh = value; }
        public string Tennh { get => tennh; set => tennh = value; }
        public string Mabm { get => mabm; set => mabm = value; }

        public NganhHoc():base()
        {
            db = new ThaotacCSDL();
        }
        public override void addNganhHoc()
        {
            string sql = string.Format("insert into  NganhHoc values('{0}',N'{1}','{2}')", Manh,Tennh,Mabm);
            Console.WriteLine(sql);
            db.ExecuteNonQuery(sql);
        }
        public override DataTable getdsNganhHoc()
        {
            string sql = "select * from NganhHoc";
            DataTable dt = db.Execute(sql);
            return dt;
        }
        public override void deleteNganhHoc()
        {
            string sql = String.Format("Delete from NganhHoc where MaNH='{0}'", Manh);
            Console.WriteLine(sql);
            db.ExecuteNonQuery(sql);
        }
        public override void updateNganhHoc()
        {
            string sql = String.Format("Update NganhHoc set MaNH='{0}',TenNH = N'{1}',MaBM ='{2}' Where MaNH='{3}'", Manh, Tennh, Mabm,Manh);
            Console.WriteLine(sql);
            db.ExecuteNonQuery(sql);
        }
    }
}
