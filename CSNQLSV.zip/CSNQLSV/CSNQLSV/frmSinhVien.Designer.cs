﻿namespace CSNQLSV
{
    partial class frmSinhVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgvsv = new System.Windows.Forms.DataGridView();
            this.btntimsv = new System.Windows.Forms.Button();
            this.txttimsv = new System.Windows.Forms.TextBox();
            this.btnxoasv = new System.Windows.Forms.Button();
            this.btnhuysv = new System.Windows.Forms.Button();
            this.btnthoatsv = new System.Windows.Forms.Button();
            this.btnsuasv = new System.Windows.Forms.Button();
            this.btnthemsv = new System.Windows.Forms.Button();
            this.txthosv = new System.Windows.Forms.TextBox();
            this.txtmasv = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txttensv = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtngsinh = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtdienthoai = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtnoisinh = new System.Windows.Forms.TextBox();
            this.txtdiachi = new System.Windows.Forms.TextBox();
            this.cbmalopsv = new System.Windows.Forms.ComboBox();
            this.btncapnhatlopsv = new System.Windows.Forms.Button();
            this.cbmapxsv = new System.Windows.Forms.ComboBox();
            this.btncapnhatpxsv = new System.Windows.Forms.Button();
            this.cbmahtsv = new System.Windows.Forms.ComboBox();
            this.btncapnhathtsv = new System.Windows.Forms.Button();
            this.cbmatsv = new System.Windows.Forms.ComboBox();
            this.btncapnhatttsv = new System.Windows.Forms.Button();
            this.cbgioisv = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.dgvhtan = new System.Windows.Forms.DataGridView();
            this.btnluu = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btncapnhatkhoasv = new System.Windows.Forms.Button();
            this.cbmakhoasv = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvsv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvhtan)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvsv
            // 
            this.dgvsv.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvsv.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvsv.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvsv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvsv.Location = new System.Drawing.Point(24, 40);
            this.dgvsv.Name = "dgvsv";
            this.dgvsv.RowHeadersWidth = 51;
            this.dgvsv.RowTemplate.Height = 24;
            this.dgvsv.Size = new System.Drawing.Size(1105, 294);
            this.dgvsv.TabIndex = 77;
            this.dgvsv.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvsv_CellClick);
            // 
            // btntimsv
            // 
            this.btntimsv.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntimsv.Location = new System.Drawing.Point(1114, 55);
            this.btntimsv.Name = "btntimsv";
            this.btntimsv.Size = new System.Drawing.Size(41, 37);
            this.btntimsv.TabIndex = 76;
            this.btntimsv.UseVisualStyleBackColor = true;
            this.btntimsv.Click += new System.EventHandler(this.btntimsv_Click);
            // 
            // txttimsv
            // 
            this.txttimsv.Font = new System.Drawing.Font("Arial", 10F);
            this.txttimsv.Location = new System.Drawing.Point(840, 61);
            this.txttimsv.Name = "txttimsv";
            this.txttimsv.Size = new System.Drawing.Size(268, 27);
            this.txttimsv.TabIndex = 75;
            this.txttimsv.TextChanged += new System.EventHandler(this.Textchange);
            this.txttimsv.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txttimsv_KeyDown);
            // 
            // btnxoasv
            // 
            this.btnxoasv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnxoasv.Font = new System.Drawing.Font("Arial", 10F);
            this.btnxoasv.ForeColor = System.Drawing.Color.Black;
            this.btnxoasv.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnxoasv.Location = new System.Drawing.Point(198, 580);
            this.btnxoasv.Name = "btnxoasv";
            this.btnxoasv.Size = new System.Drawing.Size(93, 38);
            this.btnxoasv.TabIndex = 66;
            this.btnxoasv.Text = "Xóa";
            this.btnxoasv.UseVisualStyleBackColor = false;
            this.btnxoasv.Click += new System.EventHandler(this.btnxoasv_Click);
            this.btnxoasv.MouseEnter += new System.EventHandler(this.frmSinhVien_MouseEnter);
            this.btnxoasv.MouseLeave += new System.EventHandler(this.frmSinhVien_MouseLeave);
            // 
            // btnhuysv
            // 
            this.btnhuysv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnhuysv.Font = new System.Drawing.Font("Arial", 10F);
            this.btnhuysv.ForeColor = System.Drawing.Color.Black;
            this.btnhuysv.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnhuysv.Location = new System.Drawing.Point(462, 580);
            this.btnhuysv.Name = "btnhuysv";
            this.btnhuysv.Size = new System.Drawing.Size(93, 38);
            this.btnhuysv.TabIndex = 67;
            this.btnhuysv.Text = "Hủy";
            this.btnhuysv.UseVisualStyleBackColor = false;
            this.btnhuysv.Click += new System.EventHandler(this.btnhuysv_Click);
            this.btnhuysv.MouseEnter += new System.EventHandler(this.frmSinhVien_MouseEnter);
            this.btnhuysv.MouseLeave += new System.EventHandler(this.frmSinhVien_MouseLeave);
            // 
            // btnthoatsv
            // 
            this.btnthoatsv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnthoatsv.Font = new System.Drawing.Font("Arial", 10F);
            this.btnthoatsv.ForeColor = System.Drawing.Color.Black;
            this.btnthoatsv.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnthoatsv.Location = new System.Drawing.Point(1009, 580);
            this.btnthoatsv.Name = "btnthoatsv";
            this.btnthoatsv.Size = new System.Drawing.Size(93, 38);
            this.btnthoatsv.TabIndex = 68;
            this.btnthoatsv.Text = "Thoát";
            this.btnthoatsv.UseVisualStyleBackColor = false;
            this.btnthoatsv.Click += new System.EventHandler(this.btnthoatsv_Click_1);
            this.btnthoatsv.MouseEnter += new System.EventHandler(this.frmSinhVien_MouseEnter);
            this.btnthoatsv.MouseLeave += new System.EventHandler(this.frmSinhVien_MouseLeave);
            // 
            // btnsuasv
            // 
            this.btnsuasv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnsuasv.Font = new System.Drawing.Font("Arial", 10F);
            this.btnsuasv.ForeColor = System.Drawing.Color.Black;
            this.btnsuasv.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnsuasv.Location = new System.Drawing.Point(321, 580);
            this.btnsuasv.Name = "btnsuasv";
            this.btnsuasv.Size = new System.Drawing.Size(106, 38);
            this.btnsuasv.TabIndex = 69;
            this.btnsuasv.Text = "Cập nhật";
            this.btnsuasv.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnsuasv.UseVisualStyleBackColor = false;
            this.btnsuasv.Click += new System.EventHandler(this.btnsuasv_Click);
            this.btnsuasv.MouseEnter += new System.EventHandler(this.frmSinhVien_MouseEnter);
            this.btnsuasv.MouseLeave += new System.EventHandler(this.frmSinhVien_MouseLeave);
            // 
            // btnthemsv
            // 
            this.btnthemsv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnthemsv.Font = new System.Drawing.Font("Arial", 10F);
            this.btnthemsv.ForeColor = System.Drawing.Color.Black;
            this.btnthemsv.Location = new System.Drawing.Point(73, 580);
            this.btnthemsv.Name = "btnthemsv";
            this.btnthemsv.Size = new System.Drawing.Size(97, 38);
            this.btnthemsv.TabIndex = 72;
            this.btnthemsv.Text = "Thêm";
            this.btnthemsv.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnthemsv.UseVisualStyleBackColor = false;
            this.btnthemsv.Click += new System.EventHandler(this.btnthemsv_Click);
            this.btnthemsv.MouseEnter += new System.EventHandler(this.frmSinhVien_MouseEnter);
            this.btnthemsv.MouseLeave += new System.EventHandler(this.frmSinhVien_MouseLeave);
            // 
            // txthosv
            // 
            this.txthosv.Font = new System.Drawing.Font("Arial", 10F);
            this.txthosv.Location = new System.Drawing.Point(142, 72);
            this.txthosv.Name = "txthosv";
            this.txthosv.Size = new System.Drawing.Size(377, 27);
            this.txthosv.TabIndex = 64;
            this.txthosv.TextChanged += new System.EventHandler(this.Textchange);
            this.txthosv.Enter += new System.EventHandler(this.txt_Enter);
            this.txthosv.Leave += new System.EventHandler(this.txt_Leave);
            // 
            // txtmasv
            // 
            this.txtmasv.Font = new System.Drawing.Font("Arial", 10F);
            this.txtmasv.Location = new System.Drawing.Point(142, 34);
            this.txtmasv.Name = "txtmasv";
            this.txtmasv.Size = new System.Drawing.Size(377, 27);
            this.txtmasv.TabIndex = 65;
            this.txtmasv.TextChanged += new System.EventHandler(this.Textchange);
            this.txtmasv.Enter += new System.EventHandler(this.txt_Enter);
            this.txtmasv.Leave += new System.EventHandler(this.txt_Leave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(36, 160);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 19);
            this.label5.TabIndex = 62;
            this.label5.Text = "Giới tính";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(36, 78);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 19);
            this.label4.TabIndex = 60;
            this.label4.Text = "Họ SV";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(36, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 19);
            this.label3.TabIndex = 61;
            this.label3.Text = "Tên SV";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(36, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 19);
            this.label2.TabIndex = 63;
            this.label2.Text = "MSSV";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(422, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(349, 40);
            this.label1.TabIndex = 59;
            this.label1.Text = "QUẢN LÝ SINH VIÊN";
            // 
            // txttensv
            // 
            this.txttensv.Font = new System.Drawing.Font("Arial", 10F);
            this.txttensv.Location = new System.Drawing.Point(142, 112);
            this.txttensv.Name = "txttensv";
            this.txttensv.Size = new System.Drawing.Size(377, 27);
            this.txttensv.TabIndex = 64;
            this.txttensv.TextChanged += new System.EventHandler(this.Textchange);
            this.txttensv.Enter += new System.EventHandler(this.txt_Enter);
            this.txttensv.Leave += new System.EventHandler(this.txt_Leave);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(36, 201);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 19);
            this.label6.TabIndex = 62;
            this.label6.Text = "Ngày sinh";
            // 
            // txtngsinh
            // 
            this.txtngsinh.Font = new System.Drawing.Font("Arial", 10F);
            this.txtngsinh.Location = new System.Drawing.Point(142, 195);
            this.txtngsinh.Name = "txtngsinh";
            this.txtngsinh.Size = new System.Drawing.Size(377, 27);
            this.txtngsinh.TabIndex = 64;
            this.txtngsinh.TextChanged += new System.EventHandler(this.Textchange);
            this.txtngsinh.Enter += new System.EventHandler(this.txt_Enter);
            this.txtngsinh.Leave += new System.EventHandler(this.txt_Leave);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(36, 241);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 19);
            this.label7.TabIndex = 62;
            this.label7.Text = "Email";
            // 
            // txtemail
            // 
            this.txtemail.Font = new System.Drawing.Font("Arial", 10F);
            this.txtemail.Location = new System.Drawing.Point(142, 235);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(377, 27);
            this.txtemail.TabIndex = 64;
            this.txtemail.TextChanged += new System.EventHandler(this.Textchange);
            this.txtemail.Enter += new System.EventHandler(this.txt_Enter);
            this.txtemail.Leave += new System.EventHandler(this.txt_Leave);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(36, 289);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 19);
            this.label8.TabIndex = 62;
            this.label8.Text = "Điện thoại";
            // 
            // txtdienthoai
            // 
            this.txtdienthoai.Font = new System.Drawing.Font("Arial", 10F);
            this.txtdienthoai.Location = new System.Drawing.Point(142, 279);
            this.txtdienthoai.Name = "txtdienthoai";
            this.txtdienthoai.Size = new System.Drawing.Size(377, 27);
            this.txtdienthoai.TabIndex = 64;
            this.txtdienthoai.TextChanged += new System.EventHandler(this.Textchange);
            this.txtdienthoai.Enter += new System.EventHandler(this.txt_Enter);
            this.txtdienthoai.Leave += new System.EventHandler(this.txt_Leave);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(36, 332);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(70, 19);
            this.label9.TabIndex = 62;
            this.label9.Text = "Nơi sinh";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(36, 375);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 19);
            this.label10.TabIndex = 62;
            this.label10.Text = "Địa chỉ";
            // 
            // txtnoisinh
            // 
            this.txtnoisinh.Font = new System.Drawing.Font("Arial", 10F);
            this.txtnoisinh.Location = new System.Drawing.Point(142, 326);
            this.txtnoisinh.Name = "txtnoisinh";
            this.txtnoisinh.Size = new System.Drawing.Size(377, 27);
            this.txtnoisinh.TabIndex = 64;
            this.txtnoisinh.TextChanged += new System.EventHandler(this.Textchange);
            this.txtnoisinh.Enter += new System.EventHandler(this.txt_Enter);
            this.txtnoisinh.Leave += new System.EventHandler(this.txt_Leave);
            // 
            // txtdiachi
            // 
            this.txtdiachi.Font = new System.Drawing.Font("Arial", 10F);
            this.txtdiachi.Location = new System.Drawing.Point(142, 369);
            this.txtdiachi.Name = "txtdiachi";
            this.txtdiachi.Size = new System.Drawing.Size(377, 27);
            this.txtdiachi.TabIndex = 64;
            this.txtdiachi.TextChanged += new System.EventHandler(this.Textchange);
            this.txtdiachi.Enter += new System.EventHandler(this.txt_Enter);
            this.txtdiachi.Leave += new System.EventHandler(this.txt_Leave);
            // 
            // cbmalopsv
            // 
            this.cbmalopsv.Font = new System.Drawing.Font("Arial", 10F);
            this.cbmalopsv.FormattingEnabled = true;
            this.cbmalopsv.Items.AddRange(new object[] {
            "Chọn mã khoa"});
            this.cbmalopsv.Location = new System.Drawing.Point(670, 43);
            this.cbmalopsv.Name = "cbmalopsv";
            this.cbmalopsv.Size = new System.Drawing.Size(396, 27);
            this.cbmalopsv.TabIndex = 78;
            this.cbmalopsv.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.cbmalopsv_DrawItem);
            this.cbmalopsv.TextChanged += new System.EventHandler(this.Textchange);
            this.cbmalopsv.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbmalopsv_KeyPress);
            // 
            // btncapnhatlopsv
            // 
            this.btncapnhatlopsv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btncapnhatlopsv.Font = new System.Drawing.Font("Arial", 10F);
            this.btncapnhatlopsv.ForeColor = System.Drawing.Color.Black;
            this.btncapnhatlopsv.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btncapnhatlopsv.Location = new System.Drawing.Point(848, 76);
            this.btncapnhatlopsv.Name = "btncapnhatlopsv";
            this.btncapnhatlopsv.Size = new System.Drawing.Size(218, 38);
            this.btncapnhatlopsv.TabIndex = 79;
            this.btncapnhatlopsv.Text = "Cập nhật Lớp";
            this.btncapnhatlopsv.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btncapnhatlopsv.UseVisualStyleBackColor = false;
            this.btncapnhatlopsv.Click += new System.EventHandler(this.btncapnhatlopsv_Click);
            this.btncapnhatlopsv.MouseEnter += new System.EventHandler(this.frmSinhVien_MouseEnter);
            this.btncapnhatlopsv.MouseLeave += new System.EventHandler(this.frmSinhVien_MouseLeave);
            // 
            // cbmapxsv
            // 
            this.cbmapxsv.Enabled = false;
            this.cbmapxsv.Font = new System.Drawing.Font("Arial", 10F);
            this.cbmapxsv.FormattingEnabled = true;
            this.cbmapxsv.Items.AddRange(new object[] {
            "Chọn mã khoa"});
            this.cbmapxsv.Location = new System.Drawing.Point(670, 289);
            this.cbmapxsv.Name = "cbmapxsv";
            this.cbmapxsv.Size = new System.Drawing.Size(396, 27);
            this.cbmapxsv.TabIndex = 78;
            this.cbmapxsv.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.cbmapxsv_DrawItem);
            this.cbmapxsv.TextChanged += new System.EventHandler(this.Textchange);
            this.cbmapxsv.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbmapxsv_KeyPress);
            // 
            // btncapnhatpxsv
            // 
            this.btncapnhatpxsv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btncapnhatpxsv.Font = new System.Drawing.Font("Arial", 10F);
            this.btncapnhatpxsv.ForeColor = System.Drawing.Color.Black;
            this.btncapnhatpxsv.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btncapnhatpxsv.Location = new System.Drawing.Point(848, 322);
            this.btncapnhatpxsv.Name = "btncapnhatpxsv";
            this.btncapnhatpxsv.Size = new System.Drawing.Size(218, 38);
            this.btncapnhatpxsv.TabIndex = 79;
            this.btncapnhatpxsv.Text = "Cập nhật Phường/Xã";
            this.btncapnhatpxsv.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btncapnhatpxsv.UseVisualStyleBackColor = false;
            this.btncapnhatpxsv.Click += new System.EventHandler(this.btncapnhatpxsv_Click);
            this.btncapnhatpxsv.MouseEnter += new System.EventHandler(this.frmSinhVien_MouseEnter);
            this.btncapnhatpxsv.MouseLeave += new System.EventHandler(this.frmSinhVien_MouseLeave);
            // 
            // cbmahtsv
            // 
            this.cbmahtsv.Enabled = false;
            this.cbmahtsv.Font = new System.Drawing.Font("Arial", 10F);
            this.cbmahtsv.FormattingEnabled = true;
            this.cbmahtsv.Items.AddRange(new object[] {
            "Chọn mã khoa"});
            this.cbmahtsv.Location = new System.Drawing.Point(670, 207);
            this.cbmahtsv.Name = "cbmahtsv";
            this.cbmahtsv.Size = new System.Drawing.Size(396, 27);
            this.cbmahtsv.TabIndex = 78;
            this.cbmahtsv.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.cbmahtsv_DrawItem);
            this.cbmahtsv.SelectedIndexChanged += new System.EventHandler(this.cbmahtsv_SelectedIndexChanged);
            this.cbmahtsv.TextChanged += new System.EventHandler(this.Textchange);
            this.cbmahtsv.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbmahtsv_KeyPress);
            // 
            // btncapnhathtsv
            // 
            this.btncapnhathtsv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btncapnhathtsv.Font = new System.Drawing.Font("Arial", 10F);
            this.btncapnhathtsv.ForeColor = System.Drawing.Color.Black;
            this.btncapnhathtsv.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btncapnhathtsv.Location = new System.Drawing.Point(848, 240);
            this.btncapnhathtsv.Name = "btncapnhathtsv";
            this.btncapnhathtsv.Size = new System.Drawing.Size(218, 38);
            this.btncapnhathtsv.TabIndex = 79;
            this.btncapnhathtsv.Text = "Cập nhật Huyện/Thị";
            this.btncapnhathtsv.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btncapnhathtsv.UseVisualStyleBackColor = false;
            this.btncapnhathtsv.Click += new System.EventHandler(this.btncapnhathtsv_Click);
            this.btncapnhathtsv.MouseEnter += new System.EventHandler(this.frmSinhVien_MouseEnter);
            this.btncapnhathtsv.MouseLeave += new System.EventHandler(this.frmSinhVien_MouseLeave);
            // 
            // cbmatsv
            // 
            this.cbmatsv.Font = new System.Drawing.Font("Arial", 10F);
            this.cbmatsv.FormattingEnabled = true;
            this.cbmatsv.Items.AddRange(new object[] {
            "Chọn mã khoa"});
            this.cbmatsv.Location = new System.Drawing.Point(670, 125);
            this.cbmatsv.Name = "cbmatsv";
            this.cbmatsv.Size = new System.Drawing.Size(396, 27);
            this.cbmatsv.TabIndex = 78;
            this.cbmatsv.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.cbmatsv_DrawItem);
            this.cbmatsv.SelectedIndexChanged += new System.EventHandler(this.cbmatsv_SelectedIndexChanged);
            this.cbmatsv.TextChanged += new System.EventHandler(this.Textchange);
            this.cbmatsv.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbmatsv_KeyPress);
            // 
            // btncapnhatttsv
            // 
            this.btncapnhatttsv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btncapnhatttsv.Font = new System.Drawing.Font("Arial", 10F);
            this.btncapnhatttsv.ForeColor = System.Drawing.Color.Black;
            this.btncapnhatttsv.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btncapnhatttsv.Location = new System.Drawing.Point(848, 158);
            this.btncapnhatttsv.Name = "btncapnhatttsv";
            this.btncapnhatttsv.Size = new System.Drawing.Size(218, 38);
            this.btncapnhatttsv.TabIndex = 79;
            this.btncapnhatttsv.Text = "Cập nhật Tỉnh/Thành";
            this.btncapnhatttsv.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btncapnhatttsv.UseVisualStyleBackColor = false;
            this.btncapnhatttsv.Click += new System.EventHandler(this.btncapnhatttsv_Click);
            this.btncapnhatttsv.MouseEnter += new System.EventHandler(this.frmSinhVien_MouseEnter);
            this.btncapnhatttsv.MouseLeave += new System.EventHandler(this.frmSinhVien_MouseLeave);
            // 
            // cbgioisv
            // 
            this.cbgioisv.Font = new System.Drawing.Font("Arial", 10F);
            this.cbgioisv.FormattingEnabled = true;
            this.cbgioisv.Items.AddRange(new object[] {
            "Chọn mã khoa"});
            this.cbgioisv.Location = new System.Drawing.Point(142, 154);
            this.cbgioisv.Name = "cbgioisv";
            this.cbgioisv.Size = new System.Drawing.Size(215, 27);
            this.cbgioisv.TabIndex = 78;
            this.cbgioisv.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.cbgioisv_DrawItem);
            this.cbgioisv.TextChanged += new System.EventHandler(this.Textchange);
            this.cbgioisv.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbgioisv_KeyPress);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(545, 40);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(38, 19);
            this.label11.TabIndex = 63;
            this.label11.Text = "Lớp";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(545, 122);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(90, 19);
            this.label12.TabIndex = 63;
            this.label12.Text = "Tỉnh/Thành";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 10F);
            this.label13.Location = new System.Drawing.Point(545, 204);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(83, 19);
            this.label13.TabIndex = 63;
            this.label13.Text = "Huyện/Thi";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 10F);
            this.label14.Location = new System.Drawing.Point(545, 286);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(94, 19);
            this.label14.TabIndex = 63;
            this.label14.Text = "Phường/Xã";
            // 
            // dgvhtan
            // 
            this.dgvhtan.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvhtan.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvhtan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvhtan.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvhtan.Location = new System.Drawing.Point(24, 9);
            this.dgvhtan.Name = "dgvhtan";
            this.dgvhtan.RowHeadersWidth = 51;
            this.dgvhtan.RowTemplate.Height = 24;
            this.dgvhtan.Size = new System.Drawing.Size(91, 43);
            this.dgvhtan.TabIndex = 77;
            this.dgvhtan.Visible = false;
            this.dgvhtan.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvsv_CellClick);
            // 
            // btnluu
            // 
            this.btnluu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnluu.Font = new System.Drawing.Font("Arial", 10F);
            this.btnluu.ForeColor = System.Drawing.Color.Black;
            this.btnluu.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnluu.Location = new System.Drawing.Point(884, 580);
            this.btnluu.Name = "btnluu";
            this.btnluu.Size = new System.Drawing.Size(93, 38);
            this.btnluu.TabIndex = 68;
            this.btnluu.Text = "Xuất file";
            this.btnluu.UseVisualStyleBackColor = false;
            this.btnluu.Click += new System.EventHandler(this.btnluu_Click);
            this.btnluu.MouseEnter += new System.EventHandler(this.frmSinhVien_MouseEnter);
            this.btnluu.MouseLeave += new System.EventHandler(this.frmSinhVien_MouseLeave);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.cbgioisv);
            this.groupBox1.Controls.Add(this.btncapnhatttsv);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.btncapnhathtsv);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.cbmatsv);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.btncapnhatpxsv);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.cbmahtsv);
            this.groupBox1.Controls.Add(this.txtmasv);
            this.groupBox1.Controls.Add(this.btncapnhatkhoasv);
            this.groupBox1.Controls.Add(this.btncapnhatlopsv);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.cbmakhoasv);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.cbmapxsv);
            this.groupBox1.Controls.Add(this.txthosv);
            this.groupBox1.Controls.Add(this.cbmalopsv);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txttensv);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txtngsinh);
            this.groupBox1.Controls.Add(this.txtemail);
            this.groupBox1.Controls.Add(this.txtdienthoai);
            this.groupBox1.Controls.Add(this.txtnoisinh);
            this.groupBox1.Controls.Add(this.txtdiachi);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(36, 97);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1105, 468);
            this.groupBox1.TabIndex = 80;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "THÔNG TIN";
            // 
            // btncapnhatkhoasv
            // 
            this.btncapnhatkhoasv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btncapnhatkhoasv.Font = new System.Drawing.Font("Arial", 10F);
            this.btncapnhatkhoasv.ForeColor = System.Drawing.Color.Black;
            this.btncapnhatkhoasv.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btncapnhatkhoasv.Location = new System.Drawing.Point(525, 406);
            this.btncapnhatkhoasv.Name = "btncapnhatkhoasv";
            this.btncapnhatkhoasv.Size = new System.Drawing.Size(151, 38);
            this.btncapnhatkhoasv.TabIndex = 79;
            this.btncapnhatkhoasv.Text = "Cập nhật khoa";
            this.btncapnhatkhoasv.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btncapnhatkhoasv.UseVisualStyleBackColor = false;
            this.btncapnhatkhoasv.Click += new System.EventHandler(this.btncapnhatkhoasv_Click);
            this.btncapnhatkhoasv.MouseEnter += new System.EventHandler(this.frmSinhVien_MouseEnter);
            this.btncapnhatkhoasv.MouseLeave += new System.EventHandler(this.frmSinhVien_MouseLeave);
            // 
            // cbmakhoasv
            // 
            this.cbmakhoasv.Font = new System.Drawing.Font("Arial", 10F);
            this.cbmakhoasv.FormattingEnabled = true;
            this.cbmakhoasv.Items.AddRange(new object[] {
            "Chọn mã khoa"});
            this.cbmakhoasv.Location = new System.Drawing.Point(142, 413);
            this.cbmakhoasv.Name = "cbmakhoasv";
            this.cbmakhoasv.Size = new System.Drawing.Size(377, 27);
            this.cbmakhoasv.TabIndex = 78;
            this.cbmakhoasv.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.cbmakhoasv_DrawItem);
            this.cbmakhoasv.TextChanged += new System.EventHandler(this.Textchange);
            this.cbmakhoasv.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbmakhoasv_KeyPress);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(36, 416);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 19);
            this.label15.TabIndex = 63;
            this.label15.Text = "Khoa";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.dgvsv);
            this.groupBox2.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 635);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1151, 357);
            this.groupBox2.TabIndex = 81;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "DANH SÁCH SINH VIÊN";
            // 
            // frmSinhVien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoScrollMinSize = new System.Drawing.Size(0, 820);
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(244)))), ((int)(((byte)(251)))));
            this.ClientSize = new System.Drawing.Size(1175, 1004);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dgvhtan);
            this.Controls.Add(this.btntimsv);
            this.Controls.Add(this.txttimsv);
            this.Controls.Add(this.btnxoasv);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnluu);
            this.Controls.Add(this.btnhuysv);
            this.Controls.Add(this.btnthemsv);
            this.Controls.Add(this.btnsuasv);
            this.Controls.Add(this.btnthoatsv);
            this.Name = "frmSinhVien";
            this.Text = "frmSinhVien";
            this.Load += new System.EventHandler(this.frmSinhVien_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvsv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvhtan)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dgvsv;
        private System.Windows.Forms.Button btntimsv;
        private System.Windows.Forms.TextBox txttimsv;
        private System.Windows.Forms.Button btnxoasv;
        private System.Windows.Forms.Button btnhuysv;
        private System.Windows.Forms.Button btnthoatsv;
        private System.Windows.Forms.Button btnsuasv;
        private System.Windows.Forms.Button btnthemsv;
        private System.Windows.Forms.TextBox txthosv;
        private System.Windows.Forms.TextBox txtmasv;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txttensv;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtngsinh;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtdienthoai;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtnoisinh;
        private System.Windows.Forms.TextBox txtdiachi;
        private System.Windows.Forms.ComboBox cbmalopsv;
        public System.Windows.Forms.Button btncapnhatlopsv;
        private System.Windows.Forms.ComboBox cbmapxsv;
        public System.Windows.Forms.Button btncapnhatpxsv;
        private System.Windows.Forms.ComboBox cbmahtsv;
        public System.Windows.Forms.Button btncapnhathtsv;
        private System.Windows.Forms.ComboBox cbmatsv;
        public System.Windows.Forms.Button btncapnhatttsv;
        private System.Windows.Forms.ComboBox cbgioisv;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DataGridView dgvhtan;
        private System.Windows.Forms.Button btnluu;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        public System.Windows.Forms.Button btncapnhatkhoasv;
        private System.Windows.Forms.ComboBox cbmakhoasv;
        private System.Windows.Forms.Label label15;
    }
}