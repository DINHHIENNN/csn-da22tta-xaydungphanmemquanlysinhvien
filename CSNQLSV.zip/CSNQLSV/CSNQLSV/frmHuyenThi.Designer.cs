﻿namespace CSNQLSV
{
    partial class frmHuyenThi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btncapnhatmaht = new System.Windows.Forms.Button();
            this.dgvht = new System.Windows.Forms.DataGridView();
            this.btntimht = new System.Windows.Forms.Button();
            this.txttimht = new System.Windows.Forms.TextBox();
            this.cbmatht = new System.Windows.Forms.ComboBox();
            this.btnxoaht = new System.Windows.Forms.Button();
            this.btnhuyht = new System.Windows.Forms.Button();
            this.btnthoatht = new System.Windows.Forms.Button();
            this.btnsuaht = new System.Windows.Forms.Button();
            this.btnthemht = new System.Windows.Forms.Button();
            this.txttenht = new System.Windows.Forms.TextBox();
            this.txtmaht = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvht)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btncapnhatmaht
            // 
            this.btncapnhatmaht.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btncapnhatmaht.Font = new System.Drawing.Font("Arial", 10F);
            this.btncapnhatmaht.ForeColor = System.Drawing.Color.Black;
            this.btncapnhatmaht.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btncapnhatmaht.Location = new System.Drawing.Point(589, 115);
            this.btncapnhatmaht.Name = "btncapnhatmaht";
            this.btncapnhatmaht.Size = new System.Drawing.Size(162, 33);
            this.btncapnhatmaht.TabIndex = 36;
            this.btncapnhatmaht.Text = "Cập nhật TT";
            this.btncapnhatmaht.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btncapnhatmaht.UseVisualStyleBackColor = false;
            this.btncapnhatmaht.Click += new System.EventHandler(this.btncapnhatmaht_Click);
            this.btncapnhatmaht.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btncapnhatmaht.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // dgvht
            // 
            this.dgvht.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvht.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvht.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvht.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvht.Location = new System.Drawing.Point(20, 34);
            this.dgvht.Name = "dgvht";
            this.dgvht.RowHeadersWidth = 51;
            this.dgvht.RowTemplate.Height = 24;
            this.dgvht.Size = new System.Drawing.Size(772, 227);
            this.dgvht.TabIndex = 42;
            this.dgvht.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvht_CellClick);
            // 
            // btntimht
            // 
            this.btntimht.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntimht.Location = new System.Drawing.Point(773, 62);
            this.btntimht.Name = "btntimht";
            this.btntimht.Size = new System.Drawing.Size(41, 37);
            this.btntimht.TabIndex = 41;
            this.btntimht.UseVisualStyleBackColor = true;
            this.btntimht.Click += new System.EventHandler(this.btntimht_Click);
            // 
            // txttimht
            // 
            this.txttimht.Font = new System.Drawing.Font("Arial", 10F);
            this.txttimht.Location = new System.Drawing.Point(544, 68);
            this.txttimht.Name = "txttimht";
            this.txttimht.Size = new System.Drawing.Size(223, 27);
            this.txttimht.TabIndex = 40;
            this.txttimht.TextChanged += new System.EventHandler(this.Textchange);
            this.txttimht.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txttimht_KeyDown);
            // 
            // cbmatht
            // 
            this.cbmatht.Font = new System.Drawing.Font("Arial", 10F);
            this.cbmatht.FormattingEnabled = true;
            this.cbmatht.Items.AddRange(new object[] {
            "Chọn mã khoa"});
            this.cbmatht.Location = new System.Drawing.Point(175, 119);
            this.cbmatht.Name = "cbmatht";
            this.cbmatht.Size = new System.Drawing.Size(405, 27);
            this.cbmatht.TabIndex = 39;
            this.cbmatht.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.cbmaht_DrawItem);
            this.cbmatht.SelectedIndexChanged += new System.EventHandler(this.cbmatht_SelectedIndexChanged);
            this.cbmatht.TextChanged += new System.EventHandler(this.Textchange);
            // 
            // btnxoaht
            // 
            this.btnxoaht.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnxoaht.Font = new System.Drawing.Font("Arial", 10F);
            this.btnxoaht.ForeColor = System.Drawing.Color.Black;
            this.btnxoaht.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnxoaht.Location = new System.Drawing.Point(161, 321);
            this.btnxoaht.Name = "btnxoaht";
            this.btnxoaht.Size = new System.Drawing.Size(97, 38);
            this.btnxoaht.TabIndex = 32;
            this.btnxoaht.Text = "Xóa";
            this.btnxoaht.UseVisualStyleBackColor = false;
            this.btnxoaht.Click += new System.EventHandler(this.btnxoaht_Click);
            this.btnxoaht.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnxoaht.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // btnhuyht
            // 
            this.btnhuyht.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnhuyht.Font = new System.Drawing.Font("Arial", 10F);
            this.btnhuyht.ForeColor = System.Drawing.Color.Black;
            this.btnhuyht.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnhuyht.Location = new System.Drawing.Point(450, 321);
            this.btnhuyht.Name = "btnhuyht";
            this.btnhuyht.Size = new System.Drawing.Size(97, 38);
            this.btnhuyht.TabIndex = 33;
            this.btnhuyht.Text = "Hủy";
            this.btnhuyht.UseVisualStyleBackColor = false;
            this.btnhuyht.Click += new System.EventHandler(this.btnhuyht_Click);
            this.btnhuyht.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnhuyht.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // btnthoatht
            // 
            this.btnthoatht.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnthoatht.Font = new System.Drawing.Font("Arial", 10F);
            this.btnthoatht.ForeColor = System.Drawing.Color.Black;
            this.btnthoatht.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnthoatht.Location = new System.Drawing.Point(711, 321);
            this.btnthoatht.Name = "btnthoatht";
            this.btnthoatht.Size = new System.Drawing.Size(97, 38);
            this.btnthoatht.TabIndex = 34;
            this.btnthoatht.Text = "Thoát";
            this.btnthoatht.UseVisualStyleBackColor = false;
            this.btnthoatht.Click += new System.EventHandler(this.btnthoatht_Click);
            this.btnthoatht.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnthoatht.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // btnsuaht
            // 
            this.btnsuaht.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnsuaht.Font = new System.Drawing.Font("Arial", 10F);
            this.btnsuaht.ForeColor = System.Drawing.Color.Black;
            this.btnsuaht.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnsuaht.Location = new System.Drawing.Point(297, 321);
            this.btnsuaht.Name = "btnsuaht";
            this.btnsuaht.Size = new System.Drawing.Size(112, 38);
            this.btnsuaht.TabIndex = 35;
            this.btnsuaht.Text = "Cập nhật";
            this.btnsuaht.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnsuaht.UseVisualStyleBackColor = false;
            this.btnsuaht.Click += new System.EventHandler(this.btnsuaht_Click);
            this.btnsuaht.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnsuaht.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // btnthemht
            // 
            this.btnthemht.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnthemht.Font = new System.Drawing.Font("Arial", 10F);
            this.btnthemht.ForeColor = System.Drawing.Color.Black;
            this.btnthemht.Location = new System.Drawing.Point(32, 321);
            this.btnthemht.Name = "btnthemht";
            this.btnthemht.Size = new System.Drawing.Size(97, 38);
            this.btnthemht.TabIndex = 37;
            this.btnthemht.Text = "Thêm";
            this.btnthemht.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnthemht.UseVisualStyleBackColor = false;
            this.btnthemht.Click += new System.EventHandler(this.btnthemht_Click);
            this.btnthemht.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnthemht.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // txttenht
            // 
            this.txttenht.Font = new System.Drawing.Font("Arial", 10F);
            this.txttenht.Location = new System.Drawing.Point(175, 79);
            this.txttenht.Name = "txttenht";
            this.txttenht.Size = new System.Drawing.Size(405, 27);
            this.txttenht.TabIndex = 30;
            this.txttenht.TextChanged += new System.EventHandler(this.Textchange);
            this.txttenht.Enter += new System.EventHandler(this.txt_Enter);
            this.txttenht.Leave += new System.EventHandler(this.txt_Leave);
            // 
            // txtmaht
            // 
            this.txtmaht.Font = new System.Drawing.Font("Arial", 10F);
            this.txtmaht.Location = new System.Drawing.Point(175, 41);
            this.txtmaht.Name = "txtmaht";
            this.txtmaht.Size = new System.Drawing.Size(405, 27);
            this.txtmaht.TabIndex = 31;
            this.txtmaht.TextChanged += new System.EventHandler(this.Textchange);
            this.txtmaht.Enter += new System.EventHandler(this.txt_Enter);
            this.txtmaht.Leave += new System.EventHandler(this.txt_Leave);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 10F);
            this.label4.Location = new System.Drawing.Point(33, 82);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 19);
            this.label4.TabIndex = 27;
            this.label4.Text = "Tên Huyện/Thị";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 10F);
            this.label3.Location = new System.Drawing.Point(33, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 19);
            this.label3.TabIndex = 28;
            this.label3.Text = "Tỉnh/Thành";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 10F);
            this.label2.Location = new System.Drawing.Point(33, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 19);
            this.label2.TabIndex = 29;
            this.label2.Text = "Mã Huyện/Thị";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(262, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(319, 35);
            this.label1.TabIndex = 25;
            this.label1.Text = "QUẢN LÝ HUYỆN THỊ";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.cbmatht);
            this.groupBox1.Controls.Add(this.btncapnhatmaht);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtmaht);
            this.groupBox1.Controls.Add(this.txttenht);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(32, 105);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(772, 172);
            this.groupBox1.TabIndex = 43;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "THÔNG TIN";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.dgvht);
            this.groupBox2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 396);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(813, 280);
            this.groupBox2.TabIndex = 44;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "DANH SÁCH HUYỆN THỊ";
            // 
            // frmHuyenThi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(244)))), ((int)(((byte)(251)))));
            this.ClientSize = new System.Drawing.Size(837, 689);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btntimht);
            this.Controls.Add(this.txttimht);
            this.Controls.Add(this.btnxoaht);
            this.Controls.Add(this.btnhuyht);
            this.Controls.Add(this.btnthoatht);
            this.Controls.Add(this.btnsuaht);
            this.Controls.Add(this.btnthemht);
            this.Controls.Add(this.label1);
            this.Name = "frmHuyenThi";
            this.Text = "frmHuyenThi";
            this.Load += new System.EventHandler(this.frmHuyenThi_Load);
            this.TextChanged += new System.EventHandler(this.Textchange);
            this.Enter += new System.EventHandler(this.txt_Enter);
            this.Leave += new System.EventHandler(this.txt_Leave);
            ((System.ComponentModel.ISupportInitialize)(this.dgvht)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button btncapnhatmaht;
        private System.Windows.Forms.DataGridView dgvht;
        private System.Windows.Forms.Button btntimht;
        private System.Windows.Forms.TextBox txttimht;
        private System.Windows.Forms.ComboBox cbmatht;
        private System.Windows.Forms.Button btnxoaht;
        private System.Windows.Forms.Button btnhuyht;
        private System.Windows.Forms.Button btnthoatht;
        private System.Windows.Forms.Button btnsuaht;
        private System.Windows.Forms.Button btnthemht;
        private System.Windows.Forms.TextBox txttenht;
        private System.Windows.Forms.TextBox txtmaht;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}