﻿namespace CSNQLSV
{
    partial class frmPhuongXa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btncapnhatmahtpx = new System.Windows.Forms.Button();
            this.dgvpx = new System.Windows.Forms.DataGridView();
            this.btntimpx = new System.Windows.Forms.Button();
            this.txttimpx = new System.Windows.Forms.TextBox();
            this.cbmahtpx = new System.Windows.Forms.ComboBox();
            this.btnxoapx = new System.Windows.Forms.Button();
            this.btnhuypx = new System.Windows.Forms.Button();
            this.btnthoatpx = new System.Windows.Forms.Button();
            this.btnsuapx = new System.Windows.Forms.Button();
            this.btnthempx = new System.Windows.Forms.Button();
            this.txttenpx = new System.Windows.Forms.TextBox();
            this.txtmapx = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbmatpx = new System.Windows.Forms.ComboBox();
            this.btncapnhatmatpx = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dgvan = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvpx)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvan)).BeginInit();
            this.SuspendLayout();
            // 
            // btncapnhatmahtpx
            // 
            this.btncapnhatmahtpx.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btncapnhatmahtpx.Font = new System.Drawing.Font("Arial", 10F);
            this.btncapnhatmahtpx.ForeColor = System.Drawing.Color.Black;
            this.btncapnhatmahtpx.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btncapnhatmahtpx.Location = new System.Drawing.Point(617, 155);
            this.btncapnhatmahtpx.Name = "btncapnhatmahtpx";
            this.btncapnhatmahtpx.Size = new System.Drawing.Size(148, 33);
            this.btncapnhatmahtpx.TabIndex = 53;
            this.btncapnhatmahtpx.Text = "Cập nhật HT";
            this.btncapnhatmahtpx.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btncapnhatmahtpx.UseVisualStyleBackColor = false;
            this.btncapnhatmahtpx.Click += new System.EventHandler(this.btncapnhatmahtpx_Click);
            this.btncapnhatmahtpx.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btncapnhatmahtpx.MouseLeave += new System.EventHandler(this.btnpx_MouseLeave);
            // 
            // dgvpx
            // 
            this.dgvpx.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvpx.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvpx.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvpx.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvpx.Location = new System.Drawing.Point(24, 37);
            this.dgvpx.Name = "dgvpx";
            this.dgvpx.RowHeadersWidth = 51;
            this.dgvpx.RowTemplate.Height = 24;
            this.dgvpx.Size = new System.Drawing.Size(841, 243);
            this.dgvpx.TabIndex = 58;
            this.dgvpx.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvpx_CellClick);
            // 
            // btntimpx
            // 
            this.btntimpx.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntimpx.Location = new System.Drawing.Point(836, 77);
            this.btntimpx.Name = "btntimpx";
            this.btntimpx.Size = new System.Drawing.Size(41, 37);
            this.btntimpx.TabIndex = 57;
            this.btntimpx.UseVisualStyleBackColor = true;
            this.btntimpx.Click += new System.EventHandler(this.btntimpx_Click);
            // 
            // txttimpx
            // 
            this.txttimpx.Font = new System.Drawing.Font("Arial", 10F);
            this.txttimpx.Location = new System.Drawing.Point(618, 83);
            this.txttimpx.Name = "txttimpx";
            this.txttimpx.Size = new System.Drawing.Size(212, 27);
            this.txttimpx.TabIndex = 56;
            this.txttimpx.TextChanged += new System.EventHandler(this.Textchange);
            this.txttimpx.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txttimpx_KeyDown);
            // 
            // cbmahtpx
            // 
            this.cbmahtpx.Enabled = false;
            this.cbmahtpx.Font = new System.Drawing.Font("Arial", 10F);
            this.cbmahtpx.FormattingEnabled = true;
            this.cbmahtpx.Items.AddRange(new object[] {
            "Chọn mã khoa"});
            this.cbmahtpx.Location = new System.Drawing.Point(203, 159);
            this.cbmahtpx.Name = "cbmahtpx";
            this.cbmahtpx.Size = new System.Drawing.Size(405, 27);
            this.cbmahtpx.TabIndex = 55;
            this.cbmahtpx.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.cbmahtpx_DrawItem);
            this.cbmahtpx.SelectedIndexChanged += new System.EventHandler(this.cb_SelectedIndexxChange);
            this.cbmahtpx.TextChanged += new System.EventHandler(this.Textchange);
            this.cbmahtpx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.frmPhuongXa_KeyPress);
            // 
            // btnxoapx
            // 
            this.btnxoapx.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnxoapx.Font = new System.Drawing.Font("Arial", 10F);
            this.btnxoapx.ForeColor = System.Drawing.Color.Black;
            this.btnxoapx.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnxoapx.Location = new System.Drawing.Point(194, 347);
            this.btnxoapx.Name = "btnxoapx";
            this.btnxoapx.Size = new System.Drawing.Size(97, 38);
            this.btnxoapx.TabIndex = 49;
            this.btnxoapx.Text = "Xóa";
            this.btnxoapx.UseVisualStyleBackColor = false;
            this.btnxoapx.Click += new System.EventHandler(this.btnxoapx_Click);
            this.btnxoapx.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnxoapx.MouseLeave += new System.EventHandler(this.btnpx_MouseLeave);
            // 
            // btnhuypx
            // 
            this.btnhuypx.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnhuypx.Font = new System.Drawing.Font("Arial", 10F);
            this.btnhuypx.ForeColor = System.Drawing.Color.Black;
            this.btnhuypx.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnhuypx.Location = new System.Drawing.Point(479, 347);
            this.btnhuypx.Name = "btnhuypx";
            this.btnhuypx.Size = new System.Drawing.Size(93, 38);
            this.btnhuypx.TabIndex = 50;
            this.btnhuypx.Text = "Hủy";
            this.btnhuypx.UseVisualStyleBackColor = false;
            this.btnhuypx.Click += new System.EventHandler(this.btnhuypx_Click);
            this.btnhuypx.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnhuypx.MouseLeave += new System.EventHandler(this.btnpx_MouseLeave);
            // 
            // btnthoatpx
            // 
            this.btnthoatpx.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnthoatpx.Font = new System.Drawing.Font("Arial", 10F);
            this.btnthoatpx.ForeColor = System.Drawing.Color.Black;
            this.btnthoatpx.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnthoatpx.Location = new System.Drawing.Point(756, 347);
            this.btnthoatpx.Name = "btnthoatpx";
            this.btnthoatpx.Size = new System.Drawing.Size(97, 38);
            this.btnthoatpx.TabIndex = 51;
            this.btnthoatpx.Text = "Thoát";
            this.btnthoatpx.UseVisualStyleBackColor = false;
            this.btnthoatpx.Click += new System.EventHandler(this.btnthoatpx_Click);
            this.btnthoatpx.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnthoatpx.MouseLeave += new System.EventHandler(this.btnpx_MouseLeave);
            // 
            // btnsuapx
            // 
            this.btnsuapx.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnsuapx.Font = new System.Drawing.Font("Arial", 10F);
            this.btnsuapx.ForeColor = System.Drawing.Color.Black;
            this.btnsuapx.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnsuapx.Location = new System.Drawing.Point(327, 347);
            this.btnsuapx.Name = "btnsuapx";
            this.btnsuapx.Size = new System.Drawing.Size(112, 38);
            this.btnsuapx.TabIndex = 52;
            this.btnsuapx.Text = "Cập nhật";
            this.btnsuapx.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnsuapx.UseVisualStyleBackColor = false;
            this.btnsuapx.Click += new System.EventHandler(this.btnsuapx_Click);
            this.btnsuapx.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnsuapx.MouseLeave += new System.EventHandler(this.btnpx_MouseLeave);
            // 
            // btnthempx
            // 
            this.btnthempx.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnthempx.Font = new System.Drawing.Font("Arial", 10F);
            this.btnthempx.ForeColor = System.Drawing.Color.Black;
            this.btnthempx.Location = new System.Drawing.Point(63, 347);
            this.btnthempx.Name = "btnthempx";
            this.btnthempx.Size = new System.Drawing.Size(97, 38);
            this.btnthempx.TabIndex = 54;
            this.btnthempx.Text = "Thêm";
            this.btnthempx.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnthempx.UseVisualStyleBackColor = false;
            this.btnthempx.Click += new System.EventHandler(this.btnthempx_Click);
            this.btnthempx.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnthempx.MouseLeave += new System.EventHandler(this.btnpx_MouseLeave);
            // 
            // txttenpx
            // 
            this.txttenpx.Font = new System.Drawing.Font("Arial", 10F);
            this.txttenpx.Location = new System.Drawing.Point(203, 73);
            this.txttenpx.Name = "txttenpx";
            this.txttenpx.Size = new System.Drawing.Size(405, 27);
            this.txttenpx.TabIndex = 47;
            this.txttenpx.TextChanged += new System.EventHandler(this.Textchange);
            this.txttenpx.Enter += new System.EventHandler(this.txt_Enter);
            this.txttenpx.Leave += new System.EventHandler(this.txt_Leave);
            // 
            // txtmapx
            // 
            this.txtmapx.Font = new System.Drawing.Font("Arial", 10F);
            this.txtmapx.Location = new System.Drawing.Point(203, 35);
            this.txtmapx.Name = "txtmapx";
            this.txtmapx.Size = new System.Drawing.Size(405, 27);
            this.txtmapx.TabIndex = 48;
            this.txtmapx.TextChanged += new System.EventHandler(this.Textchange);
            this.txtmapx.Enter += new System.EventHandler(this.txt_Enter);
            this.txtmapx.Leave += new System.EventHandler(this.txt_Leave);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 10F);
            this.label4.Location = new System.Drawing.Point(30, 76);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(126, 19);
            this.label4.TabIndex = 44;
            this.label4.Text = "Tên Phường/Xã";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 10F);
            this.label3.Location = new System.Drawing.Point(30, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 19);
            this.label3.TabIndex = 45;
            this.label3.Text = "Huyện/Thị";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 10F);
            this.label2.Location = new System.Drawing.Point(30, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 19);
            this.label2.TabIndex = 46;
            this.label2.Text = "Mã Phường/Xã";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(262, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(345, 35);
            this.label1.TabIndex = 43;
            this.label1.Text = "QUẢN LÝ PHƯỜNG XÃ";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.cbmatpx);
            this.groupBox1.Controls.Add(this.cbmahtpx);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.btncapnhatmatpx);
            this.groupBox1.Controls.Add(this.btncapnhatmahtpx);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txttenpx);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtmapx);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(65, 116);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(786, 207);
            this.groupBox1.TabIndex = 59;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "THÔNG TIN";
            // 
            // cbmatpx
            // 
            this.cbmatpx.Font = new System.Drawing.Font("Arial", 10F);
            this.cbmatpx.FormattingEnabled = true;
            this.cbmatpx.Items.AddRange(new object[] {
            "Chọn mã khoa"});
            this.cbmatpx.Location = new System.Drawing.Point(203, 116);
            this.cbmatpx.Name = "cbmatpx";
            this.cbmatpx.Size = new System.Drawing.Size(405, 27);
            this.cbmatpx.TabIndex = 58;
            this.cbmatpx.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.cbmatpx_DrawItem);
            this.cbmatpx.SelectedIndexChanged += new System.EventHandler(this.cb_SelectedIndexxChange);
            this.cbmatpx.TextChanged += new System.EventHandler(this.Textchange);
            this.cbmatpx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.frmPhuongXa_KeyPress);
            // 
            // btncapnhatmatpx
            // 
            this.btncapnhatmatpx.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btncapnhatmatpx.Font = new System.Drawing.Font("Arial", 10F);
            this.btncapnhatmatpx.ForeColor = System.Drawing.Color.Black;
            this.btncapnhatmatpx.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btncapnhatmatpx.Location = new System.Drawing.Point(617, 112);
            this.btncapnhatmatpx.Name = "btncapnhatmatpx";
            this.btncapnhatmatpx.Size = new System.Drawing.Size(148, 33);
            this.btncapnhatmatpx.TabIndex = 57;
            this.btncapnhatmatpx.Text = "Cập nhật TT";
            this.btncapnhatmatpx.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btncapnhatmatpx.UseVisualStyleBackColor = false;
            this.btncapnhatmatpx.Click += new System.EventHandler(this.btncapnhatmat_Click);
            this.btncapnhatmatpx.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btncapnhatmatpx.MouseLeave += new System.EventHandler(this.btnpx_MouseLeave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 10F);
            this.label5.Location = new System.Drawing.Point(30, 119);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 19);
            this.label5.TabIndex = 56;
            this.label5.Text = "Tỉnh/Thành";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.dgvpx);
            this.groupBox2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 407);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(881, 301);
            this.groupBox2.TabIndex = 60;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "DANH SÁCH PHƯỜNG XÃ";
            // 
            // dgvan
            // 
            this.dgvan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvan.Location = new System.Drawing.Point(-7, 10);
            this.dgvan.Name = "dgvan";
            this.dgvan.RowHeadersWidth = 51;
            this.dgvan.RowTemplate.Height = 24;
            this.dgvan.Size = new System.Drawing.Size(110, 49);
            this.dgvan.TabIndex = 61;
            this.dgvan.Visible = false;
            // 
            // frmPhuongXa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(244)))), ((int)(((byte)(251)))));
            this.ClientSize = new System.Drawing.Size(905, 720);
            this.Controls.Add(this.dgvan);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btntimpx);
            this.Controls.Add(this.txttimpx);
            this.Controls.Add(this.btnxoapx);
            this.Controls.Add(this.btnhuypx);
            this.Controls.Add(this.btnthoatpx);
            this.Controls.Add(this.btnsuapx);
            this.Controls.Add(this.btnthempx);
            this.Controls.Add(this.label1);
            this.Name = "frmPhuongXa";
            this.Text = "frmPhuongXa";
            this.Load += new System.EventHandler(this.frmPhuongXa_Load);
            this.Enter += new System.EventHandler(this.txt_Enter);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.frmPhuongXa_KeyPress);
            this.Leave += new System.EventHandler(this.txt_Leave);
            ((System.ComponentModel.ISupportInitialize)(this.dgvpx)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvan)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button btncapnhatmahtpx;
        private System.Windows.Forms.DataGridView dgvpx;
        private System.Windows.Forms.Button btntimpx;
        private System.Windows.Forms.TextBox txttimpx;
        private System.Windows.Forms.ComboBox cbmahtpx;
        private System.Windows.Forms.Button btnxoapx;
        private System.Windows.Forms.Button btnhuypx;
        private System.Windows.Forms.Button btnthoatpx;
        private System.Windows.Forms.Button btnsuapx;
        private System.Windows.Forms.Button btnthempx;
        private System.Windows.Forms.TextBox txttenpx;
        private System.Windows.Forms.TextBox txtmapx;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cbmatpx;
        public System.Windows.Forms.Button btncapnhatmatpx;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dgvan;
    }
}