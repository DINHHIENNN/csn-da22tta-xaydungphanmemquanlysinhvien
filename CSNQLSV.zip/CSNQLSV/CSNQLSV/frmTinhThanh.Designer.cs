﻿namespace CSNQLSV
{
    partial class frmTinhThanh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btntimtinh = new System.Windows.Forms.Button();
            this.txttimtinh = new System.Windows.Forms.TextBox();
            this.dgvtinh = new System.Windows.Forms.DataGridView();
            this.btnxoatinh = new System.Windows.Forms.Button();
            this.btnhuytinh = new System.Windows.Forms.Button();
            this.btnthoattinh = new System.Windows.Forms.Button();
            this.btnsuatinh = new System.Windows.Forms.Button();
            this.btnthemtinh = new System.Windows.Forms.Button();
            this.txttentinh = new System.Windows.Forms.TextBox();
            this.txtmatinh = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvtinh)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btntimtinh
            // 
            this.btntimtinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntimtinh.Location = new System.Drawing.Point(721, 71);
            this.btntimtinh.Name = "btntimtinh";
            this.btntimtinh.Size = new System.Drawing.Size(41, 37);
            this.btntimtinh.TabIndex = 42;
            this.btntimtinh.UseVisualStyleBackColor = true;
            this.btntimtinh.Click += new System.EventHandler(this.btntimtinh_Click);
            // 
            // txttimtinh
            // 
            this.txttimtinh.Font = new System.Drawing.Font("Arial", 10F);
            this.txttimtinh.Location = new System.Drawing.Point(487, 77);
            this.txttimtinh.Name = "txttimtinh";
            this.txttimtinh.Size = new System.Drawing.Size(228, 27);
            this.txttimtinh.TabIndex = 41;
            this.txttimtinh.TextChanged += new System.EventHandler(this.Textchange);
            this.txttimtinh.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txttimtinh_KeyDown);
            // 
            // dgvtinh
            // 
            this.dgvtinh.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvtinh.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvtinh.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvtinh.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvtinh.Location = new System.Drawing.Point(19, 37);
            this.dgvtinh.Name = "dgvtinh";
            this.dgvtinh.RowHeadersWidth = 51;
            this.dgvtinh.RowTemplate.Height = 24;
            this.dgvtinh.Size = new System.Drawing.Size(762, 252);
            this.dgvtinh.TabIndex = 39;
            this.dgvtinh.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvtinh_CellClick);
            this.dgvtinh.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvtinh_CellContentClick);
            // 
            // btnxoatinh
            // 
            this.btnxoatinh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnxoatinh.Font = new System.Drawing.Font("Arial", 10F);
            this.btnxoatinh.ForeColor = System.Drawing.Color.Black;
            this.btnxoatinh.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnxoatinh.Location = new System.Drawing.Point(212, 303);
            this.btnxoatinh.Name = "btnxoatinh";
            this.btnxoatinh.Size = new System.Drawing.Size(97, 38);
            this.btnxoatinh.TabIndex = 37;
            this.btnxoatinh.Text = "Xóa";
            this.btnxoatinh.UseVisualStyleBackColor = false;
            this.btnxoatinh.Click += new System.EventHandler(this.btnxoatinh_Click);
            this.btnxoatinh.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnxoatinh.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // btnhuytinh
            // 
            this.btnhuytinh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnhuytinh.Font = new System.Drawing.Font("Arial", 10F);
            this.btnhuytinh.ForeColor = System.Drawing.Color.Black;
            this.btnhuytinh.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnhuytinh.Location = new System.Drawing.Point(472, 303);
            this.btnhuytinh.Name = "btnhuytinh";
            this.btnhuytinh.Size = new System.Drawing.Size(97, 38);
            this.btnhuytinh.TabIndex = 36;
            this.btnhuytinh.Text = "Hủy";
            this.btnhuytinh.UseVisualStyleBackColor = false;
            this.btnhuytinh.Click += new System.EventHandler(this.btnhuytinh_Click);
            this.btnhuytinh.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnhuytinh.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // btnthoattinh
            // 
            this.btnthoattinh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnthoattinh.Font = new System.Drawing.Font("Arial", 10F);
            this.btnthoattinh.ForeColor = System.Drawing.Color.Black;
            this.btnthoattinh.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnthoattinh.Location = new System.Drawing.Point(651, 303);
            this.btnthoattinh.Name = "btnthoattinh";
            this.btnthoattinh.Size = new System.Drawing.Size(97, 38);
            this.btnthoattinh.TabIndex = 35;
            this.btnthoattinh.Text = "Thoát";
            this.btnthoattinh.UseVisualStyleBackColor = false;
            this.btnthoattinh.Click += new System.EventHandler(this.btnthoattinh_Click);
            this.btnthoattinh.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnthoattinh.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // btnsuatinh
            // 
            this.btnsuatinh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnsuatinh.Font = new System.Drawing.Font("Arial", 10F);
            this.btnsuatinh.ForeColor = System.Drawing.Color.Black;
            this.btnsuatinh.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnsuatinh.Location = new System.Drawing.Point(334, 303);
            this.btnsuatinh.Name = "btnsuatinh";
            this.btnsuatinh.Size = new System.Drawing.Size(115, 38);
            this.btnsuatinh.TabIndex = 38;
            this.btnsuatinh.Text = "Cập nhật";
            this.btnsuatinh.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnsuatinh.UseVisualStyleBackColor = false;
            this.btnsuatinh.Click += new System.EventHandler(this.btnsuatinh_Click);
            this.btnsuatinh.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnsuatinh.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // btnthemtinh
            // 
            this.btnthemtinh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnthemtinh.Font = new System.Drawing.Font("Arial", 10F);
            this.btnthemtinh.ForeColor = System.Drawing.Color.Black;
            this.btnthemtinh.Location = new System.Drawing.Point(89, 303);
            this.btnthemtinh.Name = "btnthemtinh";
            this.btnthemtinh.Size = new System.Drawing.Size(97, 38);
            this.btnthemtinh.TabIndex = 34;
            this.btnthemtinh.Text = "Thêm";
            this.btnthemtinh.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnthemtinh.UseVisualStyleBackColor = false;
            this.btnthemtinh.Click += new System.EventHandler(this.btnthemtinh_Click);
            this.btnthemtinh.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnthemtinh.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // txttentinh
            // 
            this.txttentinh.Font = new System.Drawing.Font("Arial", 10F);
            this.txttentinh.Location = new System.Drawing.Point(205, 88);
            this.txttentinh.Name = "txttentinh";
            this.txttentinh.Size = new System.Drawing.Size(405, 27);
            this.txttentinh.TabIndex = 32;
            this.txttentinh.TextChanged += new System.EventHandler(this.Textchange);
            this.txttentinh.Enter += new System.EventHandler(this.txt_Enter);
            this.txttentinh.Leave += new System.EventHandler(this.txt_Leave);
            // 
            // txtmatinh
            // 
            this.txtmatinh.Font = new System.Drawing.Font("Arial", 10F);
            this.txtmatinh.Location = new System.Drawing.Point(205, 42);
            this.txtmatinh.Name = "txtmatinh";
            this.txtmatinh.Size = new System.Drawing.Size(405, 27);
            this.txtmatinh.TabIndex = 31;
            this.txtmatinh.TextChanged += new System.EventHandler(this.Textchange);
            this.txtmatinh.Enter += new System.EventHandler(this.txt_Enter);
            this.txtmatinh.Leave += new System.EventHandler(this.txt_Leave);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 10F);
            this.label4.Location = new System.Drawing.Point(35, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 19);
            this.label4.TabIndex = 28;
            this.label4.Text = "Tên Tỉnh/Thành";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 10F);
            this.label2.Location = new System.Drawing.Point(35, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 19);
            this.label2.TabIndex = 30;
            this.label2.Text = "Mã Tỉnh/Thành";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(270, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(341, 35);
            this.label1.TabIndex = 26;
            this.label1.Text = "QUẢN LÝ TỈNH THÀNH";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.txttentinh);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtmatinh);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(89, 110);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(659, 156);
            this.groupBox1.TabIndex = 43;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "THÔNG TIN";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.dgvtinh);
            this.groupBox2.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 378);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(802, 303);
            this.groupBox2.TabIndex = 44;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "DANH SÁCH  TỈNH THÀNH";
            // 
            // frmTinhThanh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(244)))), ((int)(((byte)(251)))));
            this.ClientSize = new System.Drawing.Size(826, 693);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btntimtinh);
            this.Controls.Add(this.txttimtinh);
            this.Controls.Add(this.btnxoatinh);
            this.Controls.Add(this.btnhuytinh);
            this.Controls.Add(this.btnthoattinh);
            this.Controls.Add(this.btnsuatinh);
            this.Controls.Add(this.btnthemtinh);
            this.Controls.Add(this.label1);
            this.Name = "frmTinhThanh";
            this.Text = "frmTinhThanh";
            this.Load += new System.EventHandler(this.frmTinhThanh_Load);
            this.TextChanged += new System.EventHandler(this.Textchange);
            this.Enter += new System.EventHandler(this.txt_Enter);
            this.Leave += new System.EventHandler(this.txt_Leave);
            ((System.ComponentModel.ISupportInitialize)(this.dgvtinh)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btntimtinh;
        private System.Windows.Forms.TextBox txttimtinh;
        private System.Windows.Forms.DataGridView dgvtinh;
        private System.Windows.Forms.Button btnxoatinh;
        private System.Windows.Forms.Button btnhuytinh;
        private System.Windows.Forms.Button btnthoattinh;
        private System.Windows.Forms.Button btnsuatinh;
        private System.Windows.Forms.Button btnthemtinh;
        private System.Windows.Forms.TextBox txttentinh;
        private System.Windows.Forms.TextBox txtmatinh;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}