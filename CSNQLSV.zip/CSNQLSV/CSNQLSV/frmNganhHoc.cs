﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSNQLSV
{
    public partial class frmNganhHoc : Form
    {
        NganhHoc nh;
        BoMon bm;
        public frmNganhHoc()
        {
            InitializeComponent();
            nh= new NganhHoc();
            bm= new BoMon();
        }

        private void FfrmNganhHoc_Load(object sender, EventArgs e)
        {
            dgvnh.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DataTable dtnh = nh.getdsNganhHoc();
            this.dgvnh.DataSource = dtnh;       
            load(1);
            load_cb();
            Hienthinut(2);

            dgvnh.Columns["MaNH"].HeaderText = "Mã Ngành Học";
            dgvnh.Columns["TenNH"].HeaderText = "Tên Ngành Học";
            dgvnh.Columns["MaBM"].HeaderText = "Mã Bộ Môn";
            dgvnh.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dgvnh.DefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Regular);
            Image timbmicon = Properties.Resources.tim;
            Image resizetimbmicon = new Bitmap(timbmicon, new Size(26, 26));
            btntimnh.Image = resizetimbmicon;
        }
        public void Hienthinut(int x)
        {
            if (x == 1)
            {
                this.btnxoanh.Enabled = true;
                this.btnsuanh.Enabled = true;
                this.btnthemnh.Enabled = true;
            }
            else if (x == 2)
            {
                this.btnxoanh.Enabled = false;
                this.btnsuanh.Enabled = false;
                this.btnthemnh.Enabled = false;
            }

        }
        public void load_cb()
        {
            DataTable dtbm = bm.getdsBoMon();
            DataRow dr = dtbm.NewRow();
            dr[dtbm.Columns[0].ColumnName] = DBNull.Value;
            dr[dtbm.Columns[1].ColumnName] = "Chọn bộ môn";
            dtbm.Rows.InsertAt(dr, 0);

            this.cbmabmnh.DataSource = dtbm;
            this.cbmabmnh.ValueMember = dtbm.Columns[0].ColumnName.ToString();
            this.cbmabmnh.DisplayMember = dtbm.Columns[1].ColumnName.ToString();
            cbmabmnh.DrawMode = DrawMode.OwnerDrawFixed;
            cbmabmnh.DrawItem += cbmabmnh_DrawItem;
        }
        public void load(int x)
        {
            if (x == 1)
            {
                this.txtmanh.Text = "Nhập mã ngành học";
                this.txttennh.Text = "Nhập tên ngành học";
                this.txtmanh.ForeColor = Color.Gray;
                this.txttennh.ForeColor = Color.Gray;
                this.ActiveControl = this.txtmanh;
                this.btnhuynh.Enabled = false;
            }
            else if (x == 2)
            {
                this.txtmanh.ForeColor = Color.Black;
                this.txttennh.ForeColor = Color.Black;
                this.ActiveControl = this.txtmanh;
                this.btnhuynh.Enabled = false;

            }

        }
        private void cbmabmnh_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            ComboBox comboBox = sender as ComboBox;
            string text = comboBox.GetItemText(comboBox.Items[e.Index]);


            Color textColor = text == "Chọn bộ môn" ? Color.Gray : Color.Black;

            e.DrawBackground();
            using (Brush brush = new SolidBrush(textColor))
            {
                e.Graphics.DrawString(text, e.Font, brush, e.Bounds);
            }
            e.DrawFocusRectangle();
        }

        private void VoHieuHoa_cb(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void btntimnh_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(this.txttimnh.Text.Trim()))
            {
                MessageBox.Show("Vui lòng nhập từ khóa tìm kiếm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            DataTable dtnh = nh.getdsNganhHoc();
            dgvnh.DataSource = dtnh;
            DataTable dt_tim = new DataTable();
            DataColumn col1 = new DataColumn();
            col1.ColumnName = "MaNH";
            DataColumn col2 = new DataColumn();
            col2.ColumnName = "TenNH";
            DataColumn col3 = new DataColumn();
            col3.ColumnName = "MaBM";
            dt_tim.Columns.Add(col1);
            dt_tim.Columns.Add(col2);
            dt_tim.Columns.Add(col3);
            bool kt = false;
            foreach (DataGridViewRow row in dgvnh.Rows)
            {
                if ((row.Cells["MaNH"].Value != null && row.Cells["MaNH"].Value.ToString().Trim() == txttimnh.Text.Trim()) || (row.Cells["TenNH"].Value != null && row.Cells["TenNH"].Value.ToString().Trim() == txttimnh.Text.Trim()) )
                {
                    DataRow dr = dt_tim.NewRow();
                    dr["MaNH"] = row.Cells["MaNH"].Value.ToString();
                    dr["TenNH"] = row.Cells["TenNH"].Value.ToString();
                    dr["MaBM"] = row.Cells["MaBM"].Value.ToString();
                    dt_tim.Rows.Add(dr);
                    kt = true;
                }
            }
            load(1);
            load_cb();
            Hienthinut(2);
            this.dgvnh.DataSource = dt_tim;
            if (!kt)
            {
                MessageBox.Show("Không tìm thấy thông tin ngành học", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            this.btnhuynh.Enabled = true;
        }

        private void txttimnh_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btntimnh_Click(sender, e);
            }
        }

        private void Textchange(object sender, EventArgs e)
        {

            bool isManhEmpty = string.IsNullOrWhiteSpace(this.txtmanh.Text) || this.txtmanh.Text == "Nhập mã ngành học";
            bool isTennhEmpty = string.IsNullOrWhiteSpace(this.txttennh.Text) || this.txttennh.Text == "Nhập tên ngành học";       
            bool isTimnhEmpty = string.IsNullOrWhiteSpace(this.txttimnh.Text);
            bool isCbbmnhNotSelected = this.cbmabmnh.SelectedIndex == 0;
            if (cbmabmnh.SelectedIndex == 0)
            {
                cbmabmnh.ForeColor = Color.Gray;
            }
            else
            {
                cbmabmnh.ForeColor = Color.Black;
            }

            if (isManhEmpty && isTennhEmpty  && isCbbmnhNotSelected)
            {
                if (isTimnhEmpty)
                {
                    this.btnhuynh.Enabled = false;
                }
                else
                {
                    this.btnhuynh.Enabled = true;
                }
                Hienthinut(2);
            }
            else if (isManhEmpty || isTennhEmpty || isCbbmnhNotSelected)
            {
                if (isTimnhEmpty)
                {
                    this.btnhuynh.Enabled = true;
                }
                else
                {
                    this.btnhuynh.Enabled = true;
                }
                Hienthinut(1);
            }
            else if ((!isManhEmpty && !isTennhEmpty  && !isCbbmnhNotSelected))
            {

                if (isTimnhEmpty)
                {
                    this.btnhuynh.Enabled = true;
                }
                else
                {
                    this.btnhuynh.Enabled = true;
                }
                Hienthinut(1);
            }
        }


        private void btnthemnh_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.txtmanh.Text == "Nhập mã ngành học" ||this.txtmanh.Text=="")
                {
                    MessageBox.Show("Vui lòng nhập Mã ngành học");
                    this.txtmanh.Focus();
                }
                else if (this.txttennh.Text == "Nhập tên ngành học" || this.txttennh.Text=="")
                {
                    MessageBox.Show("Vui lòng nhập Tên ngành học!");
                    this.txttennh.Focus();
                }
                else if (this.cbmabmnh.Text == "Chọn bộ môn")
                {
                    MessageBox.Show("Vui lòng Chọn bộ môn!");
                }
                else
                {
                    nh.Mabm = this.cbmabmnh.SelectedValue.ToString().Trim();
                    nh.Manh = this.txtmanh.Text;
                    nh.Tennh = this.txttennh.Text;
                    nh.addNganhHoc();
                    DataTable dtnh = nh.getdsNganhHoc();
                    dgvnh.DataSource = dtnh;
                    dgvnh.Columns["MaNH"].HeaderText = "Mã Ngành Học";
                    dgvnh.Columns["TenNH"].HeaderText = "Tên Ngành Học";
                    dgvnh.Columns["MaBM"].HeaderText = "Mã Bộ Môn";
                    load(1);
                    load_cb();
                    MessageBox.Show("Dữ liệu đã được thêm thành công vào hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ngành học có mã {this.txtmanh.Text} đã tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnxoanh_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa dữ liệu này không?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                try
                {
                    if (this.txtmanh.Text == "Nhập mã ngành học" || this.txtmanh.Text == "")
                    {
                        MessageBox.Show("Bạn chưa nhập mã ngành học. Vui lòng điền thông tin trước khi tiếp tục.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        this.txtmanh.Focus();
                        return;
                    }
                    DataTable dtnh = nh.getdsNganhHoc();
                    dgvnh.DataSource = dtnh;
                    bool kt = false;
                    foreach (DataGridViewRow row in dgvnh.Rows)
                    {
                        if (row.Cells["MaNH"].Value != null && row.Cells["MaNH"].Value.ToString().Trim() == txtmanh.Text.Trim())
                        {
                            nh.Manh = this.txtmanh.Text;
                            nh.deleteNganhHoc();
                            DataTable dtnh1 = nh.getdsNganhHoc();
                            dgvnh.DataSource = dtnh1;

                            dgvnh.Columns["MaNH"].HeaderText = "Mã Ngành Học";
                            dgvnh.Columns["TenNH"].HeaderText = "Tên Ngành Học";
                            dgvnh.Columns["MaBM"].HeaderText = "Mã Bộ Môn";
                            load_cb();
                            load(1);
                            MessageBox.Show("Dữ liệu đã được xóa thành công khỏi hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.btnhuynh.Enabled = true;
                            kt = true;
                            break;
                        }

                    }
                    if (!kt)
                    {
                        dgvnh.Columns["MaNH"].HeaderText = "Mã Ngành Học";
                        dgvnh.Columns["TenNH"].HeaderText = "Tên Ngành Học";
                        dgvnh.Columns["MaBM"].HeaderText = "Mã Bộ Môn";
                        MessageBox.Show($"Ngành học có mã {this.txtmanh.Text} không tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi người dùng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi không thể xóa dữ liệu !", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Hủy xóa dữ liệu.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnsuanh_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.txtmanh.Text == "Nhập mã ngành học" || this.txtmanh.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập mã số sinh viên. Vui lòng điền thông tin trước khi tiếp tục.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    this.txtmanh.Focus();
                    return;
                }
                DataTable dtnh = nh.getdsNganhHoc();
                dgvnh.DataSource = dtnh;
                bool kt = false;
                int dem = 0;
                foreach (DataGridViewRow row in dgvnh.Rows)
                {
                    if (row.Cells["MaNH"].Value != null && row.Cells["MaNH"].Value.ToString().Trim() == txtmanh.Text.Trim())
                    {
                        if (this.txtmanh.Text == "Nhập mã ngành học" || this.txtmanh.Text == "")
                        {
                            this.txtmanh.Text = row.Cells["MaNH"].Value.ToString();
                        }
                        if (this.txttennh.Text == "Nhập tên ngành học" || this.txttennh.Text == "")
                        {
                            this.txttennh.Text = row.Cells["TenNH"].Value.ToString();
                            this.txttennh.ForeColor = Color.Black;
                            dem += 1;
                        }
                        if (this.cbmabmnh.Text == "Chọn bộ môn")
                        {
                            this.cbmabmnh.SelectedValue = row.Cells["MaBM"].Value.ToString().Trim();
                            this.cbmabmnh.Text = this.cbmabmnh.GetItemText(this.cbmabmnh.SelectedItem);
                            dem += 1;
                        }
                        if (dem == 2)
                        {
                            MessageBox.Show("Chưa nhập thông tin cần cập nhật.\n\nVui lòng kiểm tra và thử lại.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.txtmanh.Focus();
                            return;
                        }
                        nh.Mabm = this.cbmabmnh.SelectedValue.ToString().Trim();
                        nh.Manh = this.txtmanh.Text;
                        nh.Tennh = this.txttennh.Text;
                        nh.updateNganhHoc();
                        DataTable dtnh1 = nh.getdsNganhHoc();
                        dgvnh.DataSource = dtnh1;

                        dgvnh.Columns["MaNH"].HeaderText = "Mã Ngành Học";
                        dgvnh.Columns["TenNH"].HeaderText = "Tên Ngành Học";
                        dgvnh.Columns["MaBM"].HeaderText = "Mã Bộ Môn";
                        load(1);
                        load_cb();
                        if (this.cbmabmnh.SelectedIndex == 0)
                        {
                            this.cbmabmnh.ForeColor = Color.Gray;
                        }
                        else
                        {
                            this.cbmabmnh.ForeColor = Color.Black;
                        }
                        MessageBox.Show("Dữ liệu đã được cập nhật thành công vào hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        kt = true;
                        break;
                    }

                }
                if (!kt)
                {
                    MessageBox.Show($"Ngành học có mã {this.txtmanh.Text} không tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi người dùng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.txtmanh.Focus();
                    dgvnh.Columns["MaNH"].HeaderText = "Mã Ngành Học";
                    dgvnh.Columns["TenNH"].HeaderText = "Tên Ngành Học";
                    dgvnh.Columns["MaBM"].HeaderText = "Mã Bộ Môn";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi cập nhật dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnhuynh_Click(object sender, EventArgs e)
        {
            load(1);
            load_cb();
            this.txttimnh.Text = "";
            Hienthinut(2);
            this.btnhuynh.Enabled = false;
            DataTable dtnh1 = nh.getdsNganhHoc();
            dgvnh.DataSource = dtnh1;
            dgvnh.Columns["MaNH"].HeaderText = "Mã Ngành Học";
            dgvnh.Columns["TenNH"].HeaderText = "Tên Ngành Học";
            dgvnh.Columns["MaBM"].HeaderText = "Mã Bộ Môn";
        }

        private void btnthoatnh_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btncapnhatbmnh_Click(object sender, EventArgs e)
        {
            frmBoMon frmBM = new frmBoMon();
            if (frmBM.ShowDialog() == DialogResult.OK)
            {
                if (this.txtmanh.Text != "Nhập mã ngành học" || this.txttennh.Text != "Nhập tên ngành học" || this.cbmabmnh.SelectedIndex != 0 )
                {
                    this.btnhuynh.Enabled = true;
                    Hienthinut(2);
                    btncapnhatbmnh.BackColor = Color.FromArgb(192, 236, 255);
                    btncapnhatbmnh.ForeColor = Color.Black;
                    if (cbmabmnh.SelectedIndex == 0)
                    {
                        cbmabmnh.ForeColor = Color.Gray;
                    }
                    else
                    {
                        cbmabmnh.ForeColor = Color.Black;
                    }
                }
                else
                {
                    Hienthinut(1);
                    btncapnhatbmnh.BackColor = Color.FromArgb(192, 236, 255);
                    btncapnhatbmnh.ForeColor = Color.Black;
                }
            }
            load_cb();
            btncapnhatbmnh.BackColor = Color.FromArgb(192, 236, 255);
            btncapnhatbmnh.ForeColor = Color.Black;
        }

        private void dgvnh_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int id = e.RowIndex;
            if (id == dgvnh.NewRowIndex || id < 0)
            {
                load(1);
                Hienthinut(2);
                MessageBox.Show("Dữ liệu rỗng!");
            }
            else
            {
                this.btnhuynh.Enabled = true;
                Hienthinut(1);
                this.txtmanh.ForeColor = Color.Black;
                this.txttennh.ForeColor = Color.Black;
                this.cbmabmnh.ForeColor = Color.Black;

                this.txtmanh.Text = dgvnh.Rows[id].Cells[0].Value.ToString();
                this.txttennh.Text = dgvnh.Rows[id].Cells[1].Value.ToString();
                this.cbmabmnh.SelectedValue = dgvnh.Rows[id].Cells[2].Value.ToString().Trim();
                this.cbmabmnh.Text = this.cbmabmnh.GetItemText(this.cbmabmnh.SelectedItem);
            }

        }

        private void txt_Enter(object sender, EventArgs e)
        {
            TextBox tx = (TextBox)sender;
            if (tx.Text == this.txtmanh.Text && tx.Text == "Nhập mã ngành học")
            {
                this.txtmanh.Text = "";
                this.txtmanh.ForeColor = Color.Black;
            }
            else if (tx.Text == this.txttennh.Text && tx.Text == "Nhập tên ngành học")
            {
                this.txttennh.Text = "";
                this.txttennh.ForeColor = Color.Black;
            }
        }

        private void txt_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(this.txtmanh.Text))
            {
                this.txtmanh.Text = "Nhập mã ngành học";
                this.txtmanh.ForeColor = Color.Gray;
            }
            else if (string.IsNullOrWhiteSpace(this.txttennh.Text))
            {
                this.txttennh.Text = "Nhập tên ngành học";
                this.txttennh.ForeColor = Color.Gray;
            }
        }
        private void btn_MouseEnter(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.Text == btnthemnh.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnxoanh.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnsuanh.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnhuynh.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnthoatnh.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btncapnhatbmnh.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
        }

        private void btn_MouseLeave(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.Text == btnthemnh.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnxoanh.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnsuanh.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnhuynh.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnthoatnh.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btncapnhatbmnh.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
        }

        private void cbmabmnh_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (txttimnh.Text != "")
                return;
            DataTable dtnh = nh.getdsNganhHoc();
            this.dgvnh.DataSource = dtnh;
            if (this.cbmabmnh.SelectedIndex > 0)
            {
                string mabm = this.cbmabmnh.SelectedValue.ToString().Trim();
                DataTable dtnh2 = new DataTable();
                DataColumn col = new DataColumn();
                col.ColumnName = "MaNH";
                DataColumn col2 = new DataColumn();
                col2.ColumnName = "TenNH";
                DataColumn col3 = new DataColumn();
                col3.ColumnName = "MaBM";
                dtnh2.Columns.Add(col);
                dtnh2.Columns.Add(col2);
                dtnh2.Columns.Add(col3);
                bool kt = false;
                foreach (DataGridViewRow row in dgvnh.Rows)
                {
                    if (row.Cells["MaBM"].Value != null && row.Cells["MaBM"].Value.ToString().Trim() == mabm)
                    {
                        DataRow d1 = dtnh2.NewRow();
                        d1[0] = row.Cells["MaNH"].Value.ToString().Trim();
                        d1[1] = row.Cells["TenNH"].Value.ToString().Trim();
                        d1[2] = row.Cells["MaBM"].Value.ToString().Trim();
                        dtnh2.Rows.Add(d1);
                    }
                }
                this.dgvnh.DataSource = dtnh2;
            }
        }
    }
}
