﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSNQLSV
{
    interface itfKhoa
    {
        void addKhoa();
        DataTable getdsKhoa();
        void deleteKhoa();
        void updateKhoa();
    }
    public abstract class AbstracKhoa
    {
     
        public abstract void addKhoa();
        public abstract DataTable getdsKhoa();
        public abstract void deleteKhoa();
        public abstract void updateKhoa();
    }
    public class Khoa:AbstracKhoa,itfKhoa
    {
        private string makhoa;
        private string tenkhoa;
        private string mota;
        private int namthanhlap;

        ThaotacCSDL db;

        public string Makhoa { get => makhoa; set => makhoa = value; }
        public string Tenkhoa { get => tenkhoa; set => tenkhoa = value; }
        public string Mota { get => mota; set => mota = value; }
        public int Namthanhlap { get => namthanhlap; set => namthanhlap = value; }

        public Khoa():base()
        {
            db = new ThaotacCSDL();
        }
        public override void addKhoa()
        {
            string sql = string.Format("insert into  Khoa values('{0}',N'{1}',N'{2}',{3} )", Makhoa, Tenkhoa,Mota,Namthanhlap);
            Console.WriteLine(sql);
            db.ExecuteNonQuery(sql);
        }
        public override DataTable getdsKhoa()
        {
            string sql = "select * from Khoa";
            DataTable dt = db.Execute(sql);
            return dt;
        }
        public override void deleteKhoa()
        {
            string sql = String.Format("Delete from Khoa where MaKhoa='{0}'", Makhoa);
            Console.WriteLine(sql);
            db.ExecuteNonQuery(sql);
        }
        public override void updateKhoa()
        {
            string sql = String.Format("Update Khoa set MaKhoa='{0}',TenKhoa = N'{1}',MoTa =N'{2}',NamThanhLap = {3} Where MaKhoa='{4}'", Makhoa, Tenkhoa,Mota,Namthanhlap,Makhoa);
            Console.WriteLine(sql);
            db.ExecuteNonQuery(sql);
        }
    }
}
