﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace CSNQLSV
{
    public partial class frmHuongDanSuDung : Form
    {
        public frmHuongDanSuDung()
        {
            InitializeComponent();
        }

        private void frmHuongDanSuDung_Load(object sender, EventArgs e)
        {
            AutoScrollPosition = new Point(0, 0);
            lblmain.Text = " Giao diện chính của hệ thống bao gồm các nút chức năng giúp người dùng điều hướng đến các chức năng quản lý khác nhau. Dưới đây là hướng dẫn sử dụng từng phần:";
            lblsv.Text = @"Form Quản Lý Sinh Viên có các chức năng sau đây:
- **Nút Thêm**: 
  - Khi không nhập đủ dữ liệu, chương trình sẽ hiển thị thông báo yêu cầu nhập đầy đủ thông tin.
  - Ngược lại, nếu dữ liệu hợp lệ, sinh viên sẽ được thêm vào hệ thống.
- **Nút Xóa**: 
  - Nếu không nhập mã số sinh viên, chương trình sẽ thông báo: 'Bạn chưa nhập mã sinh viên. Vui lòng điền thông tin trước khi tiếp tục.'
  - Nếu mã số sinh viên không tồn tại trong hệ thống, thông báo: 'Mã số sinh viên xx không tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!'
  - Nếu mã số sinh viên hợp lệ, sinh viên sẽ được xóa thành công.
- **Nút Cập Nhật**: 
  - Khi nhập đầy đủ thông tin cần thiết, chương trình sẽ cập nhật thông tin sinh viên và thông báo thành công.
  - Nếu thiếu thông tin, nhưng mã số sinh viên hợp lệ, hệ thống sẽ tự động giữ nguyên thông tin cũ của các trường còn trống và tiếp tục cập nhật.
  - Nếu mã số sinh viên không tồn tại, chương trình sẽ thông báo: 'Mã số sinh viên xx không tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!'
- **Nút Hủy**: 
  - Loại bỏ tất cả thao tác vừa thực hiện và tải lại form về trạng thái ban đầu.
- **Nút Xuất File**: 
  - Nếu trong `DataGridView` có dữ liệu, chương trình sẽ hiển thị cửa sổ lưu file và cho phép người dùng lưu file về máy.
  - Nếu `DataGridView` trống, thông báo: 'Dữ liệu rỗng.'
- **Nút Thoát**: 
  - Đóng form Quản Lý Sinh Viên và trở về form chính (Mainfrm).
- **Tìm Kiếm Sinh Viên**: 
  - Khi nhập từ khóa vào ô tìm kiếm và nhấn Enter hoặc nhấn biểu tượng kính lúp, chương trình sẽ tìm kiếm thông tin sinh viên dựa trên các trường: mã số sinh viên, họ tên, giới tính, khoa, hoặc lớp.
  - Nếu tìm thấy, bảng dữ liệu sẽ hiển thị kết quả tương ứng.
  - Nếu không tìm thấy, thông báo: 'Không tìm thấy thông tin sinh viên.'";
            lblket.Text = " (Các Form còn lại trong hệ thống có chức năng tương tự như Form Quản lý Sinh Viên nhưng không có nút Xuất File)";

        }
        private void lbllink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string filePath = @"D:\CƠ SỞ NGHÀNH\WF CSN\Main\HuongDanSuDung.pdf";
            if (File.Exists(filePath))
            {

                Process.Start(new ProcessStartInfo
                {
                    FileName = filePath,
                    UseShellExecute = true
                });
            }
            else
            {
                MessageBox.Show("File không tồn tại! Vui lòng kiểm tra lại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
