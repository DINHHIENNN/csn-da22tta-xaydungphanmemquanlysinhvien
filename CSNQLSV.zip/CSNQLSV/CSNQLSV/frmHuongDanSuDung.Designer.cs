﻿namespace CSNQLSV
{
    partial class frmHuongDanSuDung
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblmain = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblsv = new System.Windows.Forms.Label();
            this.lblket = new System.Windows.Forms.Label();
            this.btnthoathdsd = new System.Windows.Forms.Button();
            this.lbllink = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::CSNQLSV.Properties.Resources.main;
            this.pictureBox1.Location = new System.Drawing.Point(143, 124);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(665, 523);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lblmain
            // 
            this.lblmain.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmain.Location = new System.Drawing.Point(106, 674);
            this.lblmain.Name = "lblmain";
            this.lblmain.Size = new System.Drawing.Size(800, 82);
            this.lblmain.TabIndex = 23;
            this.lblmain.Text = "main";
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::CSNQLSV.Properties.Resources.sv1;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Location = new System.Drawing.Point(143, 759);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(665, 523);
            this.button1.TabIndex = 24;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(275, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(356, 35);
            this.label1.TabIndex = 25;
            this.label1.Text = "HƯỚNG DẪN SỬ DỤNG";
            // 
            // lblsv
            // 
            this.lblsv.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsv.Location = new System.Drawing.Point(102, 1298);
            this.lblsv.Name = "lblsv";
            this.lblsv.Size = new System.Drawing.Size(804, 715);
            this.lblsv.TabIndex = 27;
            this.lblsv.Text = "sv";
            // 
            // lblket
            // 
            this.lblket.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblket.Location = new System.Drawing.Point(87, 2040);
            this.lblket.Name = "lblket";
            this.lblket.Size = new System.Drawing.Size(804, 36);
            this.lblket.TabIndex = 29;
            this.lblket.Text = "kết";
            // 
            // btnthoathdsd
            // 
            this.btnthoathdsd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnthoathdsd.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnthoathdsd.Location = new System.Drawing.Point(687, 79);
            this.btnthoathdsd.Name = "btnthoathdsd";
            this.btnthoathdsd.Size = new System.Drawing.Size(121, 39);
            this.btnthoathdsd.TabIndex = 31;
            this.btnthoathdsd.Text = "Thoát";
            this.btnthoathdsd.UseVisualStyleBackColor = false;
            // 
            // lbllink
            // 
            this.lbllink.AutoSize = true;
            this.lbllink.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllink.Location = new System.Drawing.Point(139, 99);
            this.lbllink.Name = "lbllink";
            this.lbllink.Size = new System.Drawing.Size(199, 22);
            this.lbllink.TabIndex = 32;
            this.lbllink.TabStop = true;
            this.lbllink.Text = "Xem tài liệu hướng dẫn ";
            this.lbllink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lbllink_LinkClicked);
            // 
            // frmHuongDanSuDung
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.AutoScrollMinSize = new System.Drawing.Size(800, 1770);
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(244)))), ((int)(((byte)(251)))));
            this.ClientSize = new System.Drawing.Size(931, 641);
            this.Controls.Add(this.lbllink);
            this.Controls.Add(this.btnthoathdsd);
            this.Controls.Add(this.lblket);
            this.Controls.Add(this.lblsv);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblmain);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button1);
            this.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmHuongDanSuDung";
            this.Text = "frmHuongDanSuDung";
            this.Load += new System.EventHandler(this.frmHuongDanSuDung_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblmain;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblsv;
        private System.Windows.Forms.Label lblket;
        private System.Windows.Forms.Button btnthoathdsd;
        private System.Windows.Forms.LinkLabel lbllink;
    }
}