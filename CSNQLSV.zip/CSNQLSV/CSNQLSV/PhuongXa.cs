﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSNQLSV
{
    interface itfPhuongXa
    {
        void addPhuongXa();
        DataTable getdsPhuongXa();
        void deletePhuongXa();
        void updatePhuongXa();
    }
    public abstract class AbstracPhuongXa
    {
        
        public abstract void addPhuongXa();
        public abstract DataTable getdsPhuongXa();
        public abstract void deletePhuongXa();
        public abstract void updatePhuongXa();
    }
    public class PhuongXa:AbstracPhuongXa,itfPhuongXa
    {
        private string mapx;
        private string tenpx;
        private string maht;
        ThaotacCSDL db;

        public string Mapx { get => mapx; set => mapx = value; }
        public string Tenpx { get => tenpx; set => tenpx = value; }
        public string Maht { get => maht; set => maht = value; }

        public PhuongXa():base()
        {
            db = new ThaotacCSDL();
        }
        public override void addPhuongXa()
        {
            string sql = string.Format("insert into  PhuongXa values('{0}',N'{1}','{2}' )", Mapx, Tenpx, Maht);
            Console.WriteLine(sql);
            db.ExecuteNonQuery(sql);
        }
        public override DataTable getdsPhuongXa()
        {
            string sql = "select * from PhuongXa";
            DataTable dt = db.Execute(sql);
            return dt;
        }
        public override void deletePhuongXa()
        {
            string sql = String.Format("Delete from PhuongXa where MaPXa='{0}'", Mapx);
            Console.WriteLine(sql);
            db.ExecuteNonQuery(sql);
        }
        public override void updatePhuongXa()
        {
            string sql = String.Format("Update PhuongXa set MaPXa='{0}',TenPXa = N'{1}',MaHuyen='{2}' Where MaPXa='{3}'", Mapx, Tenpx, Maht,Mapx);
            Console.WriteLine(sql);
            db.ExecuteNonQuery(sql);
        }
    }
}
