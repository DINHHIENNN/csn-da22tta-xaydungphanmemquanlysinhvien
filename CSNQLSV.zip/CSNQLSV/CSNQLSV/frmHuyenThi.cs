﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSNQLSV
{
    public partial class frmHuyenThi : Form
    {
        HuyenThi ht;
        TinhThanh t;
        public frmHuyenThi()
        {
            InitializeComponent();
            ht=new HuyenThi();
            t=new TinhThanh();
        }

        private void frmHuyenThi_Load(object sender, EventArgs e)
        {
            dgvht.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DataTable dtht = ht.getdsHuyenThi();
            this.dgvht.DataSource = dtht;
            load_cb();
            load(1);
            Hienthinut(2);
            dgvht.Columns["MaHT"].HeaderText = "Mã Huyện/Thị";
            dgvht.Columns["TenHT"].HeaderText = "Tên Huyện/Thị";
            dgvht.Columns["MaTT"].HeaderText = "Mã Tỉnh/Thành";
            dgvht.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dgvht.DefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Regular);
            Image timbmicon = Properties.Resources.tim;
            Image resizetimbmicon = new Bitmap(timbmicon, new Size(26, 26));
            btntimht.Image = resizetimbmicon;
        }
        public void Hienthinut(int x)
        {
            if (x == 1)
            {
                this.btnxoaht.Enabled = true;
                this.btnsuaht.Enabled = true;
                this.btnthemht.Enabled = true;
            }
            else if (x == 2)
            {
                this.btnxoaht.Enabled = false;
                this.btnsuaht.Enabled = false;
                this.btnthemht.Enabled = false;
            }

        }
        public void load_cb()
        {
            DataTable dtt = t.getdsTinhThanh();
            DataRow dr = dtt.NewRow();
            dr[dtt.Columns[0].ColumnName] = DBNull.Value;
            dr[dtt.Columns[1].ColumnName] = "Chọn tỉnh/thành";
            dtt.Rows.InsertAt(dr, 0);

            this.cbmatht.DataSource = dtt;
            this.cbmatht.ValueMember = dtt.Columns[0].ColumnName.ToString();
            this.cbmatht.DisplayMember = dtt.Columns[1].ColumnName.ToString();
            cbmatht.DrawMode = DrawMode.OwnerDrawFixed;
            cbmatht.DrawItem += cbmaht_DrawItem;
        }
        public void load(int x)
        {
            if (x == 1)
            {
                this.txtmaht.Text = "Nhập mã huyện/thị";
                this.txttenht.Text = "Nhập tên huyện/thị";
                this.txtmaht.ForeColor = Color.Gray;
                this.txttenht.ForeColor = Color.Gray;
                this.ActiveControl = this.txtmaht;
                this.btnhuyht.Enabled = false;
            }
            else if (x == 2)
            {
                this.txtmaht.ForeColor = Color.Black;
                this.txttenht.ForeColor = Color.Black;
                this.ActiveControl = this.txtmaht;
                this.btnhuyht.Enabled = false;

            }

        }

        private void dgvht_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int id = e.RowIndex;
            if (id == dgvht.NewRowIndex || id < 0)
            {
                load(1);
                Hienthinut(2);
                MessageBox.Show("Dữ liệu rỗng!");
            }
            else
            {
                this.btnhuyht.Enabled = true;
                Hienthinut(1);
                this.txtmaht.ForeColor = Color.Black;
                this.txttenht.ForeColor = Color.Black;
                this.cbmatht.ForeColor = Color.Black;

                this.txtmaht.Text = dgvht.Rows[id].Cells[0].Value.ToString();
                this.txttenht.Text = dgvht.Rows[id].Cells[2].Value.ToString();
                this.cbmatht.SelectedValue = dgvht.Rows[id].Cells[1].Value.ToString().Trim();
                this.cbmatht.Text = this.cbmatht.GetItemText(this.cbmatht.SelectedItem);
            }

        }
        private void cbmaht_DrawItem(object sender, DrawItemEventArgs e)
        {

            if (e.Index < 0) return;
            ComboBox comboBox = sender as ComboBox;
            string text = comboBox.GetItemText(comboBox.Items[e.Index]);


            Color textColor = text == "Chọn tỉnh/thành" ? Color.Gray : Color.Black;

            e.DrawBackground();
            using (Brush brush = new SolidBrush(textColor))
            {
                e.Graphics.DrawString(text, e.Font, brush, e.Bounds);
            }
            e.DrawFocusRectangle();
        }

        private void btnthemht_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.txtmaht.Text == "Nhập mã huyện/thị" ||this.txtmaht.Text=="")
                {
                    MessageBox.Show("Vui lòng nhập Mã huyện/thị!");
                    this.txtmaht.Focus();
                }
                else if (this.txttenht.Text == "Nhập tên huyện/thị" || this.txttenht.Text ==" ")
                {
                    MessageBox.Show("Vui lòng nhập Tên huyện/thị!");
                    this.txttenht.Focus();
                }
                else if (this.cbmatht.Text == "Chọn tỉnh/thành")
                {
                    MessageBox.Show("Vui lòng Chọn tỉnh/thành!");
                }
                else
                {
                    ht.Matinh = this.cbmatht.SelectedValue.ToString().Trim();
                    ht.Maht = this.txtmaht.Text;
                    ht.Tenht = this.txttenht.Text;
                    ht.addHuyenThi();
                    DataTable dtht = ht.getdsHuyenThi();
                    dgvht.DataSource = dtht;
                    dgvht.Columns["MaHT"].HeaderText = "Mã Huyện/Thị";
                    dgvht.Columns["TenHT"].HeaderText = "Tên Huyện/Thị";
                    dgvht.Columns["MaTT"].HeaderText = "Mã Tỉnh/Thành";
                    load(1);
                    load_cb();
                    MessageBox.Show("Dữ liệu đã được thêm thành công vào hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Huyện/Thị có mã {this.txtmaht.Text} đã tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnxoaht_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa dữ liệu này không?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                try
                {
                    if (this.txtmaht.Text == "Nhập mã huyện/thị" || this.txtmaht.Text == "")
                    {
                        MessageBox.Show("Bạn chưa nhập mã huyện/thị. Vui lòng điền thông tin trước khi tiếp tục.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        this.txtmaht.Focus();
                        return;
                    }
                    DataTable dtht1 = ht.getdsHuyenThi();
                    dgvht.DataSource = dtht1;
                    bool kt = false;
                    foreach (DataGridViewRow row in dgvht.Rows)
                    {
                        if (row.Cells["MaHT"].Value != null && row.Cells["MaHT"].Value.ToString().Trim() == txtmaht.Text.Trim())
                        {
                            ht.Maht = this.txtmaht.Text;
                            ht.deleteHuyenThi();
                            DataTable dtht = ht.getdsHuyenThi();
                            dgvht.DataSource = dtht;
                            dgvht.Columns["MaHT"].HeaderText = "Mã Huyện/Thị";
                            dgvht.Columns["TenHT"].HeaderText = "Tên Huyện/Thị";
                            dgvht.Columns["MaTT"].HeaderText = "Mã Tỉnh/Thành";
                            load_cb();
                            load(1);
                            this.btnhuyht.Enabled = true;
                            kt = true;
                            MessageBox.Show("Dữ liệu đã được xóa thành công khỏi hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            break;
                        }
                    }
                    if (!kt)
                    {
                        dgvht.Columns["MaHT"].HeaderText = "Mã Huyện/Thị";
                        dgvht.Columns["TenHT"].HeaderText = "Tên Huyện/Thị";
                        dgvht.Columns["MaTT"].HeaderText = "Mã Tỉnh/Thành";
                        MessageBox.Show($"Huyện/Thị có mã {this.txtmaht.Text} không tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi người dùng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi không thể xóa dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Hủy xóa dữ liệu.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnsuaht_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.txtmaht.Text == "Nhập mã huyện/thị" || this.txtmaht.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập mã huyện/thị. Vui lòng điền thông tin trước khi tiếp tục.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    this.txtmaht.Focus();
                    return;
                }
                DataTable dtht1 = ht.getdsHuyenThi();
                dgvht.DataSource = dtht1;
                bool kt = false;
                int dem = 0;
                foreach (DataGridViewRow row in dgvht.Rows)
                {
                    if (row.Cells["MaHT"].Value != null && row.Cells["MaHT"].Value.ToString().Trim() == txtmaht.Text.Trim())
                    {
                        if (this.txttenht.Text == "Nhập tên huyện/thị" || this.txttenht.Text == "")
                        {
                            this.txttenht.Text = row.Cells["TenHT"].Value.ToString();
                            this.txttenht.ForeColor = Color.Black;
                            dem += 1;
                        }
                        if (this.cbmatht.Text == "Chọn tỉnh/thành")
                        {
                            if (row.Cells["MaTT"].Value != null)
                            {
                                this.cbmatht.SelectedValue = row.Cells["MaTT"].Value.ToString().Trim();
                                this.cbmatht.Text = this.cbmatht.GetItemText(this.cbmatht.SelectedItem);
                                dem += 1;
                            }
                        }
                        if (dem == 2)
                        {
                            MessageBox.Show("Chưa thay đổi thông tin cần cập nhật.\n\nVui lòng kiểm tra và thử lại.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.txtmaht.Focus();
                            return;
                        }
                        ht.Matinh = this.cbmatht.SelectedValue.ToString().Trim();
                        ht.Maht = this.txtmaht.Text;
                        ht.Tenht = this.txttenht.Text;
                        ht.updateHuyenThi();
                        DataTable dtht = ht.getdsHuyenThi();
                        dgvht.DataSource = dtht;
                        dgvht.Columns["MaHT"].HeaderText = "Mã Huyện/Thị";
                        dgvht.Columns["TenHT"].HeaderText = "Tên Huyện/Thị";
                        dgvht.Columns["MaTT"].HeaderText = "Mã Tỉnh/Thành";
                        load(1);
                        load_cb();
                        if (this.cbmatht.SelectedIndex == 0)
                        {
                            this.cbmatht.ForeColor = Color.Gray;
                        }
                        else
                        {
                            this.cbmatht.ForeColor = Color.Black;
                        }
                        this.btnhuyht.Enabled = true;
                        kt = true;
                        MessageBox.Show("Dữ liệu đã được cập nhật thành công vào hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                    }
                }
                if (!kt)
                {
                    dgvht.Columns["MaHT"].HeaderText = "Mã Huyện/Thị";
                    dgvht.Columns["TenHT"].HeaderText = "Tên Huyện/Thị";
                    dgvht.Columns["MaTT"].HeaderText = "Mã Tỉnh/Thành";
                    MessageBox.Show($"Huyện/Thị có mã {this.txtmaht.Text} không tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi người dùng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.txtmaht.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi xập nhật dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnhuyht_Click(object sender, EventArgs e)
        {
            load(1);
            load_cb();
            this.txttimht.Text = "";
            Hienthinut(2);
            this.btnhuyht.Enabled = false;
            DataTable dtht = ht.getdsHuyenThi();
            dgvht.DataSource = dtht;
            dgvht.Columns["MaHT"].HeaderText = "Mã Huyện/Thị";
            dgvht.Columns["TenHT"].HeaderText = "Tên Huyện/Thị";
            dgvht.Columns["MaTT"].HeaderText = "Mã Tỉnh/Thành";
        }

        private void btnthoatht_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            this.Close();
        }

      

        private void btncapnhatmaht_Click(object sender, EventArgs e)
        {
            frmTinhThanh frmtt = new frmTinhThanh();
            if (frmtt.ShowDialog() == DialogResult.OK)
            {
                if (this.txtmaht.Text != "Nhập mã huyện/thị" || this.txttenht.Text != "Nhập tên huyện/thị" || this.cbmatht.SelectedIndex != 0)
                {
                    this.btnhuyht.Enabled = true;
                    Hienthinut(2);
                    btncapnhatmaht.BackColor = Color.FromArgb(192, 236, 255);
                    btncapnhatmaht.ForeColor = Color.Black;
                    if (cbmatht.SelectedIndex == 0)
                    {
                        cbmatht.ForeColor = Color.Gray;
                    }
                    else
                    {
                        cbmatht.ForeColor = Color.Black;
                    }
                }
                else
                {
                    Hienthinut(1);
                    btncapnhatmaht.BackColor = Color.FromArgb(192, 236, 255);
                    btncapnhatmaht.ForeColor = Color.Black;
                }
            }
            load_cb();
            btncapnhatmaht.BackColor = Color.FromArgb(192, 236, 255);
            btncapnhatmaht.ForeColor = Color.Black;
        }

        private void btntimht_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(this.txttimht.Text.Trim()))
            {
                MessageBox.Show("Vui lòng nhập từ khóa tìm kiếm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            DataTable dtht = ht.getdsHuyenThi();
            dgvht.DataSource = dtht;
            DataTable dt_tim = new DataTable();
            DataColumn col1 = new DataColumn();
            col1.ColumnName = "MaHT";
            DataColumn col2 = new DataColumn();
            col2.ColumnName = "TenHT";
            DataColumn col3 = new DataColumn();
            col3.ColumnName = "MaTT";
            dt_tim.Columns.Add(col1);
            dt_tim.Columns.Add(col2);
            dt_tim.Columns.Add(col3);
            bool kt = false;
            foreach (DataGridViewRow row in dgvht.Rows)
            {
                if (row.Cells["MaHT"].Value != null && row.Cells["MaHT"].Value.ToString().Trim() == txttimht.Text.Trim())
                {
                    DataRow dr = dt_tim.NewRow();
                    dr["MaHT"] = row.Cells["MaHT"].Value.ToString();
                    dr["TenHT"] = row.Cells["TenHT"].Value.ToString();
                    dr["MaTT"] = row.Cells["MaTT"].Value.ToString();
                    dt_tim.Rows.Add(dr);
                    kt = true;
                }
            }
            load(1);
            load_cb();
            Hienthinut(2);
            this.dgvht.DataSource = dt_tim;
            if (!kt)
            {
                MessageBox.Show("Không tìm thấy thông tin bộ môn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            this.btnhuyht.Enabled = true;
        }

        private void txttimht_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btntimht_Click(sender, e);
            }
        }

        private void Textchange(object sender, EventArgs e)
        {
            bool isMahtEmpty = string.IsNullOrWhiteSpace(this.txtmaht.Text) || this.txtmaht.Text == "Nhập mã huyện/thị";
            bool isTenhtEmpty = string.IsNullOrWhiteSpace(this.txttenht.Text) || this.txttenht.Text == "Nhập tên huyện/thị";
            bool isTimhtEmpty = string.IsNullOrWhiteSpace(this.txttimht.Text);
            bool isCbtinhNotSelected = this.cbmatht.SelectedIndex == 0;
            if (cbmatht.SelectedIndex == 0)
            {
                cbmatht.ForeColor = Color.Gray;
            }
            else
            {
                cbmatht.ForeColor = Color.Black;
            }

            if (isMahtEmpty && isTenhtEmpty && isCbtinhNotSelected)
            {
                if (isTimhtEmpty)
                {
                    this.btnhuyht.Enabled = false;
                }
                else
                {
                    this.btnhuyht.Enabled = true;
                }
                Hienthinut(2);
            }
            else if (isMahtEmpty || isTenhtEmpty || isCbtinhNotSelected)
            {
                if (isTimhtEmpty)
                {
                    this.btnhuyht.Enabled = true;
                }
                else
                {
                    this.btnhuyht.Enabled = true;
                }
                Hienthinut(1);
            }
            else if ((!isMahtEmpty && !isTenhtEmpty  && !isCbtinhNotSelected))
            {

                if (isTimhtEmpty)
                {
                    this.btnhuyht.Enabled = true;
                }
                else
                {
                    this.btnhuyht.Enabled = true;
                }
                Hienthinut(1);
            }
        }

        private void txt_Enter(object sender, EventArgs e)
        {
            TextBox tx = (TextBox)sender;
            if (tx.Text == this.txtmaht.Text && tx.Text == "Nhập mã huyện/thị")
            {
                this.txtmaht.Text = "";
                this.txtmaht.ForeColor = Color.Black;
            }
            else if (tx.Text == this.txttenht.Text && tx.Text == "Nhập tên huyện/thị")
            {
                this.txttenht.Text = "";
                this.txttenht.ForeColor = Color.Black;
            }
        }

        private void txt_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(this.txtmaht.Text))
            {
                this.txtmaht.Text = "Nhập mã huyện/thị";
                this.txtmaht.ForeColor = Color.Gray;
            }
            else if (string.IsNullOrWhiteSpace(this.txttenht.Text))
            {
                this.txttenht.Text = "Nhập tên huyện/thị";
                this.txttenht.ForeColor = Color.Gray;
            }
        }

        private void btn_MouseEnter(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.Text == btnthemht.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnxoaht.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnsuaht.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnhuyht.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnthoatht.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btncapnhatmaht.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
        }

        private void btn_MouseLeave(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.Text == btnthemht.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnxoaht.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnsuaht.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnhuyht.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnthoatht.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btncapnhatmaht.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
        }

        private void cbmatht_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (txttimht.Text != "")
                return;
            DataTable dtht = ht.getdsHuyenThi();
            this.dgvht.DataSource = dtht;
            if (this.cbmatht.SelectedIndex > 0)
            {
                string maht = this.cbmatht.SelectedValue.ToString().Trim();
                DataTable dtht2 = new DataTable();
                DataColumn col = new DataColumn();
                col.ColumnName = "MaHT";
                DataColumn col2 = new DataColumn();
                col2.ColumnName = "MaTT";
                DataColumn col3 = new DataColumn();
                col3.ColumnName = "TenHT";
                dtht2.Columns.Add(col);
                dtht2.Columns.Add(col2);
                dtht2.Columns.Add(col3);
                bool kt = false;
                foreach (DataGridViewRow row in dgvht.Rows)
                {
                    if (row.Cells["MaTT"].Value != null && row.Cells["MaTT"].Value.ToString().Trim() == maht)
                    {
                        DataRow d1 = dtht2.NewRow();
                        d1[0] = row.Cells["MaHT"].Value.ToString().Trim();
                        d1[1] = row.Cells["MaTT"].Value.ToString().Trim();
                        d1[2] = row.Cells["TenHT"].Value.ToString().Trim();
                        dtht2.Rows.Add(d1);
                    }
                }
                this.dgvht.DataSource = dtht2;
            }
            
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
