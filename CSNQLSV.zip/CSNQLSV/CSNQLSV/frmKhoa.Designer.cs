﻿namespace CSNQLSV
{
    partial class frmKhoa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtmakhoa = new System.Windows.Forms.TextBox();
            this.txttenkhoa = new System.Windows.Forms.TextBox();
            this.txtnamtlkhoa = new System.Windows.Forms.TextBox();
            this.btnthoatkhoa = new System.Windows.Forms.Button();
            this.rtxtmotakhoa = new System.Windows.Forms.RichTextBox();
            this.btnthemkhoa = new System.Windows.Forms.Button();
            this.btnsuakhoa = new System.Windows.Forms.Button();
            this.btnhuykhoa = new System.Windows.Forms.Button();
            this.btnxoakhoa = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.dgvkhoa = new System.Windows.Forms.DataGridView();
            this.btntim = new System.Windows.Forms.Button();
            this.txttim = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvkhoa)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(303, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(245, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "QUẢN LÝ KHOA";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 10F);
            this.label2.Location = new System.Drawing.Point(42, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Mã Khoa";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 10F);
            this.label4.Location = new System.Drawing.Point(42, 77);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 19);
            this.label4.TabIndex = 1;
            this.label4.Text = "Tên Khoa";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 10F);
            this.label3.Location = new System.Drawing.Point(42, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 19);
            this.label3.TabIndex = 1;
            this.label3.Text = "Mô tả";
            // 
            // txtmakhoa
            // 
            this.txtmakhoa.Font = new System.Drawing.Font("Arial", 10F);
            this.txtmakhoa.Location = new System.Drawing.Point(184, 36);
            this.txtmakhoa.Name = "txtmakhoa";
            this.txtmakhoa.Size = new System.Drawing.Size(405, 27);
            this.txtmakhoa.TabIndex = 2;
            this.txtmakhoa.TextChanged += new System.EventHandler(this.Textchange);
            this.txtmakhoa.Enter += new System.EventHandler(this.Enter_click);
            this.txtmakhoa.Leave += new System.EventHandler(this.txt_leave);
            // 
            // txttenkhoa
            // 
            this.txttenkhoa.Font = new System.Drawing.Font("Arial", 10F);
            this.txttenkhoa.Location = new System.Drawing.Point(184, 74);
            this.txttenkhoa.Name = "txttenkhoa";
            this.txttenkhoa.Size = new System.Drawing.Size(405, 27);
            this.txttenkhoa.TabIndex = 2;
            this.txttenkhoa.TextChanged += new System.EventHandler(this.Textchange);
            this.txttenkhoa.Enter += new System.EventHandler(this.Enter_click);
            this.txttenkhoa.Leave += new System.EventHandler(this.txt_leave);
            // 
            // txtnamtlkhoa
            // 
            this.txtnamtlkhoa.Font = new System.Drawing.Font("Arial", 10F);
            this.txtnamtlkhoa.Location = new System.Drawing.Point(184, 205);
            this.txtnamtlkhoa.Name = "txtnamtlkhoa";
            this.txtnamtlkhoa.Size = new System.Drawing.Size(255, 27);
            this.txtnamtlkhoa.TabIndex = 2;
            this.txtnamtlkhoa.TextChanged += new System.EventHandler(this.Textchange);
            this.txtnamtlkhoa.Enter += new System.EventHandler(this.Enter_click);
            this.txtnamtlkhoa.Leave += new System.EventHandler(this.txt_leave);
            // 
            // btnthoatkhoa
            // 
            this.btnthoatkhoa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnthoatkhoa.Font = new System.Drawing.Font("Arial", 10F);
            this.btnthoatkhoa.ForeColor = System.Drawing.Color.Black;
            this.btnthoatkhoa.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnthoatkhoa.Location = new System.Drawing.Point(649, 391);
            this.btnthoatkhoa.Name = "btnthoatkhoa";
            this.btnthoatkhoa.Size = new System.Drawing.Size(97, 38);
            this.btnthoatkhoa.TabIndex = 3;
            this.btnthoatkhoa.Text = "Thoát";
            this.btnthoatkhoa.UseVisualStyleBackColor = false;
            this.btnthoatkhoa.Click += new System.EventHandler(this.btnthoat_Click);
            this.btnthoatkhoa.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnthoatkhoa.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // rtxtmotakhoa
            // 
            this.rtxtmotakhoa.Font = new System.Drawing.Font("Arial", 10F);
            this.rtxtmotakhoa.Location = new System.Drawing.Point(184, 115);
            this.rtxtmotakhoa.Name = "rtxtmotakhoa";
            this.rtxtmotakhoa.Size = new System.Drawing.Size(405, 82);
            this.rtxtmotakhoa.TabIndex = 5;
            this.rtxtmotakhoa.Text = "";
            this.rtxtmotakhoa.TextChanged += new System.EventHandler(this.Textchange);
            this.rtxtmotakhoa.Enter += new System.EventHandler(this.rtxt_Enter);
            this.rtxtmotakhoa.Leave += new System.EventHandler(this.rtxt_Leave);
            // 
            // btnthemkhoa
            // 
            this.btnthemkhoa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnthemkhoa.Font = new System.Drawing.Font("Arial", 10F);
            this.btnthemkhoa.ForeColor = System.Drawing.Color.Black;
            this.btnthemkhoa.Location = new System.Drawing.Point(111, 391);
            this.btnthemkhoa.Name = "btnthemkhoa";
            this.btnthemkhoa.Size = new System.Drawing.Size(97, 38);
            this.btnthemkhoa.TabIndex = 3;
            this.btnthemkhoa.Text = "Thêm";
            this.btnthemkhoa.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnthemkhoa.UseVisualStyleBackColor = false;
            this.btnthemkhoa.Click += new System.EventHandler(this.btnthem_Click);
            this.btnthemkhoa.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnthemkhoa.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // btnsuakhoa
            // 
            this.btnsuakhoa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnsuakhoa.Font = new System.Drawing.Font("Arial", 10F);
            this.btnsuakhoa.ForeColor = System.Drawing.Color.Black;
            this.btnsuakhoa.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnsuakhoa.Location = new System.Drawing.Point(340, 391);
            this.btnsuakhoa.Name = "btnsuakhoa";
            this.btnsuakhoa.Size = new System.Drawing.Size(112, 38);
            this.btnsuakhoa.TabIndex = 3;
            this.btnsuakhoa.Text = "Cập nhật";
            this.btnsuakhoa.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnsuakhoa.UseVisualStyleBackColor = false;
            this.btnsuakhoa.Click += new System.EventHandler(this.btnsuakhoa_Click);
            this.btnsuakhoa.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnsuakhoa.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // btnhuykhoa
            // 
            this.btnhuykhoa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnhuykhoa.Font = new System.Drawing.Font("Arial", 10F);
            this.btnhuykhoa.ForeColor = System.Drawing.Color.Black;
            this.btnhuykhoa.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnhuykhoa.Location = new System.Drawing.Point(472, 391);
            this.btnhuykhoa.Name = "btnhuykhoa";
            this.btnhuykhoa.Size = new System.Drawing.Size(97, 38);
            this.btnhuykhoa.TabIndex = 3;
            this.btnhuykhoa.Text = "Hủy";
            this.btnhuykhoa.UseVisualStyleBackColor = false;
            this.btnhuykhoa.Click += new System.EventHandler(this.btnhuykhoa_Click);
            this.btnhuykhoa.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnhuykhoa.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // btnxoakhoa
            // 
            this.btnxoakhoa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnxoakhoa.Font = new System.Drawing.Font("Arial", 10F);
            this.btnxoakhoa.ForeColor = System.Drawing.Color.Black;
            this.btnxoakhoa.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnxoakhoa.Location = new System.Drawing.Point(227, 391);
            this.btnxoakhoa.Name = "btnxoakhoa";
            this.btnxoakhoa.Size = new System.Drawing.Size(97, 38);
            this.btnxoakhoa.TabIndex = 3;
            this.btnxoakhoa.Text = "Xóa";
            this.btnxoakhoa.UseVisualStyleBackColor = false;
            this.btnxoakhoa.Click += new System.EventHandler(this.btnxoakhoa_Click);
            this.btnxoakhoa.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnxoakhoa.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 10F);
            this.label5.Location = new System.Drawing.Point(42, 212);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 19);
            this.label5.TabIndex = 1;
            this.label5.Text = "Năm thành lập";
            // 
            // dgvkhoa
            // 
            this.dgvkhoa.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvkhoa.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvkhoa.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvkhoa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvkhoa.Location = new System.Drawing.Point(21, 37);
            this.dgvkhoa.Name = "dgvkhoa";
            this.dgvkhoa.RowHeadersWidth = 51;
            this.dgvkhoa.RowTemplate.Height = 24;
            this.dgvkhoa.Size = new System.Drawing.Size(772, 224);
            this.dgvkhoa.TabIndex = 4;
            this.dgvkhoa.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Load_khi_Click);
            // 
            // btntim
            // 
            this.btntim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntim.Location = new System.Drawing.Point(736, 67);
            this.btntim.Name = "btntim";
            this.btntim.Size = new System.Drawing.Size(41, 37);
            this.btntim.TabIndex = 25;
            this.btntim.UseVisualStyleBackColor = true;
            this.btntim.Click += new System.EventHandler(this.btntim_Click);
            // 
            // txttim
            // 
            this.txttim.Font = new System.Drawing.Font("Arial", 10F);
            this.txttim.Location = new System.Drawing.Point(553, 73);
            this.txttim.Name = "txttim";
            this.txttim.Size = new System.Drawing.Size(177, 27);
            this.txttim.TabIndex = 24;
            this.txttim.TextChanged += new System.EventHandler(this.Textchange);
            this.txttim.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txttim_KeyDown);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.rtxtmotakhoa);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtmakhoa);
            this.groupBox1.Controls.Add(this.txttenkhoa);
            this.groupBox1.Controls.Add(this.txtnamtlkhoa);
            this.groupBox1.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(111, 106);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(635, 257);
            this.groupBox1.TabIndex = 26;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "THÔNG TIN";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.dgvkhoa);
            this.groupBox2.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 460);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(815, 280);
            this.groupBox2.TabIndex = 27;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "DANH SÁCH KHOA";
            // 
            // frmKhoa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(244)))), ((int)(((byte)(251)))));
            this.ClientSize = new System.Drawing.Size(839, 752);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btntim);
            this.Controls.Add(this.txttim);
            this.Controls.Add(this.btnxoakhoa);
            this.Controls.Add(this.btnhuykhoa);
            this.Controls.Add(this.btnthoatkhoa);
            this.Controls.Add(this.btnsuakhoa);
            this.Controls.Add(this.btnthemkhoa);
            this.Controls.Add(this.label1);
            this.Name = "frmKhoa";
            this.Text = "frmKhoa";
            this.Load += new System.EventHandler(this.frmKhoa_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvkhoa)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtmakhoa;
        private System.Windows.Forms.TextBox txttenkhoa;
        private System.Windows.Forms.TextBox txtnamtlkhoa;
        private System.Windows.Forms.Button btnthemkhoa;
        private System.Windows.Forms.Button btnthoatkhoa;
        private System.Windows.Forms.RichTextBox rtxtmotakhoa;
        private System.Windows.Forms.Button btnsuakhoa;
        private System.Windows.Forms.Button btnhuykhoa;
        private System.Windows.Forms.Button btnxoakhoa;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dgvkhoa;
        private System.Windows.Forms.Button btntim;
        private System.Windows.Forms.TextBox txttim;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}