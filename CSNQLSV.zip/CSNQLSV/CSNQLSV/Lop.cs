﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace CSNQLSV
{
    interface itfLop
    {
        void addLop();
        DataTable getdsLop();
        void deleteLop();
        void updateLop();
    }
    public abstract class AbstracLop
    {
             
        public abstract void addLop();
        public abstract DataTable getdsLop();
        public abstract void deleteLop();
        public abstract void updateLop();
    }
    public class Lop:AbstracLop,itfLop
    {
        private string makh;
        private string manh;
        private string malop;
        private string tenlop;
        ThaotacCSDL db;

        public string Makh { get => makh; set => makh = value; }
        public string Manh { get => manh; set => manh = value; }
        public string Malop { get => malop; set => malop = value; }
        public string Tenlop { get => tenlop; set => tenlop = value; }

        public Lop():base()
        {
            db = new ThaotacCSDL();
        }
        public override void addLop()
        {
            string sql = string.Format("insert into  Lop values('{0}',N'{1}','{2}',N'{3}' )", Makh, Manh, Malop, Tenlop);
            Console.WriteLine(sql);
            db.ExecuteNonQuery(sql);
        }
        public override DataTable getdsLop()
        {
            string sql = "select * from Lop";
            DataTable dt = db.Execute(sql);
            return dt;
        }
        public override void deleteLop()
        {
            string sql = String.Format("Delete from Lop where MaLop='{0}'", Malop);
            Console.WriteLine(sql);
            db.ExecuteNonQuery(sql);
        }
        public override void updateLop()
        {
            string sql = String.Format("Update Lop set MaKH='{0}',MaNH = '{1}',MaLop ='{2}',TenLop = N'{3}' Where MaLop='{4}'", Makh, Manh, Malop,Tenlop,Malop);
            Console.WriteLine(sql);
            db.ExecuteNonQuery(sql);
        }
    }
}
