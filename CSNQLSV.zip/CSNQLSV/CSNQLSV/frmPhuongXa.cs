﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSNQLSV
{
    public partial class frmPhuongXa : Form
    {
        PhuongXa px;
        HuyenThi ht;
        TinhThanh t;
        public frmPhuongXa()
        {
            InitializeComponent();
            px= new PhuongXa(); 
            ht= new HuyenThi();
            t = new TinhThanh();
        }

        private void frmPhuongXa_Load(object sender, EventArgs e)
        {
            dgvpx.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DataTable dtpx = px.getdsPhuongXa();
            this.dgvpx.DataSource = dtpx;
            load_cb();
            load(1);
            Hienthinut(2);
            dgvpx.Columns["MaPXa"].HeaderText = "Mã Phường/Xã";
            dgvpx.Columns["TenPXa"].HeaderText = "Tên Phường/Xã";
            dgvpx.Columns["MaTT"].HeaderText = "Mã Tỉnh/Thành";
            dgvpx.Columns["MaHT"].HeaderText = "Mã Huyện/Thị";
            dgvpx.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dgvpx.DefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Regular);
            Image timbmicon = Properties.Resources.tim;
            Image resizetimbmicon = new Bitmap(timbmicon, new Size(26, 26));
            btntimpx.Image = resizetimbmicon;
        }
        public void Hienthinut(int x)
        {
            if (x == 1)
            {
                this.btnxoapx.Enabled = true;
                this.btnsuapx.Enabled = true;
                this.btnthempx.Enabled = true;
            }
            else if (x == 2)
            {
                this.btnxoapx.Enabled = false;
                this.btnsuapx.Enabled = false;
                this.btnthempx.Enabled = false;
            }

       }
        public void load_cb()
        {
            load_cbht();
            load_cbtinh();
        }
        public void load_cbht()
        {
            DataTable dtht = ht.getdsHuyenThi();
            DataRow dr = dtht.NewRow();
            dr[dtht.Columns[0].ColumnName] = DBNull.Value;
            dr[dtht.Columns[2].ColumnName] = "Chọn huyện/thị";
            dtht.Rows.InsertAt(dr, 0);

            this.cbmahtpx.DataSource = dtht;
            this.cbmahtpx.ValueMember = dtht.Columns[0].ColumnName.ToString();
            this.cbmahtpx.DisplayMember = dtht.Columns[2].ColumnName.ToString();
            cbmahtpx.DrawMode = DrawMode.OwnerDrawFixed;
            cbmahtpx.DrawItem += cbmahtpx_DrawItem;
        }
        public void load_cbtinh()
        {
            DataTable dtt = t.getdsTinhThanh();
            DataRow dr = dtt.NewRow();
            dr[dtt.Columns[0].ColumnName] = DBNull.Value;
            dr[dtt.Columns[1].ColumnName] = "Chọn tỉnh/thành";
            dtt.Rows.InsertAt(dr, 0);

            this.cbmatpx.DataSource = dtt;
            this.cbmatpx.ValueMember = dtt.Columns[0].ColumnName.ToString();
            this.cbmatpx.DisplayMember = dtt.Columns[1].ColumnName.ToString();
            cbmatpx.DrawMode = DrawMode.OwnerDrawFixed;
            cbmatpx.DrawItem += cbmatpx_DrawItem;
        }
        public void load(int x)
        {
            if (x == 1)
            {
                this.txtmapx.Text = "Nhập mã phường/xã";
                this.txttenpx.Text = "Nhập tên phường/xã";
                this.txtmapx.ForeColor = Color.Gray;
                this.txttenpx.ForeColor = Color.Gray;
                this.ActiveControl = this.txtmapx;
                this.btnhuypx.Enabled = false;
            }
            else if (x == 2)
            {
                this.txtmapx.ForeColor = Color.Black;
                this.txttenpx.ForeColor = Color.Black;
                this.ActiveControl = this.txtmapx;
                this.btnhuypx.Enabled = false;
            }

        }

        private void dgvpx_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
            int id = e.RowIndex;
            
            if (id == dgvpx.NewRowIndex || id < 0)
            {
                load(1);
                load_cb();
                Hienthinut(2);
                MessageBox.Show("Dữ liệu rỗng!");
                return;
            }
            else
            {
               
                this.btnhuypx.Enabled = true;
                Hienthinut(1);
                this.txtmapx.ForeColor = Color.Black;
                this.txttenpx.ForeColor = Color.Black;
                this.cbmahtpx.ForeColor = Color.Black;

                this.txtmapx.Text = dgvpx.Rows[id].Cells[0].Value.ToString();
                this.txttenpx.Text = dgvpx.Rows[id].Cells[1].Value.ToString();

                this.cbmatpx.SelectedValue = dgvpx.Rows[id].Cells[3].Value.ToString().Trim();
                this.cbmatpx.Text = this.cbmatpx.GetItemText(this.cbmatpx.SelectedItem);
                DataTable dtpx2 = px.getdsPhuongXa();
                dgvpx.DataSource = dtpx2;
                this.cbmahtpx.SelectedValue = dgvpx.Rows[id].Cells[2].Value.ToString().Trim();
                this.cbmahtpx.Text = this.cbmahtpx.GetItemText(this.cbmahtpx.SelectedItem);
            }

        }

        private void cbmahtpx_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            ComboBox comboBox = sender as ComboBox;
            string text = comboBox.GetItemText(comboBox.Items[e.Index]);


            Color textColor = text == "Chọn huyện/thị" ? Color.Gray : Color.Black;

            e.DrawBackground();
            using (Brush brush = new SolidBrush(textColor))
            {
                e.Graphics.DrawString(text, e.Font, brush, e.Bounds);
            }
            e.DrawFocusRectangle();
        }

        private void btnthempx_Click(object sender, EventArgs e)
        {
            
            try
            {
                if (this.txtmapx.Text == "Nhập mã phường/xã" || this.txtmapx.Text=="")
                {
                    MessageBox.Show("Vui lòng nhập Mã huyện/thị!");
                    this.txtmapx.Focus();
                }
                else if (this.txttenpx.Text == "Nhập tên phường/xã" || this.txttenpx.Text=="")
                {
                    MessageBox.Show("Vui lòng nhập Tên phường/xã!");
                    this.txttenpx.Focus();
                }
                else if (this.cbmahtpx.Text == "Chọn huyện/thị")
                {
                    MessageBox.Show("Vui lòng Chọn huyện/thị!");
                }
                else
                {
                    px.Maht = this.cbmahtpx.SelectedValue.ToString().Trim();
                    px.Mapx = this.txtmapx.Text;
                    px.Tenpx = this.txttenpx.Text;
                    px.addPhuongXa();
                    DataTable dtpx = px.getdsPhuongXa();
                    dgvpx.DataSource = dtpx;
                    dgvpx.Columns["MaPXa"].HeaderText = "Mã Phường/Xã";
                    dgvpx.Columns["TenPXa"].HeaderText = "Tên Phường/Xã";
                    dgvpx.Columns["MaTT"].HeaderText = "Mã Tỉnh/Thành";
                    dgvpx.Columns["MaHT"].HeaderText = "Mã Huyện/Thị";
                    load(1);
                    load_cb();
                    MessageBox.Show("Dữ liệu đã được thêm thành công vào hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Phường/Xã có mã {this.txtmapx.Text} đã tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnxoapx_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa dữ liệu này không?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                try
                {
                    if (this.txtmapx.Text == "Nhập mã phường/xã" || this.txtmapx.Text == "")
                    {
                        MessageBox.Show("Bạn chưa nhập mã phường/xã. Vui lòng điền thông tin trước khi tiếp tục.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        this.txtmapx.Focus();
                        return;
                    }
                    DataTable dtpx1 = px.getdsPhuongXa();
                    dgvpx.DataSource = dtpx1;
                    bool kt = false;
                    foreach (DataGridViewRow row in dgvpx.Rows)
                    {
                        if (row.Cells["MaPXa"].Value != null && row.Cells["MaPXa"].Value.ToString().Trim() == txtmapx.Text.Trim())
                        {
                            px.Mapx = this.txtmapx.Text;
                            px.deletePhuongXa();
                            DataTable dtpx = px.getdsPhuongXa();
                            dgvpx.DataSource = dtpx;
                            dgvpx.Columns["MaPXa"].HeaderText = "Mã Phường/Xã";
                            dgvpx.Columns["TenPXa"].HeaderText = "Tên Phường/Xã";
                            dgvpx.Columns["MaTT"].HeaderText = "Mã Tỉnh/Thành";
                            dgvpx.Columns["MaHT"].HeaderText = "Mã Huyện/Thị";
                            load_cb();
                            load(1);
                            MessageBox.Show("Dữ liệu đã được xóa thành công khỏi hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.btnhuypx.Enabled = true;
                            kt = true;
                            break;
                        }
                    }
                    if (!kt)
                    {
                        dgvpx.Columns["MaPXa"].HeaderText = "Mã Phường/Xã";
                        dgvpx.Columns["TenPXa"].HeaderText = "Tên Phường/Xã";
                        dgvpx.Columns["MaTT"].HeaderText = "Mã Tỉnh/Thành";
                        dgvpx.Columns["MaHT"].HeaderText = "Mã Huyện/Thị";
                        MessageBox.Show($"Phường/Xã có mã {this.txtmapx.Text} không tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi người dùng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi không thể xóa dữ liệu !", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Hủy xóa dữ liệu.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnsuapx_Click(object sender, EventArgs e)
        {

            try
            {
                if (this.txtmapx.Text == "Nhập mã phường/xã" || this.txtmapx.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập mã phường/xã. Vui lòng điền thông tin trước khi tiếp tục.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    this.txtmapx.Focus();
                    return;
                }
                DataTable dtpx1 = px.getdsPhuongXa();
                dgvpx.DataSource = dtpx1;
                bool kt = false;
                int dem = 0;
                foreach (DataGridViewRow row in dgvpx.Rows)
                {
                    if (row.Cells["MaPXa"].Value != null && row.Cells["MaPXa"].Value.ToString().Trim() == txtmapx.Text.Trim())
                    {
                        if (this.txtmapx.Text == "Nhập mã phường/xã" || this.txtmapx.Text == "")
                        {
                            this.txtmapx.Text = row.Cells["MaPXa"].Value.ToString();
                        }
                        if (this.txttenpx.Text == "Nhập tên phường/xã" || this.txttenpx.Text == "")
                        {
                            this.txttenpx.Text = row.Cells["TenPXa"].Value.ToString();
                            this.txttenpx.ForeColor = Color.Black;
                            dem += 1;
                        }
                        if (this.cbmahtpx.Text == "Chọn huyện/thị")
                        {
                            if (row.Cells["MaHT"].Value!=null)
                            {
                                this.cbmahtpx.SelectedValue = row.Cells["MaHT"].Value.ToString().Trim();
                                this.cbmahtpx.Text = this.cbmahtpx.GetItemText(this.cbmahtpx.SelectedItem);
                                dem += 1;
                            }    
                        }
                        if (dem == 2)
                        {
                            MessageBox.Show("Chưa nhập thông tin cần cập nhật.\n\nVui lòng kiểm tra và thử lại.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.txtmapx.Focus();
                            return;
                        }
                        px.Maht = this.cbmahtpx.SelectedValue.ToString().Trim();
                        px.Mapx = this.txtmapx.Text;
                        px.Tenpx = this.txttenpx.Text;
                        px.updatePhuongXa();
                        DataTable dtpx = px.getdsPhuongXa();
                        dgvpx.DataSource = dtpx;
                        dgvpx.Columns["MaPXa"].HeaderText = "Mã Phường/Xã";
                        dgvpx.Columns["TenPXa"].HeaderText = "Tên Phường/Xã";
                        dgvpx.Columns["MaTT"].HeaderText = "Mã Tỉnh/Thành";
                        dgvpx.Columns["MaHT"].HeaderText = "Mã Huyện/Thị";
                        load(1);
                        load_cb();
                        if (this.cbmahtpx.SelectedIndex == 0)
                        {
                            this.cbmahtpx.ForeColor = Color.Gray;
                        }
                        else
                        {
                            this.cbmahtpx.ForeColor = Color.Black;
                        }
                        MessageBox.Show("Dữ liệu đã được cập nhật thành công vào hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        kt = true;
                        break;
                    }
                }
                if (!kt)
                {
                    dgvpx.Columns["MaPXa"].HeaderText = "Mã Phường/Xã";
                    dgvpx.Columns["TenPXa"].HeaderText = "Tên Phường/Xã";
                    dgvpx.Columns["MaTT"].HeaderText = "Mã Tỉnh/Thành";
                    dgvpx.Columns["MaHT"].HeaderText = "Mã Huyện/Thị";
                    MessageBox.Show($"Phường/Xã có mã {this.txtmapx.Text} không tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi người dùng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.txtmapx.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi cập nhật dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnhuypx_Click(object sender, EventArgs e)
        {
            load(1);
            load_cb();
            this.txttimpx.Text = "";
            Hienthinut(2);
            this.btnhuypx.Enabled = false;
            DataTable dtpx = px.getdsPhuongXa();
            dgvpx.DataSource = dtpx;
            dgvpx.Columns["MaPXa"].HeaderText = "Mã Phường/Xã";
            dgvpx.Columns["TenPXa"].HeaderText = "Tên Phường/Xã";
            dgvpx.Columns["MaTT"].HeaderText = "Mã Tỉnh/Thành";
            dgvpx.Columns["MaHT"].HeaderText = "Mã Huyện/Thị";
        }

        private void btnthoatpx_Click(object sender, EventArgs e)
        {
            DialogResult= DialogResult.OK;
            this.Close();
        }

        private void btncapnhatmahtpx_Click(object sender, EventArgs e)
        {
            frmHuyenThi frmht = new frmHuyenThi();
            if (frmht.ShowDialog() == DialogResult.OK)
            {
                if (this.txtmapx.Text != "Nhập mã phường/xã" || this.txttenpx.Text != "Nhập tên phường/xã" || this.cbmahtpx.SelectedIndex != 0)
                {
                    this.btnhuypx.Enabled = true;
                    Hienthinut(2);
                    btncapnhatmahtpx.BackColor = Color.FromArgb(192, 236, 255);
                    btncapnhatmahtpx.ForeColor = Color.Black;
                    if (cbmahtpx.SelectedIndex == 0)
                    {
                        cbmahtpx.ForeColor = Color.Gray;
                    }
                    else
                    {
                        cbmahtpx.ForeColor = Color.Black;
                    }
                }
                else
                {
                    Hienthinut(1);
                    btncapnhatmahtpx.BackColor = Color.FromArgb(192, 236, 255);
                    btncapnhatmahtpx.ForeColor = Color.Black;
                }
            }
            load_cb();
            btncapnhatmahtpx.BackColor = Color.FromArgb(192, 236, 255);
            btncapnhatmahtpx.ForeColor = Color.Black;
        }

        private void btntimpx_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(this.txttimpx.Text.Trim()))
            {
                MessageBox.Show("Vui lòng nhập từ khóa tìm kiếm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            DataTable dtpx = px.getdsPhuongXa();
            dgvpx.DataSource = dtpx;
            bool kt = false;
            foreach (DataGridViewRow row in dgvpx.Rows)
            {
                if (row.Cells["MaPXa"].Value != null && row.Cells["MaPXa"].Value.ToString().Trim() == txttimpx.Text.Trim())
                {
                    this.txtmapx.Text = row.Cells["MaPXa"].Value.ToString();
                    this.txttenpx.Text = row.Cells["TenPXa"].Value.ToString();
                    this.cbmahtpx.SelectedValue = row.Cells["MaHT"].Value.ToString();
                    this.cbmatpx.SelectedValue = row.Cells["MaTT"].Value.ToString();
                    //cbmahtpx.DrawMode = DrawMode.OwnerDrawFixed;
                    //cbmahtpx.DrawItem += cbmahtpx_DrawItem;
                    load(2);
                    kt = true;
                    break;
                }
            }
            if (!kt)
            {
                MessageBox.Show("Không tìm thấy thông tin bộ môn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            this.btnhuypx.Enabled = true;
        }

        private void Textchange(object sender, EventArgs e)
        {
            bool isMapxEmpty = string.IsNullOrWhiteSpace(this.txtmapx.Text) || this.txtmapx.Text == "Nhập mã phường/xã";
            bool isTenpxEmpty = string.IsNullOrWhiteSpace(this.txttenpx.Text) || this.txttenpx.Text == "Nhập tên phường/xã";
            bool isTimpxEmpty = string.IsNullOrWhiteSpace(this.txttimpx.Text);
            bool isCbhtNotSelected = this.cbmahtpx.SelectedIndex == 0;
            bool isCbtNotSelected = this.cbmatpx.SelectedIndex == 0;
            if (cbmahtpx.SelectedIndex == 0)
            {
                cbmahtpx.ForeColor = Color.Gray;
            }
            else
            {
                cbmahtpx.ForeColor = Color.Black;
            }
            if (cbmatpx.SelectedIndex == 0)
            {
                cbmatpx.ForeColor = Color.Gray;
            }
            else
            {
                cbmatpx.ForeColor = Color.Black;
            }
            if (isMapxEmpty && isTenpxEmpty && isCbhtNotSelected && isCbtNotSelected)
            {
                if (isTimpxEmpty)
                {
                    this.btnhuypx.Enabled = false;
                }
                else
                {
                    this.btnhuypx.Enabled = true;
                }
                Hienthinut(2);
            }
            else if (isMapxEmpty || isTenpxEmpty || isCbhtNotSelected || isCbtNotSelected)
            {
                if (isTimpxEmpty)
                {
                    this.btnhuypx.Enabled = true;
                }
                else
                {
                    this.btnhuypx.Enabled = true;
                }
                Hienthinut(1);
            }
            else if ((!isMapxEmpty && !isTenpxEmpty && !isCbhtNotSelected && !isCbtNotSelected))
            {

                if (isTimpxEmpty)
                {
                    this.btnhuypx.Enabled = true;
                }
                else
                {
                    this.btnhuypx.Enabled = true;
                }
                Hienthinut(1);
            }
        }

        private void txt_Enter(object sender, EventArgs e)
        {
            TextBox tx = (TextBox)sender;
            if (tx.Text == this.txtmapx.Text && tx.Text == "Nhập mã phường/xã")
            {
                this.txtmapx.Text = "";
                this.txtmapx.ForeColor = Color.Black;
            }
            else if (tx.Text == this.txttenpx.Text && tx.Text == "Nhập tên phường/xã")
            {
                this.txttenpx.Text = "";
                this.txttenpx.ForeColor = Color.Black;
            }
        }

        private void txt_Leave(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(this.txtmapx.Text))
            {
                this.txtmapx.Text = "Nhập mã phường/xã";
                this.txtmapx.ForeColor = Color.Gray;
            }
            else if (string.IsNullOrWhiteSpace(this.txttenpx.Text))
            {
                this.txttenpx.Text = "Nhập tên phường/xã";
                this.txttenpx.ForeColor = Color.Gray;
            }
        }

        private void txttimpx_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btntimpx_Click(sender, e);
            }
        }
        private void btn_MouseEnter(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.Text == btnthempx.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnxoapx.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnsuapx.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnhuypx.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnthoatpx.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btncapnhatmahtpx.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btncapnhatmatpx.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
        }


        private void cbmatpx_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            ComboBox comboBox = sender as ComboBox;
            string text = comboBox.GetItemText(comboBox.Items[e.Index]);


            Color textColor = text == "Chọn tỉnh/thành" ? Color.Gray : Color.Black;

            e.DrawBackground();
            using (Brush brush = new SolidBrush(textColor))
            {
                e.Graphics.DrawString(text, e.Font, brush, e.Bounds);
            }
            e.DrawFocusRectangle();
         }


        private void cb_SelectedIndexxChange(object sender, EventArgs e)
        {
            if (cbmatpx.SelectedIndex > 0)
                cbmahtpx.Enabled = true;
            else
                cbmahtpx.Enabled = false; ;
            if (!string.IsNullOrEmpty(txttimpx.Text)) return;

            if (cbmatpx.SelectedIndex == 0 && cbmahtpx.SelectedIndex > 0)
            {
                DieuKien1();
            }
            else if (cbmatpx.SelectedIndex > 0 && cbmahtpx.SelectedIndex == 0)
            {
                DieuKien2();
            }
            else if (cbmatpx.SelectedIndex > 0 && cbmahtpx.SelectedIndex > 0)
            {
                DieuKien3();
            }
            else if (cbmatpx.SelectedIndex == 0 && cbmahtpx.SelectedIndex == 0)
            {
                dgvpx.DataSource = px.getdsPhuongXa();
                load_cb();
            }
        }

        private void DieuKien1()
        {
            DataTable dtpx = px.getdsPhuongXa();
            this.dgvpx.DataSource = dtpx;
            string maht = this.cbmahtpx.SelectedValue.ToString().Trim();
            DataTable dtt = t.getdsTinhThanh();
            this.dgvan.DataSource = dtt;

            DataTable dtp = new DataTable();
            DataColumn col = new DataColumn();
            col.ColumnName = "MaTT";
            DataColumn col2 = new DataColumn();
            col2.ColumnName = "TenTT";
            dtp.Columns.Add(col);
            dtp.Columns.Add(col2);
            DataRow d = dtp.NewRow();
            d[0] = "-1"; d[1] = "Chọn tỉnh/thành";
            dtp.Rows.Add(d);

            DataTable dtpx2 = new DataTable();
            DataColumn co = new DataColumn();
            co.ColumnName = "MaPXa";
            DataColumn co2 = new DataColumn();
            co2.ColumnName = "TenPXa";
            DataColumn co3 = new DataColumn();
            co3.ColumnName = "MaHT";
            DataColumn co4 = new DataColumn();
            co4.ColumnName = "MaTT";
            dtpx2.Columns.Add(co);
            dtpx2.Columns.Add(co2);
            dtpx2.Columns.Add(co3);
            dtpx2.Columns.Add(co4);

            bool kt = false;
            foreach (DataGridViewRow row1 in dgvpx.Rows)
            {
                if (row1.Cells["MaHT"].Value != null && row1.Cells["MaHT"].Value.ToString().Trim() == maht)
                {
                    foreach (DataGridViewRow row2 in dgvan.Rows)
                    {
                        if (row2.Cells["MaTT"].Value != null && row2.Cells["MaTT"].Value.ToString().Trim() == row1.Cells["MaTT"].Value.ToString().Trim())
                        {
                            DataRow d1 = dtpx2.NewRow();
                            d1[0] = row1.Cells["MaPXa"].Value.ToString().Trim();
                            d1[1] = row1.Cells["TenPXa"].Value.ToString().Trim();
                            d1[2] = row1.Cells["MaHT"].Value.ToString().Trim();
                            d1[3] = row1.Cells["MaTT"].Value.ToString().Trim();
                            dtpx2.Rows.Add(d1);

                            DataRow an = dtp.NewRow();
                            an[0] = row2.Cells["MaTT"].Value.ToString().Trim();
                            an[1] = row2.Cells["TenTT"].Value.ToString();
                            dtp.Rows.Add(an);
                        }
                    }
                }
            }
            this.dgvpx.DataSource = dtpx2;
            //this.cbmatpx.DataSource = dtp;
            //this.cbmatpx.ValueMember = dtp.Columns[0].ColumnName.ToString();
            //this.cbmatpx.DisplayMember = dtp.Columns[1].ColumnName.ToString();
            //cbmatpx.DrawMode = DrawMode.OwnerDrawFixed;
            //cbmatpx.DrawItem += cbmatpx_DrawItem;
        }
        private void DieuKien2()
        {
            DataTable dtpx = px.getdsPhuongXa();
            this.dgvpx.DataSource = dtpx;
            DataTable dtht = ht.getdsHuyenThi();
            this.dgvan.DataSource = dtht;
            string mat = this.cbmatpx.SelectedValue.ToString().Trim();
            DataTable dtpx2 = new DataTable();
            DataColumn col = new DataColumn();
            col.ColumnName = "MaHT";
            DataColumn col2 = new DataColumn();
            col2.ColumnName = "TenHT";
            DataColumn col3 = new DataColumn();
            col3.ColumnName = "MaTT";
            dtpx2.Columns.Add(col);
            dtpx2.Columns.Add(col2);
            dtpx2.Columns.Add(col3);
            DataRow d = dtpx2.NewRow();
            d[0] = "-1"; d[1] = "Chọn huyện/thị"; d[2] = "NULL";
            dtpx2.Rows.Add(d);

            DataTable dtpxan = new DataTable();
            DataColumn co = new DataColumn();
            co.ColumnName = "MaPXa";
            DataColumn co2 = new DataColumn();
            co2.ColumnName = "TenPXa";
            DataColumn co3 = new DataColumn();
            co3.ColumnName = "MaHT";
            DataColumn co4 = new DataColumn();
            co4.ColumnName = "MaTT";
            dtpxan.Columns.Add(co);
            dtpxan.Columns.Add(co2);
            dtpxan.Columns.Add(co3);
            dtpxan.Columns.Add(co4);
            bool kt = false;
            foreach (DataGridViewRow row in dgvpx.Rows)
            {
                if (row.Cells["MaTT"].Value != null && row.Cells["MaTT"].Value.ToString().Trim() == mat)
                {
                    foreach (DataGridViewRow row1 in dgvan.Rows)
                    {
                        if (row1.Cells["MaTT"].Value != null && row1.Cells["MaTT"].Value.ToString().Trim() == row.Cells["MaTT"].Value.ToString().Trim())
                        {
                            DataRow d1 = dtpx2.NewRow();
                            d1[0] = row1.Cells["MaHT"].Value.ToString().Trim();
                            d1[1] = row1.Cells["TenHT"].Value.ToString();
                            d1[2] = row1.Cells["MaTT"].Value.ToString().Trim();
                            dtpx2.Rows.Add(d1);

                            DataRow an = dtpxan.NewRow();
                            an[0] = row.Cells["MaPXa"].Value.ToString().Trim();
                            an[1] = row.Cells["TenPXa"].Value.ToString();
                            an[2] = row.Cells["MaHT"].Value.ToString().Trim();
                            an[3] = row.Cells["MaTT"].Value.ToString().Trim();
                            dtpxan.Rows.Add(an);
                        }
                    }

                }
            }
            this.dgvpx.DataSource = dtpxan;
            this.cbmahtpx.DataSource = dtpx2;
            this.cbmahtpx.ValueMember = dtpx2.Columns[0].ColumnName.ToString();
            this.cbmahtpx.DisplayMember = dtpx2.Columns[1].ColumnName.ToString();
            cbmahtpx.DrawMode = DrawMode.OwnerDrawFixed;
            cbmahtpx.DrawItem += cbmahtpx_DrawItem;

        }
        private void DieuKien3()
        {
            DataTable dtpx = px.getdsPhuongXa();
            this.dgvpx.DataSource = dtpx;
            string maht = this.cbmahtpx.SelectedValue.ToString().Trim();
            string mat = this.cbmatpx.SelectedValue.ToString().Trim();
            DataTable dtpx2 = new DataTable();
            DataColumn col = new DataColumn();
            col.ColumnName = "MaPXa";
            DataColumn col2 = new DataColumn();
            col2.ColumnName = "TenPXa";
            DataColumn col3 = new DataColumn();
            col3.ColumnName = "MaHT";
            DataColumn col4 = new DataColumn();
            col4.ColumnName = "MaTT";
            dtpx2.Columns.Add(col);
            dtpx2.Columns.Add(col2);
            dtpx2.Columns.Add(col3);
            dtpx2.Columns.Add(col4);

            //DataTable dtht = ht.getdsHuyenThi();
            //this.dgvan.DataSource = dtht;
            //DataTable dtpxht = new DataTable();
            //DataColumn co = new DataColumn();
            //co.ColumnName = "MaHT";
            //DataColumn co2 = new DataColumn();
            //co2.ColumnName = "TenHT";
            //DataColumn co3 = new DataColumn();
            //co3.ColumnName = "MaTT";
            //dtpxht.Columns.Add(co);
            //dtpxht.Columns.Add(co2);
            //dtpxht.Columns.Add(co3);
            //DataRow d = dtpxht.NewRow();
            //d[0] = "-1"; d[1] = "Chọn huyện/thị"; d[2] = "NULL";
            //dtpxht.Rows.Add(d);
            bool kt = false;
            //foreach (DataGridViewRow row in dgvan.Rows)
            //{
            //    if (row.Cells["MaTT"].Value != null && row.Cells["MaTT"].Value.ToString().Trim() == mat)
            //    {
            foreach (DataGridViewRow row1 in dgvpx.Rows)
            {
                if ((row1.Cells["MaHT"].Value != null && row1.Cells["MaHT"].Value.ToString().Trim() == maht) && (row1.Cells["MaTT"].Value != null && row1.Cells["MaTT"].Value.ToString().Trim() == mat))
                {
                    DataRow d1 = dtpx2.NewRow();
                    d1[0] = row1.Cells["MaPXa"].Value.ToString().Trim();
                    d1[1] = row1.Cells["TenPXa"].Value.ToString().Trim();
                    d1[2] = row1.Cells["MaHT"].Value.ToString().Trim();
                    d1[3] = row1.Cells["MaTT"].Value.ToString().Trim();
                    dtpx2.Rows.Add(d1);

                    //DataRow d2 = dtpxht.NewRow();
                    //d2[0] = row.Cells["MaHT"].Value.ToString().Trim();
                    //d2[1] = row.Cells["TenHT"].Value.ToString();
                    //d2[2] = row.Cells["MaTT"].Value.ToString().Trim();
                    //dtpxht.Rows.Add(d2);
                }
            }
               // }
            //}
            this.dgvpx.DataSource = dtpx2;
        }  
        private void btncapnhatmat_Click(object sender, EventArgs e)
        {
            frmTinhThanh frmht = new frmTinhThanh();
            if (frmht.ShowDialog() == DialogResult.OK)
            {
                if (this.txtmapx.Text != "Nhập mã tỉnh/thành" || this.txttenpx.Text != "Nhập tên tỉnh/thành" || this.cbmahtpx.SelectedIndex != 0 || this.cbmatpx.SelectedIndex!=0)
                {
                    this.btnhuypx.Enabled = true;
                    Hienthinut(2);
                    btncapnhatmatpx.BackColor = Color.FromArgb(192, 236, 255);
                    btncapnhatmatpx.ForeColor = Color.Black;
                    if (cbmatpx.SelectedIndex == 0)
                    {
                        cbmatpx.ForeColor = Color.Gray;
                    }
                    else
                    {
                        cbmatpx.ForeColor = Color.Black;
                    }
                }
                else
                {
                    Hienthinut(1);
                    btncapnhatmatpx.BackColor = Color.FromArgb(192, 236, 255);
                    btncapnhatmatpx.ForeColor = Color.Black;
                }
            }
            load_cb();
            btncapnhatmatpx.BackColor = Color.FromArgb(192, 236, 255);
            btncapnhatmatpx.ForeColor = Color.Black;
        }

        private void btnpx_MouseLeave(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.Text == btnthempx.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnxoapx.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnsuapx.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnhuypx.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnthoatpx.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btncapnhatmahtpx.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btncapnhatmatpx.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
        }

        private void frmPhuongXa_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }
    }
}
