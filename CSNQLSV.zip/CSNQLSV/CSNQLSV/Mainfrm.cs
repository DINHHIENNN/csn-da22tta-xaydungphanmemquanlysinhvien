﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSNQLSV
{
    public partial class Mainfrm : Form
    {
        public Mainfrm()
        {
            InitializeComponent();
        }
        private void btn_mouseentre(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.Text == btnsv.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnbm.Text)
            {
                btn.BackColor = Color.FromArgb(103, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnnh.Text)
            {
                btn.BackColor = Color.FromArgb(103, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnkh.Text)
            {
                btn.BackColor = Color.FromArgb(103, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnl.Text)
            {
                btn.BackColor = Color.FromArgb(103, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnt.Text)
            {
                btn.BackColor = Color.FromArgb(103, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnht.Text)
            {
                btn.BackColor = Color.FromArgb(103, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnpx.Text)
            {
                btn.BackColor = Color.FromArgb(103, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnk.Text)
            {
                btn.BackColor = Color.FromArgb(103, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnhd.Text)
            {
                btn.BackColor = Color.FromArgb(103, 191, 255);
                btn.ForeColor = Color.Black;
            }
        }


        private void btn_modeleave(object sender, EventArgs e)
        {
            
            Button btn = (Button)sender;
            if (btn.Text == btnsv.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnbm.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnnh.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnkh.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnl.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnt.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnht.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnpx.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnk.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnhd.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
                }

        private void btnsv_Click(object sender, EventArgs e)
        {
            frmSinhVien frm = new frmSinhVien();
            if(frm.ShowDialog()==DialogResult.OK)
            {

            }    
        }

        private void btnhd_Click(object sender, EventArgs e)
        {
           frmHuongDanSuDung frm = new frmHuongDanSuDung();
            if (frm.ShowDialog() == DialogResult.OK)
            {

            }
        }

        private void btnkh_Click(object sender, EventArgs e)
        {
            frmKhoaHoc frm = new frmKhoaHoc();
            if (frm.ShowDialog() == DialogResult.OK)
            {

            }
        }

        private void btnnh_Click(object sender, EventArgs e)
        {
            frmNganhHoc frm = new frmNganhHoc();
            if (frm.ShowDialog() == DialogResult.OK)
            {

            }
        }

        private void btnpx_Click(object sender, EventArgs e)
        {
            frmPhuongXa frm = new frmPhuongXa();
            if (frm.ShowDialog() == DialogResult.OK)
            {

            }
        }

        private void btnbm_Click(object sender, EventArgs e)
        {
            frmBoMon frm = new frmBoMon();
            if (frm.ShowDialog() == DialogResult.OK)
            {

            }
        }

        private void btnk_Click(object sender, EventArgs e)
        {
            frmKhoa frm = new frmKhoa();
            if (frm.ShowDialog() == DialogResult.OK)
            {

            }
        }

        private void btnl_Click(object sender, EventArgs e)
        {
            frmLop frm = new frmLop();
            if (frm.ShowDialog() == DialogResult.OK)
            {

            }
        }

        private void btnht_Click(object sender, EventArgs e)
        {
            frmHuyenThi frm = new frmHuyenThi();
            if (frm.ShowDialog() == DialogResult.OK)
            {

            }
        }

        private void btnt_Click(object sender, EventArgs e)
        {
            frmTinhThanh frm = new frmTinhThanh();
            if (frm.ShowDialog() == DialogResult.OK)
            {

            }
        }

        private void Mainfrm_Load(object sender, EventArgs e)
        {
            
        }
    }
}
