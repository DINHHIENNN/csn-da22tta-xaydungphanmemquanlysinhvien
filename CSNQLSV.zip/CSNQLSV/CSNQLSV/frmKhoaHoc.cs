﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSNQLSV
{
    public partial class frmKhoaHoc : Form
    {
        KhoaHoc kh;
        public frmKhoaHoc()
        {
            InitializeComponent();
            kh=new KhoaHoc();
        }

        private void frmKhoaHoc_Load(object sender, EventArgs e)
        {
            dgvkhoahoc.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DataTable dtkh = kh.getdsKhoaHoc();
            this.dgvkhoahoc.DataSource = dtkh;
            load(1);
            Hienthinut(2);
            btnhuykhoahoc.Enabled = false;
            this.dgvkhoahoc.Columns["MaKH"].HeaderText = "Mã Khóa Học";
            this.dgvkhoahoc.Columns["TenKH"].HeaderText = "Tên Khóa Học";
            this.dgvkhoahoc.Columns["NamHoc"].HeaderText = "Năm Học";
            dgvkhoahoc.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dgvkhoahoc.DefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Regular);
            Image timbmicon = Properties.Resources.tim;
            Image resizetimbmicon = new Bitmap(timbmicon, new Size(26, 26));
            btntim.Image = resizetimbmicon;
        }
        public void Hienthinut(int x)
        {
            if (x == 1)
            {
                this.btnxoakhoahoc.Enabled = true;
                this.btnsuakhoahoc.Enabled = true;
                this.btnthemkhoahoc.Enabled = true;
            }
            else if (x == 2)
            {
                this.btnxoakhoahoc.Enabled = false;
                this.btnsuakhoahoc.Enabled = false;
                this.btnthemkhoahoc.Enabled = false;
            }

        }
        public void load(int x)
        {
            if (x == 1)
            {
                this.txtmakhoahoc.Text = "Nhập mã khóa học";
                this.txttenkhoahoc.Text = "Nhập tên khóa học";
                this.txtnamkh.Text = "Nhập năm học khóa học";
                this.txtmakhoahoc.ForeColor = Color.Gray;
                this.txttenkhoahoc.ForeColor = Color.Gray;
                this.txtnamkh.ForeColor = Color.Gray;
                this.ActiveControl = this.txtmakhoahoc;
                this.btnhuykhoahoc.Enabled = false;
            }
            else if (x == 2)
            {

                this.txtmakhoahoc.ForeColor = Color.Black;
                this.txttenkhoahoc.ForeColor = Color.Black;
                this.txtnamkh.ForeColor = Color.Black;
                this.ActiveControl = this.txtmakhoahoc;
                this.btnhuykhoahoc.Enabled = false;
            }

        }

        private void dgvkhoahoc_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            int index = e.RowIndex;
            if (index == dgvkhoahoc.NewRowIndex || index < 0)
            {
                load(1);
                Hienthinut(2);
                MessageBox.Show("Dữ liệu rỗng!");
            }
            else
            {
                this.btnhuykhoahoc.Enabled = true;
                Hienthinut(1);
                this.txtmakhoahoc.ForeColor = Color.Black;
                this.txttenkhoahoc.ForeColor = Color.Black;             
                this.txtnamkh.ForeColor = Color.Black;
                this.txtmakhoahoc.Text = dgvkhoahoc.Rows[index].Cells[0].Value.ToString();
                this.txttenkhoahoc.Text = dgvkhoahoc.Rows[index].Cells[1].Value.ToString();
                this.txtnamkh.Text = dgvkhoahoc.Rows[index].Cells[2].Value.ToString();
            }
        }

        private void btnthemkhoahoc_Click(object sender, EventArgs e)
        {
            try
            {
                int namkh;
                if (this.txtmakhoahoc.Text == "Nhập mã khóa học" || this.txtmakhoahoc.Text=="")
                {
                    MessageBox.Show("Vui lòng nhập Mã khoá học!");
                    this.txtmakhoahoc.Focus();
                }
                else if (this.txttenkhoahoc.Text == "Nhập tên khoá học"|| this.txttenkhoahoc.Text=="")
                {
                    MessageBox.Show("Vui lòng nhập Tên khoá học!");
                    this.txttenkhoahoc.Focus();
                }
                else if (this.txtnamkh.Text == "Nhập năm học khóa học" || this.txtnamkh.Text == "")
                {
                    MessageBox.Show("Vui lòng nhập Năm học!");
                    this.txtnamkh.Focus();
                }
                else if (!int.TryParse(this.txtnamkh.Text, out namkh) || this.txtnamkh.Text.Length != 4)
                {
                    MessageBox.Show("Vui lòng nhập đúng Năm học của khóa học!");
                    this.txtnamkh.Focus();
                }
                else
                {
                    kh.Makh = this.txtmakhoahoc.Text;
                    kh.Tenkh = this.txttenkhoahoc.Text;
                    kh.Nam = namkh;
                    kh.addKhoaHoc();
                    DataTable dtkh = kh.getdsKhoaHoc();
                    dgvkhoahoc.DataSource = dtkh;
                    load(1);
                    MessageBox.Show("Dữ liệu đã được thêm thành công vào hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Khóa học có mã {this.txtmakhoahoc.Text} đã tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnxoakhoahoc_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa dữ liệu này không?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                try
                {
                    if (this.txtmakhoahoc.Text == "Nhập mã khóa học" || this.txtmakhoahoc.Text == "")
                    {
                        MessageBox.Show("Bạn chưa nhập mã khóa học. Vui lòng điền thông tin trước khi tiếp tục.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        this.txtmakhoahoc.Focus();
                        return;
                    }
                    DataTable dtkh1 = kh.getdsKhoaHoc();
                    dgvkhoahoc.DataSource = dtkh1;
                    bool kt = false;
                    foreach (DataGridViewRow row in dgvkhoahoc.Rows)
                    {
                        if (row.Cells["MaKH"].Value != null && row.Cells["MaKH"].Value.ToString().Trim() == txtmakhoahoc.Text.Trim())
                        {
                            kh.Makh = this.txtmakhoahoc.Text;
                            kh.deleteKhoaHoc();
                            DataTable dtkh = kh.getdsKhoaHoc();
                            dgvkhoahoc.DataSource = dtkh;
                            load(1);
                            this.btnhuykhoahoc.Enabled = true;
                            kt = true;
                            MessageBox.Show("Dữ liệu đã được xóa thành công khỏi hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            break;
                        }
                    }
                    if (!kt)
                    {
                        MessageBox.Show($"Khoá học có mã {this.txtmakhoahoc.Text} không tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi người dùng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi không thể xóa dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Hủy xóa dữ liệu.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnsuakhoahoc_Click(object sender, EventArgs e)
        {
            try
            {
                int namtl;
                if (this.txtmakhoahoc.Text == "Nhập mã khóa học" || this.txtmakhoahoc.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập mã khóa học. Vui lòng điền thông tin trước khi tiếp tục.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    this.txtmakhoahoc.Focus();
                    return;
                }
                DataTable dtkh1 = kh.getdsKhoaHoc();
                dgvkhoahoc.DataSource = dtkh1;
                bool kt = false;
                int dem = 0;
                foreach (DataGridViewRow row in dgvkhoahoc.Rows)
                {
                    if (row.Cells["MaKH"].Value != null && row.Cells["MaKH"].Value.ToString().Trim() == txtmakhoahoc.Text.Trim())
                    {
                        if (this.txttenkhoahoc.Text == "Nhập tên khóa học" || this.txttenkhoahoc.Text == "")
                        {
                            this.txttenkhoahoc.Text = row.Cells["TenKH"].Value.ToString();
                            this.txttenkhoahoc.ForeColor = Color.Black;
                            dem += 1;
                        }
                        if (this.txtnamkh.Text == "Nhập năm học khóa học" || this.txtnamkh.Text == "")
                        {
                            this.txtnamkh.Text = row.Cells["NamHoc"].Value.ToString();
                            this.txtnamkh.ForeColor = Color.Black;
                            dem += 1;
                        }
                        if (!int.TryParse(this.txtnamkh.Text, out namtl) || this.txtnamkh.Text.Length != 4)
                        {
                            MessageBox.Show("Vui lòng nhập đúng Năm học!");
                            this.txtnamkh.Focus();
                            dem += 1;
                        }
                        if (dem == 2 || dem == 3)
                        {
                            MessageBox.Show("Chưa thay đổi thông tin cần cập nhật.\n\nVui lòng kiểm tra và thử lại.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.txtmakhoahoc.Focus();
                            return;
                        }
                        kh.Makh = this.txtmakhoahoc.Text;
                        kh.Tenkh = this.txttenkhoahoc.Text;
                        kh.Nam = namtl;
                        kh.updateKhoaHoc();
                        DataTable dtkh = kh.getdsKhoaHoc();
                        dgvkhoahoc.DataSource = dtkh;
                        load(1);
                        kt = true;
                        MessageBox.Show("Dữ liệu đã được xóa thành công khỏi hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                    }
                }
                if (!kt)
                {
                    MessageBox.Show($"Khóa học có mã {this.txtmakhoahoc.Text} không tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi người dùng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.txtmakhoahoc.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi cập nhật dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnhuykhoahoc_Click(object sender, EventArgs e)
        {
            load(1);
            this.txttimkhoahoc.Text = "";
            Hienthinut(2);
            this.btnhuykhoahoc.Enabled = false;
        }

        private void btnthoatkhoahoc_Click(object sender, EventArgs e)
        {
            DialogResult= DialogResult.OK;
            this.Close();
        }

        private void txt_Enter(object sender, EventArgs e)
        {
            TextBox tx = (TextBox)sender;
            if (tx.Text == this.txtmakhoahoc.Text && tx.Text == "Nhập mã khóa học")
            {
                this.txtmakhoahoc.Text = "";
                this.txtmakhoahoc.ForeColor = Color.Black;
            }
            else if (tx.Text == this.txttenkhoahoc.Text && tx.Text == "Nhập tên khóa học")
            {
                this.txttenkhoahoc.Text = "";
                this.txttenkhoahoc.ForeColor = Color.Black;
            }else if (tx.Text == this.txtnamkh.Text && tx.Text=="Nhập năm học khóa học")
            {
                this.txtnamkh.Text = "";
                this.txtnamkh.ForeColor = Color.Black;
            }    
        }

        private void txt_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(this.txtmakhoahoc.Text))
            {
                this.txtmakhoahoc.Text = "Nhập mã khóa học";
                this.txtmakhoahoc.ForeColor = Color.Gray;
            }
            else if (string.IsNullOrWhiteSpace(this.txttenkhoahoc.Text))
            {
                this.txttenkhoahoc.Text = "Nhập tên khóa học";
                this.txttenkhoahoc.ForeColor = Color.Gray;
            }
            else if (string.IsNullOrWhiteSpace(this.txtnamkh.Text))
            {
                this.txtnamkh.Text = "Nhập năm học khóa học";
                this.txtnamkh.ForeColor = Color.Gray;
            }
        }

        private void btntim_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrEmpty(this.txttimkhoahoc.Text.Trim()))
            {
                MessageBox.Show("Vui lòng nhập từ khóa tìm kiếm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            DataTable dtkh = kh.getdsKhoaHoc();
            dgvkhoahoc.DataSource = dtkh;
            bool kt = false;
            foreach (DataGridViewRow row in dgvkhoahoc.Rows)
            {
                if (row.Cells["MaKH"].Value != null && row.Cells["MaKH"].Value.ToString().Trim() == txttimkhoahoc.Text.Trim())
                {
                    this.txtmakhoahoc.Text = row.Cells["MaKH"].Value.ToString();
                    this.txttenkhoahoc.Text = row.Cells["TenKH"].Value.ToString();
                    this.txtnamkh.Text = row.Cells["NamHoc"].Value.ToString();
                    load(2);
                    kt = true;
                    break;
                }
            }
            if (!kt)
            {
                MessageBox.Show("Không tìm thấy thông tin khoa", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            this.btnhuykhoahoc.Enabled = true;
        }

        private void txttimkhoahoc_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) { 
                btntim_Click(sender, e);
            }

        }

        private void Textchange(object sender, EventArgs e)
        {
            bool isMakhoahocEmpty = string.IsNullOrWhiteSpace(this.txtmakhoahoc.Text) || this.txtmakhoahoc.Text == "Nhập mã khóa học";
            bool isTenkhoahocEmpty = string.IsNullOrWhiteSpace(this.txttenkhoahoc.Text) || this.txttenkhoahoc.Text == "Nhập tên khóa học";
            bool isTimkhoahocEmpty = string.IsNullOrWhiteSpace(this.txttimkhoahoc.Text);
            bool isnamkhEmpty = string.IsNullOrWhiteSpace(this.txtnamkh.Text) || this.txtnamkh.Text == "Nhập năm học khóa học";
            if (isMakhoahocEmpty && isTenkhoahocEmpty && isnamkhEmpty)
            {
                if (isTimkhoahocEmpty)
                {
                    this.btnhuykhoahoc.Enabled = false;
                }
                else
                {
                    this.btnhuykhoahoc.Enabled = true;
                }
                Hienthinut(2);
            }
            else if (isMakhoahocEmpty || isTenkhoahocEmpty || isnamkhEmpty)
            {
                if (isTimkhoahocEmpty)
                {
                    this.btnhuykhoahoc.Enabled = true;
                }
                else
                {
                    this.btnhuykhoahoc.Enabled = true;
                }
                Hienthinut(1);
            }
            else if ((!isMakhoahocEmpty && !isTenkhoahocEmpty &&  !isnamkhEmpty))
            {

                if (isTimkhoahocEmpty)
                {
                    this.btnhuykhoahoc.Enabled = true;
                }
                else
                {
                    this.btnhuykhoahoc.Enabled = true;
                }
                Hienthinut(1);
            }
        }
        private void btn_MouseEnter(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.Text == btnthemkhoahoc.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnxoakhoahoc.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnsuakhoahoc.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnhuykhoahoc.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnthoatkhoahoc.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
        }

        private void btn_MouseLeave(object sender, EventArgs e)
        {
            
            Button btn = (Button)sender;
            if (btn.Text == btnthemkhoahoc.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black; ;
            }
            else if (btn.Text == btnxoakhoahoc.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnsuakhoahoc.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnhuykhoahoc.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnthoatkhoahoc.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
