﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSNQLSV
{
     interface itfhuyenthi
    {
        void addHuyenThi();
        DataTable getdsHuyenThi();
        void deleteHuyenThi();
        void updateHuyenThi();
    }
    public abstract class AbstractHuyenThi
    {
       
        public abstract void addHuyenThi();
        public abstract DataTable getdsHuyenThi();
        public abstract void deleteHuyenThi();
        public abstract void updateHuyenThi();
    }

    public class HuyenThi : AbstractHuyenThi, itfhuyenthi
    {
        private string maht;
        private string matinh;
        private string tenht;
        ThaotacCSDL db;

        public string Maht { get => maht; set => maht = value; }
        public string Matinh { get => matinh; set => matinh = value; }
        public string Tenht { get => tenht; set => tenht = value; }

        public HuyenThi() : base() {
            db = new ThaotacCSDL();
        }
        public override void addHuyenThi()
        {
            string sql = string.Format("insert into  HuyenThi values('{0}','{1}',N'{2}' )", Maht, Matinh, Tenht);
            Console.WriteLine(sql);
            db.ExecuteNonQuery(sql);
        }

        public override DataTable getdsHuyenThi()
        {
            string sql = "select * from HuyenThi";
            DataTable dt = db.Execute(sql);
            return dt;
        }

        public override void deleteHuyenThi()
        {
            string sql = String.Format("Delete from HuyenThi where MaHT='{0}'", Maht);
            Console.WriteLine(sql);
            db.ExecuteNonQuery(sql);
        }

        public override void updateHuyenThi()
        {
            string sql = String.Format("Update HuyenThi set MaHT='{0}', MaTT = '{1}', TenHT = N'{2}' Where MaHT='{3}'", Maht, Matinh, Tenht, Maht);
            Console.WriteLine(sql);
            db.ExecuteNonQuery(sql);
        }
    }
}
