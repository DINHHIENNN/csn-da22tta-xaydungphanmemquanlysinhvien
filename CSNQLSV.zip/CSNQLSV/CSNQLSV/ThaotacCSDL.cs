﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSNQLSV
{
    
    class ThaotacCSDL
    {
        private SqlConnection sqlConn;
        private SqlDataAdapter da;
        private DataSet ds;
        public string strCnn = @"Data Source = DELL\MAY2; Initial Catalog = QLSV_01;Integrated Security= True;";
        public ThaotacCSDL()
        {
        }
        public DataTable Execute(string sqlStr)
        {
            using (SqlConnection sqlConn = new SqlConnection(strCnn))
            {
                SqlDataAdapter da = new SqlDataAdapter(sqlStr, sqlConn);
                DataSet ds = new DataSet();
                da.Fill(ds);
                return ds.Tables[0];
            }
        }
        public void ExecuteNonQuery(string strSQL)
        {
            using (SqlConnection sqlConn = new SqlConnection(strCnn))  
            {
                SqlCommand sqlcmd = new SqlCommand(strSQL, sqlConn);
                sqlConn.Open(); 
                sqlcmd.ExecuteNonQuery(); 
            }
        }
    }
}
