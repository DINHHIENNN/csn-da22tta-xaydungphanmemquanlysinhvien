﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSNQLSV
{
    interface itfTinhThanh
    {
        void addTinhThanh();
        DataTable getdsTinhThanh();
        void deleteTinhThanh();
        void updateTinhThanh();
    }
    public abstract class AbstracTinhThanh
    {
       
        public abstract void addTinhThanh();
        public abstract DataTable getdsTinhThanh();
        public abstract void deleteTinhThanh();
        public abstract void updateTinhThanh();
    }
    public class TinhThanh:AbstracTinhThanh,itfTinhThanh
    {
        private string matt;
        private string tentt;
        ThaotacCSDL db;

        public string Matt { get => matt; set => matt = value; }
        public string Tentt { get => tentt; set => tentt = value; }

        public TinhThanh():base()
        {
            db = new ThaotacCSDL();
        }
        public override void addTinhThanh()
        {
            string sql = string.Format("insert into  TinhThanh values('{0}',N'{1}')", Matt, Tentt);
            db.ExecuteNonQuery(sql);
        }
        public override DataTable getdsTinhThanh()
        {
            string sql = "select * from TinhThanh";
            DataTable dt = db.Execute(sql);
            return dt;
        }
        public override void deleteTinhThanh()
        {
            string sql = String.Format("Delete from TinhThanh where MaTT='{0}'", Matt);
            Console.WriteLine(sql);
            db.ExecuteNonQuery(sql);
        }
        public override void updateTinhThanh()
        {
            string sql = String.Format("Update TinhThanh set MaTT='{0}',TenTT = N'{1}' Where MaTT='{2}'", Matt, Tentt,Matt);
            Console.WriteLine(sql);
            db.ExecuteNonQuery(sql);
        }
    }
}
