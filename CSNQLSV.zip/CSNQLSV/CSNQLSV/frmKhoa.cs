﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace CSNQLSV
{
    public partial class frmKhoa : Form
    {
        Khoa k;
        public frmKhoa()
        {
            InitializeComponent();
            k = new Khoa();
        }

        private void frmKhoa_Load(object sender, EventArgs e)
        {
            dgvkhoa.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DataTable dtk = k.getdsKhoa();
            this.dgvkhoa.DataSource = dtk;
            this.dgvkhoa.Columns["MaKhoa"].HeaderText = "Mã Khoa";
            this.dgvkhoa.Columns["TenKhoa"].HeaderText = "Tên Khoa";
            this.dgvkhoa.Columns["MoTa"].HeaderText = "Mô Tả";
            this.dgvkhoa.Columns["NamThanhLap"].HeaderText = "Năm Thành Lập";
            load(1);
            Hienthinut(2);
            btnhuykhoa.Enabled = false;
            dgvkhoa.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dgvkhoa.DefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Regular);
            Image timbmicon = Properties.Resources.tim;
            Image resizetimbmicon = new Bitmap(timbmicon, new Size(26, 26));
            btntim.Image = resizetimbmicon;
        }
        public void Hienthinut(int x)
        {
            if (x == 1)
            {
                this.btnxoakhoa.Enabled = true;
                this.btnsuakhoa.Enabled = true;
                this.btnthemkhoa.Enabled = true;
            }
            else if (x == 2)
            {
                this.btnxoakhoa.Enabled = false;
                this.btnsuakhoa.Enabled = false;
                this.btnthemkhoa.Enabled = false;
            }

        }
        public void load(int x)
        {
            if (x == 1)
            {
                this.txtmakhoa.Text = "Nhập mã khoa";
                this.txttenkhoa.Text = "Nhập tên khoa";
                this.rtxtmotakhoa.Text = "Nhập mô tả khoa";
                this.txtnamtlkhoa.Text = "Nhập năm thành lập khoa";
                this.txtmakhoa.ForeColor = Color.Gray;
                this.txttenkhoa.ForeColor = Color.Gray;
                this.rtxtmotakhoa.ForeColor = Color.Gray;
                this.txtnamtlkhoa.ForeColor = Color.Gray;
                this.ActiveControl = this.txtmakhoa;
                this.btnhuykhoa.Enabled = false;
            }
            else if (x == 2)
            {
                
                this.txtmakhoa.ForeColor = Color.Black;
                this.txttenkhoa.ForeColor = Color.Black;
                this.rtxtmotakhoa.ForeColor = Color.Black;
                this.txtnamtlkhoa.ForeColor = Color.Black;
                this.ActiveControl = this.txtmakhoa;
                this.btnhuykhoa.Enabled = false;
            }
            
        }
        private void Load_khi_Click(object sender, DataGridViewCellEventArgs e)
        {
            int index=e.RowIndex;
            if (index == dgvkhoa.NewRowIndex || index < 0)
            {
                load(1);
                Hienthinut(2);
                MessageBox.Show("Dữ liệu rỗng!");
            }
            else
            {
                this.btnhuykhoa.Enabled = true;
                Hienthinut(1);
                this.txtmakhoa.ForeColor = Color.Black;
                this.txttenkhoa.ForeColor = Color.Black;
                this.rtxtmotakhoa.ForeColor = Color.Black;
                this.txtnamtlkhoa.ForeColor = Color.Black;
                this.txtmakhoa.Text = dgvkhoa.Rows[index].Cells[0].Value.ToString();
                this.txttenkhoa.Text = dgvkhoa.Rows[index].Cells[1].Value.ToString();
                this.rtxtmotakhoa.Text = dgvkhoa.Rows[index].Cells[2].Value.ToString();
                this.txtnamtlkhoa.Text = dgvkhoa.Rows[index].Cells[3].Value.ToString();

            }
        }

        private void btnthem_Click(object sender, EventArgs e)
        {
            try
            {
                int namtl;
                if (this.txtmakhoa.Text == "Nhập mã khoa" || this.txtmakhoa.Text=="")
                {
                    MessageBox.Show("Vui lòng nhập Mã khoa!");
                    this.txtmakhoa.Focus();
                }
                else if (this.txttenkhoa.Text == "Nhập tên khoa" || this.txttenkhoa.Text=="")
                {
                    MessageBox.Show("Vui lòng nhập Tên khoa!");
                    this.txttenkhoa.Focus();
                }
                else if (this.rtxtmotakhoa.Text == "Nhập mô tả khoa" || this.rtxtmotakhoa.Text=="")
                {
                    MessageBox.Show("Vui lòng nhập Mô tả khoa!");
                    this.rtxtmotakhoa.Focus();
                }
                else if (this.txtnamtlkhoa.Text == "Nhập năm thành lập khoa" || this.txtnamtlkhoa.Text == "")
                {
                    MessageBox.Show("Vui lòng nhập Năm thành lập khoa!");
                    this.txtnamtlkhoa.Focus();
                }
                else if (!int.TryParse(this.txtnamtlkhoa.Text, out namtl) || this.txtnamtlkhoa.Text.Length != 4 )
                {
                    MessageBox.Show("Vui lòng nhập đúng Năm thành lập khoa!");
                    this.txtnamtlkhoa.Focus();
                }
                else
                {
                    k.Makhoa = this.txtmakhoa.Text;
                    k.Tenkhoa = this.txttenkhoa.Text;
                    k.Mota = this.rtxtmotakhoa.Text;
                    k.Namthanhlap = namtl;
                    k.addKhoa();
                    DataTable dtk = k.getdsKhoa();
                    dgvkhoa.DataSource = dtk;
                    load(1);
                    MessageBox.Show("Dữ liệu đã được thêm thành công vào hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Khoa có mã {this.txtmakhoa.Text} đã tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnthoat_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            this.Close();
            
        }
        private void btnxoakhoa_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa dữ liệu này không?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                try
                {
                    if (this.txtmakhoa.Text == "Nhập mã khoa" || this.txtmakhoa.Text == "")
                    {
                        MessageBox.Show("Bạn chưa nhập mã khoa. Vui lòng điền thông tin trước khi tiếp tục.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        this.txtmakhoa.Focus();
                        return;
                    }
                    DataTable dtk1 = k.getdsKhoa();
                    dgvkhoa.DataSource = dtk1;
                    bool kt = false;
                    foreach (DataGridViewRow row in dgvkhoa.Rows)
                    {
                        if (row.Cells["MaKhoa"].Value != null && row.Cells["MaKhoa"].Value.ToString().Trim() == txtmakhoa.Text.Trim())
                        {
                            k.Makhoa = this.txtmakhoa.Text;
                            k.deleteKhoa();
                            DataTable dtk = k.getdsKhoa();
                            dgvkhoa.DataSource = dtk;
                            load(1);
                            this.btnhuykhoa.Enabled = true;
                            kt = true;
                            MessageBox.Show("Dữ liệu đã được xóa thành công khỏi hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            break;
                        }
                    }
                    if (!kt)
                    {
                        MessageBox.Show($"Khoa có mã {this.txtmakhoa.Text} không tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi người dùng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi không thể xóa dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Hủy xóa dữ liệu.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnsuakhoa_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.txtmakhoa.Text == "Nhập mã khoa" || this.txtmakhoa.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập mã khoa. Vui lòng điền thông tin trước khi tiếp tục.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    this.txtmakhoa.Focus();
                    return;
                }
                DataTable dtk1 = k.getdsKhoa();
                dgvkhoa.DataSource = dtk1;
                bool kt = false;
                int dem = 0;
                foreach (DataGridViewRow row in dgvkhoa.Rows)
                {
                    if (row.Cells["MaKhoa"].Value != null && row.Cells["MaKhoa"].Value.ToString().Trim() == txtmakhoa.Text.Trim())
                    {
                        if (this.txttenkhoa.Text == "Nhập tên khoa" || this.txttenkhoa.Text == "")
                        {
                            this.txttenkhoa.Text = row.Cells["TenKhoa"].Value.ToString();
                            this.txttenkhoa.ForeColor = Color.Black;
                            dem += 1;
                        }
                        if (this.rtxtmotakhoa.Text == "Nhập mô tả khoa" || this.rtxtmotakhoa.Text == "")
                        {
                            this.rtxtmotakhoa.Text = row.Cells["MoTa"].Value.ToString();
                            this.rtxtmotakhoa.ForeColor = Color.Black;
                            dem += 1;
                        }
                        if (this.txtnamtlkhoa.Text == "Nhập năm thành lập khoa" || this.txtnamtlkhoa.Text == "")
                        {
                            this.txtnamtlkhoa.Text = row.Cells["NamThanhLap"].Value.ToString();
                            this.txtnamtlkhoa.ForeColor = Color.Black;
                            dem += 1;
                        }
                        if (dem == 3)
                        {
                            MessageBox.Show("Chưa thay đổi thông tin cần cập nhật.\n\nVui lòng kiểm tra và thử lại.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.txtmakhoa.Focus();
                            return;
                        }
                        k.Makhoa = this.txtmakhoa.Text;
                        k.Tenkhoa = this.txttenkhoa.Text;
                        k.Mota = this.rtxtmotakhoa.Text;
                        k.Namthanhlap = Int32.Parse(this.txtnamtlkhoa.Text);
                        k.updateKhoa();
                        DataTable dtk = k.getdsKhoa();
                        dgvkhoa.DataSource = dtk;
                        load(1);
                        MessageBox.Show("Dữ liệu đã được cập nhật thành công vào hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        kt = true;
                        break;
                    }
                }
                if (!kt)
                {
                    MessageBox.Show($"Khoa có mã {this.txtmakhoa.Text} không tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi người dùng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.txtmakhoa.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi cập nhật dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnhuykhoa_Click(object sender, EventArgs e)
        {
            load(1);
            this.txttim.Text = "";
            Hienthinut(2);
            this.btnhuykhoa.Enabled = false;
        }
        
        private void Enter_click(object sender, EventArgs e)
        {
            TextBox tx= (TextBox)sender;
            if(tx.Text == this.txtmakhoa.Text && tx.Text== "Nhập mã khoa")
            {
                this.txtmakhoa.Text = "";
                this.txtmakhoa.ForeColor=Color.Black;
            } 
            else if (tx.Text == this.txttenkhoa.Text && tx.Text == "Nhập tên khoa")
            {
                this.txttenkhoa.Text = "";
                this.txttenkhoa.ForeColor = Color.Black;
            }
            else if (tx.Text == this.txtnamtlkhoa.Text && tx.Text == "Nhập năm thành lập khoa")
            {
                this.txtnamtlkhoa.Text = "";
                this.txtnamtlkhoa.ForeColor = Color.Black;
            }
        }

        private void txt_leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(this.txtmakhoa.Text))
            {
                this.txtmakhoa.Text = "Nhập mã khoa";
                this.txtmakhoa.ForeColor = Color.Gray;
            }
            else if (string.IsNullOrWhiteSpace(this.txttenkhoa.Text))
            {
                this.txttenkhoa.Text = "Nhập tên khoa";
                this.txttenkhoa.ForeColor = Color.Gray;
            }
            else if (string.IsNullOrWhiteSpace(this.txtnamtlkhoa.Text))
            {
                this.txtnamtlkhoa.Text = "Nhập năm thành lập khoa";
                this.txtnamtlkhoa.ForeColor = Color.Gray;
            }
        }

        private void rtxt_Enter(object sender, EventArgs e)
        {
            RichTextBox tx = (RichTextBox)sender;
            if (tx.Text == this.rtxtmotakhoa.Text && tx.Text == "Nhập mô tả khoa")
            {
                this.rtxtmotakhoa.Text = "";
                this.rtxtmotakhoa.ForeColor = Color.Black;
            }
        }

        private void rtxt_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(this.rtxtmotakhoa.Text))
            {
                this.rtxtmotakhoa.Text = "Nhập mô tả khoa";
                this.rtxtmotakhoa.ForeColor = Color.Gray;
            }
        }

        private void txttim_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btntim_Click(sender, e);
            }
        }

        private void btntim_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(this.txttim.Text.Trim()))
            {
                MessageBox.Show("Vui lòng nhập từ khóa tìm kiếm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            DataTable dtk = k.getdsKhoa();
            dgvkhoa.DataSource = dtk;
            bool kt = false;
            foreach (DataGridViewRow row in dgvkhoa.Rows)
            {
                if (row.Cells["MaKhoa"].Value != null && row.Cells["MaKhoa"].Value.ToString().Trim() == txttim.Text.Trim())
                {
                    this.txtmakhoa.Text = row.Cells["MaKhoa"].Value.ToString();
                    this.txttenkhoa.Text = row.Cells["TenKhoa"].Value.ToString();
                    this.rtxtmotakhoa.Text = row.Cells["MoTa"].Value.ToString();
                    this.txtnamtlkhoa.Text = row.Cells["NamThanhLap"].Value.ToString();
                    load(2);
                    kt = true;
                    break;
                }
            }
            if (!kt)
            {
                MessageBox.Show("Không tìm thấy thông tin khoa", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            this.btnhuykhoa.Enabled = true;
        }
        private void Textchange(object sender, EventArgs e)
        {
            bool isMakhoaEmpty = string.IsNullOrWhiteSpace(this.txtmakhoa.Text) || this.txtmakhoa.Text == "Nhập mã khoa";
            bool isTenkhoaEmpty = string.IsNullOrWhiteSpace(this.txttenkhoa.Text) || this.txttenkhoa.Text == "Nhập tên khoa";
            bool isMotaEmpty = string.IsNullOrWhiteSpace(this.rtxtmotakhoa.Text) || this.rtxtmotakhoa.Text == "Nhập mô tả khoa";
            bool isTimkhoaEmpty = string.IsNullOrWhiteSpace(this.txttim.Text);
            bool isnamtlEmpty = string.IsNullOrWhiteSpace(this.txtnamtlkhoa.Text) || this.txtnamtlkhoa.Text == "Nhập năm thành lập khoa";
            if (isMakhoaEmpty && isTenkhoaEmpty && isMotaEmpty && isnamtlEmpty)
            {
                if (isTimkhoaEmpty)
                {
                    this.btnhuykhoa.Enabled = false;
                }
                else
                {
                    this.btnhuykhoa.Enabled = true;
                }
                Hienthinut(2);
            }else if(isMakhoaEmpty || isTenkhoaEmpty || isMotaEmpty || isnamtlEmpty)
            {
                if (isTimkhoaEmpty)
                {
                    this.btnhuykhoa.Enabled = true;
                }
                else
                {
                    this.btnhuykhoa.Enabled = true;
                }
                Hienthinut(1);
            }
            else if ((!isMakhoaEmpty && !isTenkhoaEmpty && !isMotaEmpty && !isnamtlEmpty))
            {
                
                if (isTimkhoaEmpty)
                {
                    this.btnhuykhoa.Enabled = true;
                }
                else
                {
                    this.btnhuykhoa.Enabled = true;
                }
                Hienthinut(1);
            }
        }

        private void btn_MouseEnter(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.Text == btnthemkhoa.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnxoakhoa.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnsuakhoa.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnhuykhoa.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnthoatkhoa.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
        }

        private void btn_MouseLeave(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.Text == btnthemkhoa.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnxoakhoa.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnsuakhoa.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnhuykhoa.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnthoatkhoa.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
        }
    }
}
