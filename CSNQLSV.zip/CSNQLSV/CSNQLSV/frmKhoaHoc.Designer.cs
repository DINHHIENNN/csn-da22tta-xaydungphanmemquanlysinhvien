﻿namespace CSNQLSV
{
    partial class frmKhoaHoc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btntim = new System.Windows.Forms.Button();
            this.txttimkhoahoc = new System.Windows.Forms.TextBox();
            this.dgvkhoahoc = new System.Windows.Forms.DataGridView();
            this.btnxoakhoahoc = new System.Windows.Forms.Button();
            this.btnhuykhoahoc = new System.Windows.Forms.Button();
            this.btnthoatkhoahoc = new System.Windows.Forms.Button();
            this.btnsuakhoahoc = new System.Windows.Forms.Button();
            this.btnthemkhoahoc = new System.Windows.Forms.Button();
            this.txtnamkh = new System.Windows.Forms.TextBox();
            this.txttenkhoahoc = new System.Windows.Forms.TextBox();
            this.txtmakhoahoc = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvkhoahoc)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btntim
            // 
            this.btntim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntim.Location = new System.Drawing.Point(700, 73);
            this.btntim.Name = "btntim";
            this.btntim.Size = new System.Drawing.Size(41, 37);
            this.btntim.TabIndex = 42;
            this.btntim.UseVisualStyleBackColor = true;
            this.btntim.Click += new System.EventHandler(this.btntim_Click);
            // 
            // txttimkhoahoc
            // 
            this.txttimkhoahoc.Font = new System.Drawing.Font("Arial", 10F);
            this.txttimkhoahoc.Location = new System.Drawing.Point(517, 79);
            this.txttimkhoahoc.Name = "txttimkhoahoc";
            this.txttimkhoahoc.Size = new System.Drawing.Size(177, 27);
            this.txttimkhoahoc.TabIndex = 41;
            this.txttimkhoahoc.TextChanged += new System.EventHandler(this.Textchange);
            this.txttimkhoahoc.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txttimkhoahoc_KeyDown);
            // 
            // dgvkhoahoc
            // 
            this.dgvkhoahoc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvkhoahoc.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvkhoahoc.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvkhoahoc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvkhoahoc.Location = new System.Drawing.Point(22, 37);
            this.dgvkhoahoc.Name = "dgvkhoahoc";
            this.dgvkhoahoc.RowHeadersWidth = 51;
            this.dgvkhoahoc.RowTemplate.Height = 24;
            this.dgvkhoahoc.Size = new System.Drawing.Size(733, 187);
            this.dgvkhoahoc.TabIndex = 39;
            this.dgvkhoahoc.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvkhoahoc_CellClick);
            // 
            // btnxoakhoahoc
            // 
            this.btnxoakhoahoc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnxoakhoahoc.Font = new System.Drawing.Font("Arial", 10F);
            this.btnxoakhoahoc.ForeColor = System.Drawing.Color.Black;
            this.btnxoakhoahoc.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnxoakhoahoc.Location = new System.Drawing.Point(213, 320);
            this.btnxoakhoahoc.Name = "btnxoakhoahoc";
            this.btnxoakhoahoc.Size = new System.Drawing.Size(92, 38);
            this.btnxoakhoahoc.TabIndex = 37;
            this.btnxoakhoahoc.Text = "Xóa";
            this.btnxoakhoahoc.UseVisualStyleBackColor = false;
            this.btnxoakhoahoc.Click += new System.EventHandler(this.btnxoakhoahoc_Click);
            this.btnxoakhoahoc.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnxoakhoahoc.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // btnhuykhoahoc
            // 
            this.btnhuykhoahoc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnhuykhoahoc.Font = new System.Drawing.Font("Arial", 10F);
            this.btnhuykhoahoc.ForeColor = System.Drawing.Color.Black;
            this.btnhuykhoahoc.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnhuykhoahoc.Location = new System.Drawing.Point(460, 320);
            this.btnhuykhoahoc.Name = "btnhuykhoahoc";
            this.btnhuykhoahoc.Size = new System.Drawing.Size(92, 38);
            this.btnhuykhoahoc.TabIndex = 36;
            this.btnhuykhoahoc.Text = "Hủy";
            this.btnhuykhoahoc.UseVisualStyleBackColor = false;
            this.btnhuykhoahoc.Click += new System.EventHandler(this.btnhuykhoahoc_Click);
            this.btnhuykhoahoc.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnhuykhoahoc.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // btnthoatkhoahoc
            // 
            this.btnthoatkhoahoc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnthoatkhoahoc.Font = new System.Drawing.Font("Arial", 10F);
            this.btnthoatkhoahoc.ForeColor = System.Drawing.Color.Black;
            this.btnthoatkhoahoc.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnthoatkhoahoc.Location = new System.Drawing.Point(623, 320);
            this.btnthoatkhoahoc.Name = "btnthoatkhoahoc";
            this.btnthoatkhoahoc.Size = new System.Drawing.Size(93, 38);
            this.btnthoatkhoahoc.TabIndex = 35;
            this.btnthoatkhoahoc.Text = "Thoát";
            this.btnthoatkhoahoc.UseVisualStyleBackColor = false;
            this.btnthoatkhoahoc.Click += new System.EventHandler(this.btnthoatkhoahoc_Click);
            this.btnthoatkhoahoc.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnthoatkhoahoc.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // btnsuakhoahoc
            // 
            this.btnsuakhoahoc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnsuakhoahoc.Font = new System.Drawing.Font("Arial", 10F);
            this.btnsuakhoahoc.ForeColor = System.Drawing.Color.Black;
            this.btnsuakhoahoc.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnsuakhoahoc.Location = new System.Drawing.Point(329, 320);
            this.btnsuakhoahoc.Name = "btnsuakhoahoc";
            this.btnsuakhoahoc.Size = new System.Drawing.Size(107, 38);
            this.btnsuakhoahoc.TabIndex = 38;
            this.btnsuakhoahoc.Text = "Cập nhật";
            this.btnsuakhoahoc.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnsuakhoahoc.UseVisualStyleBackColor = false;
            this.btnsuakhoahoc.Click += new System.EventHandler(this.btnsuakhoahoc_Click);
            this.btnsuakhoahoc.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnsuakhoahoc.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // btnthemkhoahoc
            // 
            this.btnthemkhoahoc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.btnthemkhoahoc.Font = new System.Drawing.Font("Arial", 10F);
            this.btnthemkhoahoc.ForeColor = System.Drawing.Color.Black;
            this.btnthemkhoahoc.Location = new System.Drawing.Point(98, 320);
            this.btnthemkhoahoc.Name = "btnthemkhoahoc";
            this.btnthemkhoahoc.Size = new System.Drawing.Size(92, 38);
            this.btnthemkhoahoc.TabIndex = 34;
            this.btnthemkhoahoc.Text = "Thêm";
            this.btnthemkhoahoc.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnthemkhoahoc.UseVisualStyleBackColor = false;
            this.btnthemkhoahoc.Click += new System.EventHandler(this.btnthemkhoahoc_Click);
            this.btnthemkhoahoc.MouseEnter += new System.EventHandler(this.btn_MouseEnter);
            this.btnthemkhoahoc.MouseLeave += new System.EventHandler(this.btn_MouseLeave);
            // 
            // txtnamkh
            // 
            this.txtnamkh.Font = new System.Drawing.Font("Arial", 10F);
            this.txtnamkh.Location = new System.Drawing.Point(178, 118);
            this.txtnamkh.Name = "txtnamkh";
            this.txtnamkh.Size = new System.Drawing.Size(255, 27);
            this.txtnamkh.TabIndex = 33;
            this.txtnamkh.TextChanged += new System.EventHandler(this.Textchange);
            this.txtnamkh.Enter += new System.EventHandler(this.txt_Enter);
            this.txtnamkh.Leave += new System.EventHandler(this.txt_Leave);
            // 
            // txttenkhoahoc
            // 
            this.txttenkhoahoc.Font = new System.Drawing.Font("Arial", 10F);
            this.txttenkhoahoc.Location = new System.Drawing.Point(178, 76);
            this.txttenkhoahoc.Name = "txttenkhoahoc";
            this.txttenkhoahoc.Size = new System.Drawing.Size(405, 27);
            this.txttenkhoahoc.TabIndex = 32;
            this.txttenkhoahoc.TextChanged += new System.EventHandler(this.Textchange);
            this.txttenkhoahoc.Enter += new System.EventHandler(this.txt_Enter);
            this.txttenkhoahoc.Leave += new System.EventHandler(this.txt_Leave);
            // 
            // txtmakhoahoc
            // 
            this.txtmakhoahoc.Font = new System.Drawing.Font("Arial", 10F);
            this.txtmakhoahoc.Location = new System.Drawing.Point(178, 38);
            this.txtmakhoahoc.Name = "txtmakhoahoc";
            this.txtmakhoahoc.Size = new System.Drawing.Size(405, 27);
            this.txtmakhoahoc.TabIndex = 31;
            this.txtmakhoahoc.TextChanged += new System.EventHandler(this.Textchange);
            this.txtmakhoahoc.Enter += new System.EventHandler(this.txt_Enter);
            this.txtmakhoahoc.Leave += new System.EventHandler(this.txt_Leave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 10F);
            this.label5.Location = new System.Drawing.Point(36, 121);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 19);
            this.label5.TabIndex = 29;
            this.label5.Text = "Năm học";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 10F);
            this.label4.Location = new System.Drawing.Point(36, 79);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 19);
            this.label4.TabIndex = 28;
            this.label4.Text = "Tên Khóa học";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 10F);
            this.label2.Location = new System.Drawing.Point(36, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 19);
            this.label2.TabIndex = 30;
            this.label2.Text = "Mã Khóa học";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(253, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(321, 35);
            this.label1.TabIndex = 26;
            this.label1.Text = "QUẢN LÝ KHOÁ HỌC";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.txttenkhoahoc);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtmakhoahoc);
            this.groupBox1.Controls.Add(this.txtnamkh);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(101, 112);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(615, 187);
            this.groupBox1.TabIndex = 43;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "THÔNG TIN";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.dgvkhoahoc);
            this.groupBox2.Font = new System.Drawing.Font("Arial", 10F);
            this.groupBox2.Location = new System.Drawing.Point(12, 387);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(776, 245);
            this.groupBox2.TabIndex = 44;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "DANH SÁCH KHÓA HỌC";
            // 
            // frmKhoaHoc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(244)))), ((int)(((byte)(251)))));
            this.ClientSize = new System.Drawing.Size(815, 644);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btntim);
            this.Controls.Add(this.txttimkhoahoc);
            this.Controls.Add(this.btnxoakhoahoc);
            this.Controls.Add(this.btnhuykhoahoc);
            this.Controls.Add(this.btnthoatkhoahoc);
            this.Controls.Add(this.btnsuakhoahoc);
            this.Controls.Add(this.btnthemkhoahoc);
            this.Controls.Add(this.label1);
            this.Name = "frmKhoaHoc";
            this.Text = "frmKhoaHoc";
            this.Load += new System.EventHandler(this.frmKhoaHoc_Load);
            this.Enter += new System.EventHandler(this.txt_Enter);
            this.Leave += new System.EventHandler(this.txt_Leave);
            ((System.ComponentModel.ISupportInitialize)(this.dgvkhoahoc)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btntim;
        private System.Windows.Forms.TextBox txttimkhoahoc;
        private System.Windows.Forms.DataGridView dgvkhoahoc;
        private System.Windows.Forms.Button btnxoakhoahoc;
        private System.Windows.Forms.Button btnhuykhoahoc;
        private System.Windows.Forms.Button btnthoatkhoahoc;
        private System.Windows.Forms.Button btnsuakhoahoc;
        private System.Windows.Forms.Button btnthemkhoahoc;
        private System.Windows.Forms.TextBox txtnamkh;
        private System.Windows.Forms.TextBox txttenkhoahoc;
        private System.Windows.Forms.TextBox txtmakhoahoc;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}