﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSNQLSV
{
    interface itfKhoaHoc
    {
        void addKhoaHoc();
        DataTable getdsKhoaHoc();
        void deleteKhoaHoc();
        void updateKhoaHoc();
    }
    public abstract class AbstracKhoaHoc
    {
       
        public abstract void addKhoaHoc();
        public abstract DataTable getdsKhoaHoc();
        public abstract void deleteKhoaHoc();
        public abstract void updateKhoaHoc();
    }
    public class KhoaHoc:AbstracKhoaHoc,itfKhoaHoc
    {
        private string makh;
        private string tenkh;
        private int nam;
        ThaotacCSDL db;

        public string Makh { get => makh; set => makh = value; }
        public string Tenkh { get => tenkh; set => tenkh = value; }
        public int Nam { get => nam; set => nam = value; }

        public KhoaHoc():base()
        {
            db = new ThaotacCSDL();
        }
        public override void addKhoaHoc()
        {
            string sql = string.Format("insert into  KhoaHoc values('{0}',N'{1}',{2})", Makh, Tenkh, Nam);
            Console.WriteLine(sql);
            db.ExecuteNonQuery(sql);
        }
        public override DataTable getdsKhoaHoc()
        {
            string sql = "select * from KhoaHoc";
            DataTable dt = db.Execute(sql);
            return dt;
        }
        public override void deleteKhoaHoc()
        {
            string sql = String.Format("Delete from KhoaHoc where MaKH='{0}'", Makh);
            Console.WriteLine(sql);
            db.ExecuteNonQuery(sql);
        }
        public override void updateKhoaHoc()
        {
            string sql = String.Format("Update KhoaHoc set MaKH='{0}',TenKH = N'{1}',NamHoc ={2} Where MaKH='{3}'", Makh, Tenkh, Nam,Makh);
            Console.WriteLine(sql);
            db.ExecuteNonQuery(sql);
        }
    }
}
