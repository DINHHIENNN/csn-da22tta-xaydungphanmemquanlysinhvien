﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSNQLSV
{
    public partial class frmBoMon : Form
    {
        Khoa k;
        BoMon bm;
        public frmBoMon()
        {
            InitializeComponent();
            k = new Khoa();
            bm = new BoMon();
        }
        private void frmBoMon_Load(object sender, EventArgs e)
        {
            dgvbm.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DataTable dtbm = bm.getdsBoMon();
            this.dgvbm.DataSource = dtbm;
            load_cb();
            load(1);
            Hienthinut(2);
            dgvbm.Columns["MaBM"].HeaderText = "Mã Bộ Môn";
            dgvbm.Columns["TenBoMon"].HeaderText = "Tên Bộ Môn";
            dgvbm.Columns["MoTaBM"].HeaderText = "Mô Tả";
            dgvbm.Columns["MaKhoa"].HeaderText = "Mã Khoa";
            dgvbm.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Bold);
            dgvbm.DefaultCellStyle.Font = new Font("Arial", 10, FontStyle.Regular);
            Image timbmicon = Properties.Resources.tim;
            Image resizetimbmicon = new Bitmap(timbmicon, new Size(26, 26));
            btntimbm.Image = resizetimbmicon;
        }
        public void Hienthinut(int x)
        {
            if (x == 1)
            {
                this.btnxoabm.Enabled = true;
                this.btnsuabm.Enabled = true;
                this.btnthembm.Enabled = true;
            }
            else if (x == 2)
            {
                this.btnxoabm.Enabled = false;
                this.btnsuabm.Enabled = false;
                this.btnthembm.Enabled = false;
            }

        }
        public void load_cb()
        {
            DataTable dtk = k.getdsKhoa();
            DataRow dr = dtk.NewRow();
            dr[dtk.Columns[0].ColumnName] = DBNull.Value;
            dr[dtk.Columns[1].ColumnName] = "Chọn khoa";
            dtk.Rows.InsertAt(dr, 0);

            this.cbmakhoabm.DataSource = dtk;
            this.cbmakhoabm.ValueMember = dtk.Columns[0].ColumnName.ToString().Trim();
            this.cbmakhoabm.DisplayMember = dtk.Columns[1].ColumnName.ToString();
            cbmakhoabm.DrawMode = DrawMode.OwnerDrawFixed;
            cbmakhoabm.DrawItem += cbmakhoabm_DrawItem;
        }
        public void load(int x)
        {
            if (x == 1)
            {
                this.txtmabm.Text = "Nhập mã bộ môn";
                this.txttenbm.Text = "Nhập tên bộ môn";
                this.rtxtmotabm.Text = "Nhập mô tả";
                this.txtmabm.ForeColor = Color.Gray;
                this.txttenbm.ForeColor = Color.Gray;
                this.rtxtmotabm.ForeColor = Color.Gray;
                this.ActiveControl = this.txtmabm;
                this.btnhuybm.Enabled = false;
            }
            else if (x == 2)
            {
                this.txtmabm.ForeColor = Color.Black;
                this.txttenbm.ForeColor = Color.Black;
                this.rtxtmotabm.ForeColor = Color.Black;
                this.ActiveControl = this.txtmabm;
                this.btnhuybm.Enabled = false;

            }

        }
        private void Load_khi_Click(object sender, DataGridViewCellEventArgs e)
        {
            int id = e.RowIndex;
            if (id == dgvbm.NewRowIndex || id < 0)
            {
                load(1);
                Hienthinut(2);
                cbmakhoabm.SelectedIndex = 0;
                MessageBox.Show("Dữ liệu rỗng!");
                return;
            }
            else
            {
                this.btnhuybm.Enabled = true;
                Hienthinut(1);
                this.txtmabm.ForeColor = Color.Black;
                this.txttenbm.ForeColor = Color.Black;
                this.rtxtmotabm.ForeColor = Color.Black;
                this.cbmakhoabm.ForeColor = Color.Black;

                this.txtmabm.Text = dgvbm.Rows[id].Cells[0].Value.ToString().Trim();
                this.txttenbm.Text = dgvbm.Rows[id].Cells[1].Value.ToString();
                this.rtxtmotabm.Text = dgvbm.Rows[id].Cells[3].Value.ToString();
                this.cbmakhoabm.SelectedValue = dgvbm.Rows[id].Cells[2].Value.ToString().Trim();
                this.cbmakhoabm.Text = this.cbmakhoabm.GetItemText(this.cbmakhoabm.SelectedItem);  
            }
        }
        private void btnthembm_Click(object sender, EventArgs e)
        {

            try
            {
                if (this.txtmabm.Text == "Nhập mã bộ môn" || this.txtmabm.Text=="")
                {
                    MessageBox.Show("Vui lòng nhập Mã Bộ môn!");
                    this.txtmabm.Focus();
                }
                else if (this.txttenbm.Text == "Nhập tên bộ môn" || this.txttenbm.Text=="")
                {
                    MessageBox.Show("Vui lòng nhập Tên bộ môn!");
                    this.txttenbm.Focus();
                }
                else if (this.cbmakhoabm.Text == "Chọn khoa" )
                {
                    MessageBox.Show("Vui lòng Chọn khoa!");
                }
                else if (this.rtxtmotabm.Text == "Nhập mô tả" || this.rtxtmotabm.Text == "")
                {
                    MessageBox.Show("Vui lòng nhập mô tả!");
                    this.rtxtmotabm.Focus();
                }
                else
                {
                    bm.Makhoa = this.cbmakhoabm.SelectedValue.ToString().Trim();
                    bm.MaBoMon = this.txtmabm.Text; 
                    bm.TenBoMon= this.txttenbm.Text;
                    bm.Mota = this.rtxtmotabm.Text;
                    bm.addBoMon();
                    DataTable dtbm = bm.getdsBoMon();
                    dgvbm.DataSource = dtbm;
                    dgvbm.Columns["MaBM"].HeaderText = "Mã Bộ Môn";
                    dgvbm.Columns["TenBoMon"].HeaderText = "Tên Bộ Môn";
                    dgvbm.Columns["MoTaBM"].HeaderText = "Mô Tả";
                    dgvbm.Columns["MaKhoa"].HeaderText = "Mã Khoa";
                    load(1);
                    load_cb();
                    MessageBox.Show("Dữ liệu đã được thêm thành công vào hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Bộ môn có mã {this.txtmabm.Text} đã tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnxoabm_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa dữ liệu này không?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                try
                {
                    if (this.txtmabm.Text == "Nhập mã bộ môn" || this.txtmabm.Text == "")
                    {
                        MessageBox.Show("Bạn chưa nhập mã bộ môn. Vui lòng điền thông tin trước khi tiếp tục.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        this.txtmabm.Focus();
                        return;
                    }
                    DataTable dtbm1 = bm.getdsBoMon();
                    dgvbm.DataSource = dtbm1;
                    bool kt = false;
                    foreach (DataGridViewRow row in dgvbm.Rows)
                    {
                        if (row.Cells["MaBM"].Value != null && row.Cells["MaBM"].Value.ToString().Trim() == txtmabm.Text.Trim())
                        {
                            bm.MaBoMon = this.txtmabm.Text;
                            bm.deleteBoMon();
                            DataTable dtbm = bm.getdsBoMon();
                            dgvbm.DataSource = dtbm;
                            dgvbm.Columns["MaBM"].HeaderText = "Mã Bộ Môn";
                            dgvbm.Columns["TenBoMon"].HeaderText = "Tên Bộ Môn";
                            dgvbm.Columns["MoTaBM"].HeaderText = "Mô Tả";
                            dgvbm.Columns["MaKhoa"].HeaderText = "Mã Khoa";
                            load(1);
                            load_cb();
                            this.btnhuybm.Enabled = true;
                            kt = true;
                            MessageBox.Show("Dữ liệu đã được xóa thành công khỏi hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            break;
                        }
                    }
                   
                    if (!kt)
                    {
                        MessageBox.Show($"Bộ môn có mã {this.txtmabm.Text} không tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi người dùng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        dgvbm.Columns["MaBM"].HeaderText = "Mã Bộ Môn";
                        dgvbm.Columns["TenBoMon"].HeaderText = "Tên Bộ Môn";
                        dgvbm.Columns["MoTaBM"].HeaderText = "Mô Tả";
                        dgvbm.Columns["MaKhoa"].HeaderText = "Mã Khoa";
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi không thể xóa dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Hủy xóa dữ liệu.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void btnsuabm_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.txtmabm.Text == "Nhập mã bộ môn" || this.txtmabm.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập mã số sinh viên. Vui lòng điền thông tin trước khi tiếp tục.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    this.txtmabm.Focus();
                    return;
                }
                DataTable dtbm = bm.getdsBoMon();
                dgvbm.DataSource = dtbm;
                bool kt = false;
                int dem = 0;
                foreach (DataGridViewRow row in dgvbm.Rows)
                {
                    if (row.Cells["MaBM"].Value != null && row.Cells["MaBM"].Value.ToString().Trim() == txtmabm.Text.Trim())
                    {

                        if (this.txttenbm.Text == "Nhập tên bộ môn" || this.txttenbm.Text=="")
                        {
                            this.txttenbm.Text = row.Cells["TenBoMon"].Value.ToString();
                            this.txttenbm.ForeColor = Color.Black;
                            dem += 1;
                        }
                        if (this.cbmakhoabm.Text == "Chọn khoa")
                        {
                            if (row.Cells["MaKhoa"].Value != null)
                            {
                                this.cbmakhoabm.SelectedValue = row.Cells["MaKhoa"].Value.ToString().Trim();
                                this.cbmakhoabm.Text = this.cbmakhoabm.GetItemText(this.cbmakhoabm.SelectedItem);
                                dem += 1;
                            }
                        }
                        if (this.rtxtmotabm.Text == "Nhập mô tả" || this.rtxtmotabm.Text=="")
                        {
                            this.rtxtmotabm.Text = row.Cells["MoTaBM"].Value.ToString();
                            this.rtxtmotabm.ForeColor = Color.Black;
                            dem += 1;
                        }
                        if (dem == 3)
                        {
                            MessageBox.Show("Chưa thay đổi thông tin cần cập nhật.\n\nVui lòng kiểm tra và thử lại.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.txtmabm.Focus();
                            return;
                        }
                        bm.Makhoa = this.cbmakhoabm.SelectedValue.ToString().Trim();
                        bm.MaBoMon = this.txtmabm.Text;
                        bm.TenBoMon = this.txttenbm.Text;
                        bm.Mota = this.rtxtmotabm.Text;
                        bm.updateBoMon();
                        DataTable dtbm1 = bm.getdsBoMon();
                        dgvbm.DataSource = dtbm1;
                        dgvbm.Columns["MaBM"].HeaderText = "Mã Bộ Môn";
                        dgvbm.Columns["TenBoMon"].HeaderText = "Tên Bộ Môn";
                        dgvbm.Columns["MoTaBM"].HeaderText = "Mô Tả";
                        dgvbm.Columns["MaKhoa"].HeaderText = "Mã Khoa";
                        load(1);
                        load_cb();
                        if (this.cbmakhoabm.SelectedIndex == 0)
                        {
                            this.cbmakhoabm.ForeColor = Color.Gray;
                        }
                        else
                        {
                            this.cbmakhoabm.ForeColor = Color.Black;
                        }
                        MessageBox.Show("Dữ liệu đã được cập nhật thành công vào hệ thống!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        kt = true;
                        break;
                    }

                }

                if (!kt)
                {
                    MessageBox.Show($"Bộ môn có mã {this.txtmabm.Text} không tồn tại trong cơ sở dữ liệu. Vui lòng kiểm tra lại!", "Lỗi người dùng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.txtmabm.Focus();
                    dgvbm.Columns["MaBM"].HeaderText = "Mã Bộ Môn";
                    dgvbm.Columns["TenBoMon"].HeaderText = "Tên Bộ Môn";
                    dgvbm.Columns["MoTaBM"].HeaderText = "Mô Tả";
                    dgvbm.Columns["MaKhoa"].HeaderText = "Mã Khoa";
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi cập nhật dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnhuybm_Click(object sender, EventArgs e)
        {
            load(1);
            load_cb();
            this.txttimbm.Text = "";
            Hienthinut(2);
            this.btnhuybm.Enabled = false;
            DataTable dtbm1 = bm.getdsBoMon();
            dgvbm.DataSource = dtbm1;
            dgvbm.Columns["MaBM"].HeaderText = "Mã Bộ Môn";
            dgvbm.Columns["TenBoMon"].HeaderText = "Tên Bộ Môn";
            dgvbm.Columns["MoTaBM"].HeaderText = "Mô Tả";
            dgvbm.Columns["MaKhoa"].HeaderText = "Mã Khoa";
        }
        private void btnthoatbm_Click(object sender, EventArgs e)
        {
            DialogResult result = DialogResult.OK;
            this.Close();
        }

        private void txt_Enter(object sender, EventArgs e)
        {
            
            TextBox tx = (TextBox)sender;
            if (tx.Text == this.txtmabm.Text && tx.Text == "Nhập mã bộ môn")
            {
                this.txtmabm.Text = "";
                this.txtmabm.ForeColor = Color.Black;
            }
            else if (tx.Text == this.txttenbm.Text && tx.Text == "Nhập tên bộ môn")
            {
                this.txttenbm.Text = "";
                this.txttenbm.ForeColor = Color.Black;
            }
        }
        private void txt_Leave(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(this.txtmabm.Text))
            {
                this.txtmabm.Text = "Nhập mã bộ môn";
                this.txtmabm.ForeColor = Color.Gray;
            }
            else if (string.IsNullOrWhiteSpace(this.txttenbm.Text))
            {
                this.txttenbm.Text = "Nhập tên bộ môn";
                this.txttenbm.ForeColor = Color.Gray;
            }
        }
        private void rtxt_Enter(object sender, EventArgs e)
        {
            if (this.rtxtmotabm.Text == "Nhập mô tả")
            {
                this.rtxtmotabm.Text = "";
                this.rtxtmotabm.ForeColor = Color.Black;
            }
        }

        private void rtxt_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(this.rtxtmotabm.Text))
            {
                this.rtxtmotabm.Text = "Nhập mô tả";
                this.rtxtmotabm.ForeColor = Color.Gray;
            }
        }
        private void VoHieuHoa_cb(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void cbmakhoabm_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            ComboBox comboBox = sender as ComboBox;
            string text = comboBox.GetItemText(comboBox.Items[e.Index]);


            Color textColor = text == "Chọn khoa" ? Color.Gray : Color.Black;

            e.DrawBackground();
            using (Brush brush = new SolidBrush(textColor))
            {
                e.Graphics.DrawString(text, e.Font, brush, e.Bounds);
            }
            e.DrawFocusRectangle();
        }

        private void txttimbm_KeyDown(object sender, KeyEventArgs e)
        {
            
            if (e.KeyCode == Keys.Enter)
            {
                btntimbm_Click(sender, e);
            }
        }
        private void btntimbm_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(this.txttimbm.Text.Trim()))
            {
                MessageBox.Show("Vui lòng nhập từ khóa tìm kiếm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else
            {
                DataTable dtbm = bm.getdsBoMon();
                dgvbm.DataSource = dtbm;
                DataTable dt_tim = new DataTable();
                DataColumn col1 = new DataColumn();
                col1.ColumnName = "MaBM";
                DataColumn col2 = new DataColumn();
                col2.ColumnName = "TenBoMon";
                DataColumn col3 = new DataColumn();
                col3.ColumnName = "MaKhoa";
                DataColumn col4 = new DataColumn();
                col4.ColumnName = "MoTaBM";
                dt_tim.Columns.Add(col1);
                dt_tim.Columns.Add(col2);
                dt_tim.Columns.Add(col3);
                dt_tim.Columns.Add(col4);
                bool kt = false;
                foreach (DataGridViewRow row in dgvbm.Rows)
                {
                    if (row.Cells["MaBM"].Value != null && row.Cells["MaBM"].Value.ToString().Trim() == txttimbm.Text.Trim())
                    {
                        DataRow dr = dt_tim.NewRow();
                        dr["MaBM"] = row.Cells["MaBM"].Value.ToString();
                        dr["TenBoMon"] = row.Cells["TenBoMon"].Value.ToString();
                        dr["MoTaBM"] = row.Cells["MoTaBM"].Value.ToString();
                        dr["MaKhoa"] = row.Cells["MaKhoa"].Value.ToString();
                        dt_tim.Rows.Add(dr);
                        kt = true;
                    }
                }
                load(1);
                load_cb();
                Hienthinut(2);
                this.dgvbm.DataSource = dt_tim;
                if (!kt)
                {
                    MessageBox.Show("Không tìm thấy thông tin bộ môn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                this.btnhuybm.Enabled = true;
            }
            
        }

        private void btncapnhatmkbm_Click(object sender, EventArgs e)
        {
            frmKhoa frmKhoa = new frmKhoa();
            if (frmKhoa.ShowDialog() == DialogResult.OK)
            {
                if (this.txtmabm.Text != "Nhập mã bộ môn" || this.txttenbm.Text != "Nhập tên bộ môn" || this.cbmakhoabm.SelectedIndex != 0 || this.rtxtmotabm.Text != "Nhập mô tả")
                {
                    this.btnhuybm.Enabled = true;
                    Hienthinut(2);
                    btncapnhatmkbm.BackColor = Color.FromArgb(192, 236, 255);
                    btncapnhatmkbm.ForeColor = Color.Black;
                    if (cbmakhoabm.SelectedIndex == 0)
                    {
                        cbmakhoabm.ForeColor = Color.Gray;
                    }
                    else
                    {
                        cbmakhoabm.ForeColor = Color.Black;
                    }
                }
                else
                {
                    Hienthinut(1);
                    btncapnhatmkbm.BackColor = Color.FromArgb(192, 236, 255);
                    btncapnhatmkbm.ForeColor = Color.Black;
                }
            }
            load_cb();
            btncapnhatmkbm.BackColor = Color.FromArgb(192, 236, 255);
            btncapnhatmkbm.ForeColor = Color.Black;

        }

        private void Textchange(object sender, EventArgs e)
        {
            bool isMabmEmpty = string.IsNullOrWhiteSpace(this.txtmabm.Text) || this.txtmabm.Text == "Nhập mã bộ môn";
            bool isTenbmEmpty = string.IsNullOrWhiteSpace(this.txttenbm.Text) || this.txttenbm.Text == "Nhập tên bộ môn";
            bool isMotaEmpty = string.IsNullOrWhiteSpace(this.rtxtmotabm.Text) || this.rtxtmotabm.Text == "Nhập mô tả";
            bool isTimbmEmpty = string.IsNullOrWhiteSpace(this.txttimbm.Text);
            bool isCbKhoabmNotSelected = this.cbmakhoabm.SelectedIndex == 0;
            if (cbmakhoabm.SelectedIndex == 0)
            {
                cbmakhoabm.ForeColor = Color.Gray;
            }
            else
            {
                cbmakhoabm.ForeColor = Color.Black;
            }

            if (isMabmEmpty && isTenbmEmpty && isMotaEmpty && isCbKhoabmNotSelected)
            {
                if (isTimbmEmpty)
                {
                    this.btnhuybm.Enabled = false;
                }
                else
                {
                    this.btnhuybm.Enabled = true;
                }
                Hienthinut(2);
            }
            else if (isMabmEmpty || isTenbmEmpty || isMotaEmpty || isCbKhoabmNotSelected)
            {
                if (isTimbmEmpty)
                {
                    this.btnhuybm.Enabled = true;
                }
                else
                {
                    this.btnhuybm.Enabled = true;
                }
                Hienthinut(1);
            }
            else if ((!isMabmEmpty && !isTenbmEmpty && !isMotaEmpty && !isCbKhoabmNotSelected))
            {

                if (isTimbmEmpty)
                {
                    this.btnhuybm.Enabled = true;
                }
                else
                {
                    this.btnhuybm.Enabled = true;
                }
                Hienthinut(1);
            }
        }

        private void btn_MouseEnter(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.Text == btnthembm.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnxoabm.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnsuabm.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnhuybm.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnthoatbm.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btncapnhatmkbm.Text)
            {
                btn.BackColor = Color.FromArgb(0, 191, 255);
                btn.ForeColor = Color.Black;
            }
        }

        private void btnsuabm_MouseLeave(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.Text == btnthembm.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnxoabm.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnsuabm.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnhuybm.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btnthoatbm.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
            else if (btn.Text == btncapnhatmkbm.Text)
            {
                btn.BackColor = Color.FromArgb(192, 236, 255);
                btn.ForeColor = Color.Black;
            }
        }

        private void cbmakhoabm_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (txttimbm.Text != "")
                return;
            DataTable dtbm = bm.getdsBoMon();
            this.dgvbm.DataSource = dtbm;
            if (this.cbmakhoabm.SelectedIndex > 0)
            {
                string makhoa = this.cbmakhoabm.SelectedValue.ToString().Trim();
                DataTable dtht2 = new DataTable();
                DataColumn col = new DataColumn();
                col.ColumnName = "Mã Bộ Môn";
                DataColumn col2 = new DataColumn();
                col2.ColumnName = "Tên Bộ Môn";
                DataColumn col3 = new DataColumn();
                col3.ColumnName = "Mã Khoa";
                DataColumn col4 = new DataColumn();
                col4.ColumnName = "Mô Tả";
                dtht2.Columns.Add(col);
                dtht2.Columns.Add(col2);
                dtht2.Columns.Add(col3);
                dtht2.Columns.Add(col4);
                bool kt = false;
                foreach (DataGridViewRow row in dgvbm.Rows)
                {
                    if (row.Cells["MaKhoa"].Value != null && row.Cells["MaKhoa"].Value.ToString().Trim() == makhoa)
                    {
                        DataRow d1 = dtht2.NewRow();
                        d1[0] = row.Cells["MaBM"].Value.ToString().Trim();
                        d1[1] = row.Cells["TenBoMon"].Value.ToString().Trim();
                        d1[2] = row.Cells["MaKhoa"].Value.ToString().Trim();
                        d1[3] = row.Cells["MoTaBM"].Value.ToString();
                        dtht2.Rows.Add(d1);
                    }
                }
                this.dgvbm.DataSource = dtht2;
            }
        
        }
    }
}
